// Copyright 2024 KVCache.AI
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// NDS (NPU Direct Storage) transport backend for Mooncake TENT.
//
// Path A (thin wrapper): NDS exposes P2P memory mapping (aclrtMemP2PMapHost)
// plus synchronous POSIX read/write to virtiofs.  This transport wraps the
// synchronous data plane with a user-space thread pool to satisfy the TENT
// Transport asynchronous batch contract (submitTransferTasks returns
// immediately; getTransferStatus polls for completion).
//
// Reference: NDS-Mooncake-接入接口分析.md §6.2 路径A
// Reference: ascend_nds.c async worker pool (experiment report §2.3)

#include "tent/transport/nds/nds_transport.h"

#include <fcntl.h>
#include <glog/logging.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cassert>
#include <cstddef>
#include <cstdint>

#include "tent/runtime/slab.h"

namespace mooncake {
namespace tent {

NdsTransport::NdsTransport() : installed_(false) {}

NdsTransport::~NdsTransport() { uninstall(); }

Status NdsTransport::install(std::string &local_segment_name,
                             std::shared_ptr<ControlService> metadata,
                             std::shared_ptr<Topology> local_topology,
                             std::shared_ptr<Config> conf) {
    if (installed_) {
        return Status::InvalidArgument(
            "NDS transport has been installed" LOC_MARK);
    }

    metadata_ = metadata;
    local_segment_name_ = local_segment_name;
    local_topology_ = local_topology;
    conf_ = conf;
    installed_ = true;

    io_batch_depth_ = conf_->get("transports/nds/io_batch_depth", 32);
    if (io_batch_depth_ < 1) io_batch_depth_ = 1;
    if (io_batch_depth_ > static_cast<int>(kNdsMaxBatchDepth))
        io_batch_depth_ = static_cast<int>(kNdsMaxBatchDepth);
    int worker_threads = conf_->get("transports/nds/worker_threads", 8);
    thread_pool_ = std::make_unique<NdsThreadPool>(
        static_cast<size_t>(worker_threads));

    // NDS handles both host DRAM ↔ file and NPU HBM ↔ file.
    // NPU plays the role that GPU plays in the GDS backend.
    caps.dram_to_file = true;
    caps.gpu_to_file = true;
    return Status::OK();
}

Status NdsTransport::uninstall() {
    if (installed_) {
        // Clean up all allocated sub-batches.
        {
            std::lock_guard<std::mutex> lock(allocated_batches_lock_);
            for (auto *nds_batch : allocated_batches_) {
                for (auto &fut : nds_batch->futures) {
                    if (fut.valid()) fut.wait();
                }
                Slab<NdsSubBatch>::Get().deallocate(nds_batch);
            }
            allocated_batches_.clear();
        }

        // Shut down the thread pool before releasing mappings.
        thread_pool_.reset();

        // Unmap all P2P buffers.
        {
            std::lock_guard<std::mutex> lock(buffer_map_lock_);
            for (auto &kv : buffer_map_) {
                aclrtMemP2PUnmapHost(kv.second.host_ptr, kv.second.size);
            }
            buffer_map_.clear();
        }

        // Close all file contexts.
        {
            std::lock_guard<std::mutex> lock(file_context_lock_);
            file_context_map_.clear();
        }

        metadata_.reset();
        installed_ = false;
    }
    return Status::OK();
}

Status NdsTransport::allocateSubBatch(SubBatchRef &batch, size_t max_size) {
    auto nds_batch = Slab<NdsSubBatch>::Get().allocate();
    if (!nds_batch)
        return Status::InternalError("Unable to allocate NDS sub-batch");

    nds_batch->max_size = max_size;
    // task_slots is a fixed-size std::array (non-movable NdsTaskSlot);
    // only reset the submitted-task count.
    nds_batch->num_tasks = 0;
    nds_batch->futures.clear();
    nds_batch->futures.reserve(io_batch_depth_);
    nds_batch->reusable = true;

    {
        std::lock_guard<std::mutex> lock(allocated_batches_lock_);
        allocated_batches_.push_back(nds_batch);
    }

    batch = nds_batch;
    return Status::OK();
}

Status NdsTransport::freeSubBatch(SubBatchRef &batch) {
    auto nds_batch = dynamic_cast<NdsSubBatch *>(batch);
    if (!nds_batch)
        return Status::InvalidArgument("Invalid NDS sub-batch" LOC_MARK);

    // Remove from tracking list.
    {
        std::lock_guard<std::mutex> lock(allocated_batches_lock_);
        auto it = std::find(allocated_batches_.begin(),
                            allocated_batches_.end(), nds_batch);
        if (it != allocated_batches_.end()) {
            allocated_batches_.erase(it);
        }
    }

    // Safety condition (experiment report §5.2 freeSubBatch): wait for all
    // in-flight I/O to reach a terminal state before allowing reuse.  The
    // synchronous POSIX I/O has no residual device references once the
    // worker thread completes, so waiting on futures is sufficient.
    for (auto &fut : nds_batch->futures) {
        if (fut.valid()) fut.wait();
    }

    Slab<NdsSubBatch>::Get().deallocate(nds_batch);
    batch = nullptr;
    return Status::OK();
}

std::string NdsTransport::getNdsFilePath(SegmentID target_id) {
    std::string ret;
    auto status = metadata_->segmentManager().withCachedSegment(
        target_id, [&](SegmentDesc *segment) {
            if (segment->type != SegmentType::File)
                return Status::NeedsRefreshCache(
                    "Segment type is not File" LOC_MARK);
            auto &detail = std::get<FileSegmentDesc>(segment->detail);
            if (detail.buffers.empty())
                return Status::NeedsRefreshCache("No buffers found" LOC_MARK);
            ret = detail.buffers[0].path;
            return Status::OK();
        });
    if (!status.ok()) return "";
    return ret;
}

NdsFileContext *NdsTransport::findFileContext(SegmentID target_id) {
    thread_local std::unordered_map<SegmentID, std::shared_ptr<NdsFileContext>>
        tl_file_context_map;
    if (tl_file_context_map.count(target_id))
        return tl_file_context_map[target_id].get();

    std::lock_guard<std::mutex> guard(file_context_lock_);
    if (!file_context_map_.count(target_id)) {
        std::string path = getNdsFilePath(target_id);
        if (path.empty()) return nullptr;
        file_context_map_[target_id] = std::make_shared<NdsFileContext>(path);
    }

    tl_file_context_map = file_context_map_;
    return tl_file_context_map[target_id].get();
}

void *NdsTransport::lookupHostVa(void *dev_ptr) {
    std::lock_guard<std::mutex> lock(buffer_map_lock_);
    auto it = buffer_map_.find(dev_ptr);
    if (it == buffer_map_.end()) return nullptr;
    return it->second.host_ptr;
}

Status NdsTransport::submitTransferTasks(
    SubBatchRef batch, const std::vector<Request> &request_list) {
    auto nds_batch = dynamic_cast<NdsSubBatch *>(batch);
    if (!nds_batch)
        return Status::InvalidArgument("Invalid NDS sub-batch" LOC_MARK);

    size_t first_task = nds_batch->num_tasks;
    if (first_task + request_list.size() > static_cast<size_t>(io_batch_depth_))
        return Status::TooManyRequests("Exceed batch capacity" LOC_MARK);

    for (auto &request : request_list) {
        // Alignment contract: NDS requires 4 KB aligned offset and length.
        if (request.target_offset % kNdsAlignment != 0 ||
            request.length % kNdsAlignment != 0) {
            return Status::InvalidArgument(
                "NDS: offset and length must be 4 KB aligned" LOC_MARK);
        }

        NdsFileContext *context = findFileContext(request.target_id);
        if (!context || !context->ready())
            return Status::InvalidArgument(
                "Invalid remote segment" LOC_MARK);

        // Resolve the host-usable VA for the source buffer.
        // For host DRAM (not in buffer_map_), request.source is already
        // a host pointer and can be used directly.
        void *io_buf = lookupHostVa(request.source);
        if (!io_buf) io_buf = request.source;  // assume host DRAM

        // Take the next slot from the fixed-size array. task_slots is a
        // std::array, so the pointer stays stable for the thread-pool
        // worker.
        const size_t task_id = nds_batch->num_tasks++;
        NdsTaskSlot *slot = &nds_batch->task_slots[task_id];

        int fd = context->fd();
        auto opcode = request.opcode;
        uint64_t file_offset = request.target_offset;
        size_t length = request.length;

        // Dispatch synchronous POSIX I/O to the thread pool and return
        // immediately.  The worker updates the slot atomically on
        // completion.
        auto fut = thread_pool_->submit(
            [fd, io_buf, opcode, file_offset, length, slot]() {
                ssize_t ret;
                if (opcode == Request::READ) {
                    ret = pread(fd, io_buf, length,
                                static_cast<off_t>(file_offset));
                } else {
                    ret = pwrite(fd, io_buf, length,
                                 static_cast<off_t>(file_offset));
                }
                if (ret < 0) {
                    slot->status.store(TransferStatusEnum::FAILED,
                                       std::memory_order_release);
                    slot->transferred_bytes.store(0,
                                                  std::memory_order_release);
                } else {
                    slot->status.store(TransferStatusEnum::COMPLETED,
                                       std::memory_order_release);
                    slot->transferred_bytes.store(
                        static_cast<size_t>(ret), std::memory_order_release);
                }
            });
        nds_batch->futures.push_back(std::move(fut));
    }
    return Status::OK();
}

Status NdsTransport::getTransferStatus(SubBatchRef batch, int task_id,
                                       TransferStatus &status) {
    auto nds_batch = dynamic_cast<NdsSubBatch *>(batch);
    if (!nds_batch)
        return Status::InvalidArgument("Invalid NDS sub-batch" LOC_MARK);

    size_t num_tasks = nds_batch->num_tasks;
    if (task_id < 0 || task_id >= static_cast<int>(num_tasks))
        return Status::InvalidArgument("Invalid task ID");

    // No lock needed: task_slots is a fixed std::array and each slot's
    // state is atomic.
    auto &slot = nds_batch->task_slots[task_id];
    status.s = slot.status.load(std::memory_order_acquire);
    status.transferred_bytes =
        slot.transferred_bytes.load(std::memory_order_acquire);
    return Status::OK();
}

Status NdsTransport::addMemoryBuffer(BufferDesc &desc,
                                     const MemoryOptions &options) {
    LocationParser location(options.location);
    std::string loc_type = location.type();

    // Host DRAM can be used directly by POSIX without P2P mapping.
    if (loc_type == "cpu" || loc_type == "dram" || loc_type == "host")
        return Status::OK();

    // NPU HBM (and other accelerator memory) requires P2P mapping to
    // obtain a host-usable virtual address for POSIX read/write.
    if (desc.length > kNdsMaxP2PMappingSize) {
        return Status::InvalidArgument(
            "NDS: buffer size exceeds 2 GiB P2P mapping limit" LOC_MARK);
    }

    void *host_ptr = nullptr;
    auto ret =
        aclrtMemP2PMapHost((void *)desc.addr, desc.length, &host_ptr, 0);
    if (ret != ACL_SUCCESS) {
        return Status::InternalError(
            std::string("NDS: aclrtMemP2PMapHost failed: ") +
            std::to_string(ret) + LOC_MARK);
    }

    {
        std::lock_guard<std::mutex> lock(buffer_map_lock_);
        buffer_map_[(void *)desc.addr] = {host_ptr, desc.length};
    }

    desc.transports.push_back(NDS);
    LOG(INFO) << "NDS: mapped device buffer " << desc.addr << " (size="
              << desc.length << ") to host VA " << host_ptr;
    return Status::OK();
}

Status NdsTransport::removeMemoryBuffer(BufferDesc &desc) {
    std::lock_guard<std::mutex> lock(buffer_map_lock_);
    auto it = buffer_map_.find((void *)desc.addr);
    if (it == buffer_map_.end()) return Status::OK();

    auto ret = aclrtMemP2PUnmapHost(it->second.host_ptr, it->second.size);
    if (ret != ACL_SUCCESS) {
        return Status::InternalError(
            std::string("NDS: aclrtMemP2PUnmapHost failed: ") +
            std::to_string(ret) + LOC_MARK);
    }

    buffer_map_.erase(it);
    return Status::OK();
}

}  // namespace tent
}  // namespace mooncake