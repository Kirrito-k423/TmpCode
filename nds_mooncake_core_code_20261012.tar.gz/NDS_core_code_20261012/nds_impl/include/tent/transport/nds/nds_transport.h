// Copyright 2024 KVCache.AI
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef NDS_TRANSPORT_H_
#define NDS_TRANSPORT_H_

#include <bits/stdint-uintn.h>

#include <array>
#include <atomic>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <future>
#include <memory>
#include <mutex>
#include <queue>
#include <string>
#include <thread>
#include <unordered_map>
#include <utility>
#include <vector>

#include <acl/acl.h>

#include "tent/runtime/control_plane.h"
#include "tent/runtime/transport.h"

namespace mooncake {
namespace tent {

// NDS (NPU Direct Storage) P2P memory mapping API.
//
// These symbols are exported by the Ascend CANN runtime v9.0.0 staging
// libraries (libacl_rt.so) but are NOT declared in the public acl_rt.h
// header shipped with the standard CANN install.  We declare them here
// and rely on LD_PRELOAD of the six staging .so files at process launch
// to resolve the symbols at runtime (see NDS experiment report §5.5).
//
// aclrtMemP2PMapHost maps an NPU HBM device pointer into a second virtual
// address that the host CPU can use for POSIX read/write, enabling
// zero-copy file I/O directly into NPU HBM via virtiofs + P2P DMA.
//
// Source: runtime-v9.0.0/src/acl/aclrt_impl/memory.cpp:253
extern "C" {
aclError aclrtMemP2PMapHost(void *devPtr, size_t size, void **hostPtr,
                            uint32_t flags);
aclError aclrtMemP2PUnmapHost(void *hostPtr, size_t size);
}

// Maximum single P2P mapping size (2 GiB).  The NDS fio engine enforces
// this ceiling (experiment report §8.10); larger buffers must be split
// across multiple mappings.
constexpr size_t kNdsMaxP2PMappingSize = 2ull * 1024 * 1024 * 1024;

// NDS alignment contract: offset and length must be 4 KB aligned (FUSE
// patch requirement, experiment report §2.2).
constexpr size_t kNdsAlignment = 4096;

class NdsFileContext {
   public:
    explicit NdsFileContext(const std::string &path) : ready_(false) {
        // Buffered I/O (no O_DIRECT): P2P-mapped ZONE_DEVICE pages do not
        // support the kernel direct-I/O path (returns EREMOTEIO).  The
        // page-cache path correctly handles P2P-mapped VAs and still
        // reaches the NPU HBM via the host VA from aclrtMemP2PMapHost.
        int fd = open(path.c_str(), O_RDWR);
        if (fd < 0) {
            PLOG(ERROR) << "NDS: failed to open file " << path;
            return;
        }
        fd_ = fd;
        ready_ = true;
    }

    NdsFileContext(const NdsFileContext &) = delete;
    NdsFileContext &operator=(const NdsFileContext &) = delete;

    ~NdsFileContext() {
        if (fd_ >= 0) close(fd_);
    }

    int fd() const { return fd_; }
    bool ready() const { return ready_; }

   private:
    int fd_ = -1;
    bool ready_;
};

// Per-task state for asynchronous POSIX I/O dispatched to the thread pool.
// NdsTaskSlot is non-movable (std::atomic members), so NdsSubBatch stores a
// fixed-size array instead of a std::vector whose reallocation path would
// require a move constructor.
struct NdsTaskSlot {
    std::atomic<TransferStatusEnum> status{TransferStatusEnum::PENDING};
    std::atomic<size_t> transferred_bytes{0};
};

// Upper bound for one SubBatch's in-flight tasks. install() clamps the
// io_batch_depth config to this value.
constexpr size_t kNdsMaxBatchDepth = 64;

struct NdsSubBatch : public Transport::SubBatch {
    size_t max_size;
    std::array<NdsTaskSlot, kNdsMaxBatchDepth> task_slots{};
    size_t num_tasks = 0;
    // One future per submitted task; waited on in freeSubBatch and polled
    // in getTransferStatus.
    std::vector<std::future<void>> futures;
    bool reusable = true;
    std::mutex status_mutex;
    virtual size_t size() const { return num_tasks; }
};

// Fixed-size thread pool that turns synchronous POSIX pread/pwrite into
// asynchronous submissions conforming to the TENT Transport contract.
// Modelled on the async worker pool in ascend_nds.c (experiment report
// §2.3): NDS data plane is synchronous POSIX; asyncity is simulated in
// user space by dispatching each I/O to a worker thread.
class NdsThreadPool {
   public:
    explicit NdsThreadPool(size_t num_workers) : stop_(false) {
        if (num_workers == 0) num_workers = 1;
        for (size_t i = 0; i < num_workers; ++i)
            workers_.emplace_back([this] { workerLoop(); });
    }

    ~NdsThreadPool() { shutdown(); }

    NdsThreadPool(const NdsThreadPool &) = delete;
    NdsThreadPool &operator=(const NdsThreadPool &) = delete;

    template <typename F>
    std::future<void> submit(F &&task) {
        auto packaged = std::make_shared<std::packaged_task<void()>>(
            std::forward<F>(task));
        std::future<void> fut = packaged->get_future();
        {
            std::lock_guard<std::mutex> lock(mutex_);
            tasks_.emplace([packaged]() { (*packaged)(); });
        }
        cv_.notify_one();
        return fut;
    }

    void shutdown() {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            if (stop_) return;
            stop_ = true;
        }
        cv_.notify_all();
        for (auto &w : workers_)
            if (w.joinable()) w.join();
        workers_.clear();
    }

   private:
    void workerLoop() {
        for (;;) {
            std::function<void()> task;
            {
                std::unique_lock<std::mutex> lock(mutex_);
                cv_.wait(lock, [this] { return stop_ || !tasks_.empty(); });
                if (stop_ && tasks_.empty()) return;
                task = std::move(tasks_.front());
                tasks_.pop();
            }
            task();
        }
    }

    std::vector<std::thread> workers_;
    std::queue<std::function<void()>> tasks_;
    std::mutex mutex_;
    std::condition_variable cv_;
    bool stop_;
};

// Device-pointer -> mapped host-VA entry.  addMemoryBuffer populates this
// via aclrtMemP2PMapHost; submitTransferTasks looks up the host VA to use
// as the POSIX read/write buffer.
struct NdsBufferMapping {
    void *host_ptr = nullptr;
    size_t size = 0;
};

class NdsTransport : public Transport {
   public:
    NdsTransport();

    ~NdsTransport();

    virtual Status install(std::string &local_segment_name,
                           std::shared_ptr<ControlService> metadata,
                           std::shared_ptr<Topology> local_topology,
                           std::shared_ptr<Config> conf = nullptr);

    virtual Status uninstall();

    virtual Status allocateSubBatch(SubBatchRef &batch, size_t max_size);

    virtual Status freeSubBatch(SubBatchRef &batch);

    virtual Status submitTransferTasks(
        SubBatchRef batch, const std::vector<Request> &request_list);

    virtual Status getTransferStatus(SubBatchRef batch, int task_id,
                                     TransferStatus &status);

    virtual Status addMemoryBuffer(BufferDesc &desc,
                                   const MemoryOptions &options);

    virtual Status removeMemoryBuffer(BufferDesc &desc);

    virtual const char *getName() const { return "nds"; }

   private:
    NdsFileContext *findFileContext(SegmentID target_id);

    std::string getNdsFilePath(SegmentID target_id);

    void *lookupHostVa(void *dev_ptr);

    bool installed_ = false;
    std::shared_ptr<ControlService> metadata_;
    std::string local_segment_name_;
    std::shared_ptr<Topology> local_topology_;
    std::shared_ptr<Config> conf_;

    int io_batch_depth_ = 32;
    std::unique_ptr<NdsThreadPool> thread_pool_;

    // Device-to-host P2P mapping table.
    std::mutex buffer_map_lock_;
    std::unordered_map<void *, NdsBufferMapping> buffer_map_;

    // File context cache (per-thread + global fallback).
    using FileContextMap =
        std::unordered_map<SegmentID, std::shared_ptr<NdsFileContext>>;
    std::mutex file_context_lock_;
    FileContextMap file_context_map_;

    // Track allocated sub-batches for cleanup on uninstall.
    std::mutex allocated_batches_lock_;
    std::vector<NdsSubBatch *> allocated_batches_;
};

}  // namespace tent
}  // namespace mooncake

#endif  // NDS_TRANSPORT_H_