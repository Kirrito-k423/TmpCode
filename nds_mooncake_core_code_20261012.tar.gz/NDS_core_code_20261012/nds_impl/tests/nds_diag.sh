#!/bin/bash
S=/root/tomer/nds/runtime-v9.0.0/build/_CPack_Packages/makeself_staging/runtime/lib
cd /home/t00906153/Mooncake/mooncake-transfer-engine/tent/tests/nds

echo '=== env check ==='
df -T /home /mnt/TRC 2>/dev/null | head -5
ls /dev/davinci_zonedev* 2>/dev/null | head -3

echo '=== rebuild with errno diagnostics ==='
cat > /tmp/diag.c << 'EOF'
#include <errno.h>
#include <string.h>
EOF
g++ -std=c++17 -O2 -DUSE_ERRNO_DIAG \
  -I/usr/local/Ascend/cann/include \
  nds_smoke_test.cpp -o nds_smoke_test \
  -L$S -lacl_rt -lpthread -Wl,-rpath,$S 2>&1 | tail -3

echo '=== run with strace pread ==='
SIX="$S/libascend_dump.so $S/liberror_manager.so $S/libruntime_common.so $S/libruntime.so $S/libacl_rt_impl.so $S/libacl_rt.so"
if command -v strace >/dev/null; then
  LD_PRELOAD="$SIX" LD_LIBRARY_PATH="$S:$LD_LIBRARY_PATH" \
    strace -f -e trace=openat,pread64,pwrite64,close -o /tmp/nds_strace.txt \
    ./nds_smoke_test 2>&1 | tail -8
  echo '=== strace pread lines ==='
  grep -E 'pread64|pwrite64' /tmp/nds_strace.txt | head -8
else
  echo 'no strace, plain run:'
  LD_PRELOAD="$SIX" LD_LIBRARY_PATH="$S:$LD_LIBRARY_PATH" ./nds_smoke_test 2>&1 | tail -6
fi