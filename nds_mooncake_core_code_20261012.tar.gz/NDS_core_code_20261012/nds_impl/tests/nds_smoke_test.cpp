// Copyright 2024 KVCache.AI
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Minimal smoke test for the NDS P2P data path that NdsTransport relies on.
//
// Exercises the exact sequence NdsTransport performs at runtime:
//   aclrtMalloc(HUGE_FIRST_P2P) -> aclrtMemP2PMapHost ->
//   pread/pwrite on the mapped host VA (O_DIRECT, 4K aligned) ->
//   aclrtMemcpy verify -> aclrtMemP2PUnmapHost -> aclrtFree.
//
// Build (on A2-110):
//   S=/root/tomer/nds/runtime-v9.0.0/build/_CPack_Packages/makeself_staging/runtime/lib
//   g++ -std=c++17 -O2 -I/usr/local/Ascend/cann/include \
//       nds_smoke_test.cpp -o nds_smoke_test -L$S -lacl_rt -lpthread \
//       -Wl,-rpath,$S
//
// Run (LD_PRELOAD of the six NDS staging libraries, see experiment report
// §5.5):
//   SIX="$S/libascend_dump.so $S/liberror_manager.so $S/libruntime_common.so \
//        $S/libruntime.so $S/libacl_rt_impl.so $S/libacl_rt.so"
//   LD_PRELOAD="$SIX" LD_LIBRARY_PATH="$S:$LD_LIBRARY_PATH" ./nds_smoke_test

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <cerrno>
#include <cstdio>
#include <cstring>
#include <vector>

#include <acl/acl.h>

extern "C" {
aclError aclrtMemP2PMapHost(void *devPtr, size_t size, void **hostPtr,
                            uint32_t flags);
aclError aclrtMemP2PUnmapHost(void *hostPtr, size_t size);
}

namespace {

constexpr size_t kSize = 4 * 1024 * 1024;  // 4 MiB, 4 KB aligned
constexpr size_t kAlignment = 4096;
const char *kPath = "/home/t00906153/nds_test_data.bin";

#define CHECK(expr, msg)                                              \
    do {                                                              \
        if ((expr) != ACL_SUCCESS) {                                  \
            printf("FAIL: %s (line %d)\n", msg, __LINE__);            \
            return 1;                                                 \
        }                                                             \
    } while (0)

}  // namespace

int main() {
    // 1. ACL init.
    CHECK(aclInit(nullptr), "aclInit");
    CHECK(aclrtSetDevice(0), "aclrtSetDevice(0)");

    // 2. Prepare the test file with a known pattern (4 KB aligned size).
    int fd = open(kPath, O_RDWR | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) {
        perror("open test file");
        return 1;
    }
    std::vector<char> pattern(kSize);
    for (size_t i = 0; i < kSize; ++i)
        pattern[i] = static_cast<char>(i & 0xFF);
    if (pwrite(fd, pattern.data(), kSize, 0) != static_cast<ssize_t>(kSize)) {
        perror("pwrite pattern");
        return 1;
    }
    fsync(fd);

    // 3. Allocate NPU HBM via the P2P allocation policy.
    void *dev_ptr = nullptr;
    CHECK(aclrtMalloc(&dev_ptr, kSize, ACL_MEM_MALLOC_HUGE_FIRST_P2P),
          "aclrtMalloc(HUGE_FIRST_P2P)");

    // 4. Map to a host-usable VA (the NDS core API).
    void *host_va = nullptr;
    CHECK(aclrtMemP2PMapHost(dev_ptr, kSize, &host_va, 0),
          "aclrtMemP2PMapHost");
    printf("mapped dev %p (4 MiB) -> host VA %p\n", dev_ptr, host_va);
    if (reinterpret_cast<uintptr_t>(host_va) % kAlignment != 0) {
        printf("FAIL: mapped VA is not 4 KB aligned\n");
        return 1;
    }

    // 5. Buffered pread into the mapped HBM VA
    //    (the NdsTransport READ data path).  O_DIRECT is not used because
    //    P2P-mapped ZONE_DEVICE pages return EREMOTEIO on the direct-I/O
    //    path; the page-cache path works correctly.
    int dfd = open(kPath, O_RDONLY);
    if (dfd < 0) {
        perror("open (read)");
        return 1;
    }
    ssize_t got = pread(dfd, host_va, kSize, 0);
    if (got != static_cast<ssize_t>(kSize)) {
        printf("FAIL: pread into mapped VA returned %zd (%s)\n", got,
               strerror(errno));
        return 1;
    }
    close(dfd);

    // 6. Verify via D2H copy + memcmp.
    std::vector<char> check(kSize);
    CHECK(aclrtMemcpy(check.data(), kSize, dev_ptr, kSize,
                      ACL_MEMCPY_DEVICE_TO_HOST),
          "aclrtMemcpy D2H");
    if (memcmp(check.data(), pattern.data(), kSize) != 0) {
        printf("FAIL: data mismatch on read path\n");
        return 1;
    }
    printf("PASS: buffered pread into mapped HBM, data intact\n");

    // 7. Write path: fill HBM from host, pwrite from the mapped VA,
    //    verify by reading the file back (the NdsTransport WRITE path).
    for (size_t i = 0; i < kSize; ++i)
        pattern[i] = static_cast<char>((i * 7 + 3) & 0xFF);
    CHECK(aclrtMemcpy(dev_ptr, kSize, pattern.data(), kSize,
                      ACL_MEMCPY_HOST_TO_DEVICE),
          "aclrtMemcpy H2D");
    int wfd = open(kPath, O_WRONLY);
    if (wfd < 0) {
        perror("open (write)");
        return 1;
    }
    ssize_t put = pwrite(wfd, host_va, kSize, 0);
    if (put != static_cast<ssize_t>(kSize)) {
        printf("FAIL: pwrite from mapped VA returned %zd\n", put);
        return 1;
    }
    close(wfd);
    fsync(fd);

    std::vector<char> reread(kSize);
    if (pread(fd, reread.data(), kSize, 0) !=
        static_cast<ssize_t>(kSize)) {
        printf("FAIL: reread\n");
        return 1;
    }
    if (memcmp(reread.data(), pattern.data(), kSize) != 0) {
        printf("FAIL: data mismatch on write path\n");
        return 1;
    }
    printf("PASS: buffered pwrite from mapped HBM, data intact\n");

    // 8. Cleanup.
    CHECK(aclrtMemP2PUnmapHost(host_va, kSize), "aclrtMemP2PUnmapHost");
    CHECK(aclrtFree(dev_ptr), "aclrtFree");
    close(fd);
    unlink(kPath);
    aclFinalize();
    printf("== NDS SMOKE TEST PASSED ==\n");
    return 0;
}