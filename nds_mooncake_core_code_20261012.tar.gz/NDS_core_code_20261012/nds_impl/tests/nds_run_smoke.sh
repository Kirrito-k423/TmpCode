#!/bin/bash
S=/root/tomer/nds/runtime-v9.0.0/build/_CPack_Packages/makeself_staging/runtime/lib
cd /home/t00906153/Mooncake/mooncake-transfer-engine/tent/tests/nds
echo '=== fs check ==='
df -T /home | tail -1
echo '=== build ==='
g++ -std=c++17 -O2 \
  -I/usr/local/Ascend/cann/include \
  nds_smoke_test.cpp -o nds_smoke_test \
  -L$S -lacl_rt -lpthread -Wl,-rpath,$S
echo 'build OK'
echo '=== run ==='
SIX="$S/libascend_dump.so $S/liberror_manager.so $S/libruntime_common.so $S/libruntime.so $S/libacl_rt_impl.so $S/libacl_rt.so"
LD_PRELOAD="$SIX" LD_LIBRARY_PATH="$S:$LD_LIBRARY_PATH" ./nds_smoke_test
