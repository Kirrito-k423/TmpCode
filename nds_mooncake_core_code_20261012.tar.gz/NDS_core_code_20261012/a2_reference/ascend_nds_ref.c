/*
 * ascend_nds.c — external fio ioengine for NDS (NPU Direct Storage).
 *
 * v2: ASYNC (worker-thread pool), numjobs=1. Three modes:
 *   mode=p2p    : I/O buffer IS the mmap'd BAR4 VA over NPU HBM (zero-copy).
 *   mode=bounce : I/O buffer is host DRAM; each read is followed by an
 *                 aclrtMemcpy H2D, so the timed op = file->host->HBM.
 *   mode=p2pw   : like p2p, HBM prefilled device-side; writes permitted.
 *
 * WHY ASYNC (P0-6): virtio-fs selects its request queue by *issuing CPU*
 * (mq_map[raw_smp_processor_id()]; 192 CPUs / 24 queues = 8 CPUs per queue),
 * and the DPU backend is serial per queue. So concurrency comes from workers
 * landing on CPUs that map to DIFFERENT queues. Two axes are measurable with
 * one binary:
 *   cpu_stride=8  -> WIDTH: iodepth workers on iodepth distinct queues.
 *                   Expected to reproduce the measured N-process curve.
 *   cpu_stride=1  -> DEPTH: iodepth workers all on ONE queue (CPUs 0..7).
 *                   Pre-batching per-queue depth baseline; this is the axis
 *                   the backend batching work (UHF_WORKQ_DEPTH) must move.
 *
 * DO NOT run these under `taskset`. The engine pins its own workers; an
 * inherited single-CPU mask collapses every worker onto one queue and looks
 * exactly like "async did not help".
 *
 * Buffers: fio allocates ONE region (orig_buffer_size = max_bs * iodepth,
 * backend.c:1487-1491, unconditional) via our .iomem_alloc, then carves one
 * slot per io_u. So each in-flight io_u already owns a private HBM slot; the
 * engine needs no pool of its own. The 2GiB handler ceiling binds only when
 * iodepth * bs > 2GiB (24 x 1M = 24MiB, far under).
 *
 * Refusal gates (fail loud at init, never degrade silently): writes outside
 * p2pw, numjobs>1 (ACL not fork-safe), verify!=none, bs<4K or non-4K-multiple,
 * nr_files>1 (per-worker fd design), io_submit_mode=offload, iodepth out of
 * range, p2p mapping >2GiB.
 *
 * Build: ./build.sh   (needs -pthread)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sched.h>
#include <time.h>
#include <pthread.h>
#include <stdint.h>
#include <sys/mman.h>

#include "../fio-src/fio.h"
#include "../fio-src/optgroup.h"

#include "acl/acl.h"

enum { NDS_MODE_P2P = 0, NDS_MODE_BOUNCE = 1, NDS_MODE_P2PW = 2 };

#define NDS_MAX_DEPTH 64

struct nds_options {
	void *pad;
	unsigned int devid;
	unsigned int mode;
	unsigned int cpu_base;
	unsigned int cpu_stride;
};

struct nds_data;

struct nds_worker {
	pthread_t        th;
	struct nds_data *nd;
	int              idx;
	int              cpu;
	int              fd;		/* private fd -> matches the proven
					 * N-process config, where each stream
					 * had its own open() */
	int              started;
};

struct nds_data {
	struct thread_data *td;

	int   zonedev_fd;	/* p2p: fd of /dev/davinci_zonedevN */
	void *devPtr;		/* p2p: aclrtMalloc'd HBM devPtr (== mmap offset) */
	void *map;		/* p2p: mmap'd HBM VA (== td->orig_buffer)  */
	void *devDst;		/* bounce: HBM destination for H2D copy     */
	size_t total;		/* bytes mapped/allocated                   */
	int   acl_inited;
	int   dev_set;
	aclrtContext ctx;	/* implicit ctx from aclrtSetDevice; workers
				 * must adopt it before any ACL call */

	/* submission ring */
	struct io_u   **sq;
	int             sq_size;	/* depth + 1 */
	int             sq_head, sq_tail, sq_cnt;
	pthread_mutex_t sq_lock;
	pthread_cond_t  sq_cv;

	/* completion array */
	struct io_u   **cq;
	int             cq_cnt;
	pthread_mutex_t cq_lock;
	pthread_cond_t  cq_cv;

	/* snapshot handed to fio via .event() */
	struct io_u   **ev;
	int             ev_cnt;

	struct nds_worker *w;
	int   nworkers;
	int   depth;
	int   stop;
	int   workers_started;
	int   align_warned;
};

static struct fio_option options[] = {
	{
		.name  = "devid",
		.lname = "NPU device id",
		.type  = FIO_OPT_INT,
		.off1  = offsetof(struct nds_options, devid),
		.def   = "2",
		.help  = "Ascend NPU device id (must be same-root-complex as storage)",
		.category = FIO_OPT_C_ENGINE,
		.group    = FIO_OPT_G_INVALID,
	},
	{
		.name  = "mode",
		.lname = "NDS buffer mode",
		.type  = FIO_OPT_STR,
		.off1  = offsetof(struct nds_options, mode),
		.def   = "p2p",
		.help  = "p2p (buffer=HBM) or bounce (host DRAM + aclrtMemcpy H2D) or p2pw",
		.posval = {
			{ .ival = "p2p",    .oval = NDS_MODE_P2P },
			{ .ival = "bounce", .oval = NDS_MODE_BOUNCE },
			{ .ival = "p2pw",   .oval = NDS_MODE_P2PW },
		},
		.category = FIO_OPT_C_ENGINE,
		.group    = FIO_OPT_G_INVALID,
	},
	{
		.name  = "cpu_base",
		.lname = "worker CPU base",
		.type  = FIO_OPT_INT,
		.off1  = offsetof(struct nds_options, cpu_base),
		.def   = "0",
		.help  = "CPU of worker 0",
		.category = FIO_OPT_C_ENGINE,
		.group    = FIO_OPT_G_INVALID,
	},
	{
		.name  = "cpu_stride",
		.lname = "worker CPU stride",
		.type  = FIO_OPT_INT,
		.off1  = offsetof(struct nds_options, cpu_stride),
		.def   = "8",
		.help  = "worker i pinned to cpu_base + i*cpu_stride. "
			 "8 = one distinct virtio queue per worker (WIDTH axis); "
			 "1 = all workers share one queue (DEPTH axis)",
		.category = FIO_OPT_C_ENGINE,
		.group    = FIO_OPT_G_INVALID,
	},
	{ .name = NULL },
};

/* ------------------------------------------------------------------ */

static int fio_nds_setup(struct thread_data *td)
{
	struct nds_options *o = td->eo;
	struct fio_file *f;
	unsigned int i;

	/* writes allowed ONLY in explicit p2pw mode (prefilled device-side) */
	if ((td_write(td) || td_rw(td)) && o->mode != NDS_MODE_P2PW) {
		log_err("ascend_nds: writes only allowed with mode=p2pw (got mode=%d)\n", o->mode);
		return 1;
	}
	if (td->o.numjobs > 1) {
		log_err("ascend_nds: numjobs>1 unsupported (ACL not fork-safe). "
			"Use iodepth for in-process concurrency.\n");
		return 1;
	}
	if (td->o.verify != 0) {
		log_err("ascend_nds: verify= unsupported (use D2H harness).\n");
		return 1;
	}
	if (td->o.nr_files > 1) {
		log_err("ascend_nds: nr_files>1 unsupported (one private fd per worker "
			"is bound to a single file).\n");
		return 1;
	}
	if (td->o.io_submit_mode == IO_MODE_OFFLOAD) {
		log_err("ascend_nds: io_submit_mode=offload unsupported — fio's single "
			"submitter thread defeats per-worker CPU pinning, so queue "
			"selection would collapse.\n");
		return 1;
	}
	if (td->o.iodepth < 1 || td->o.iodepth > NDS_MAX_DEPTH) {
		log_err("ascend_nds: iodepth must be 1..%d (got %u)\n",
			NDS_MAX_DEPTH, td->o.iodepth);
		return 1;
	}
	if (o->cpu_stride < 1) {
		log_err("ascend_nds: cpu_stride must be >=1\n");
		return 1;
	}
	if (o->mode == NDS_MODE_P2P || o->mode == NDS_MODE_P2PW) {
		unsigned long long bs = td->o.min_bs[DDIR_READ];
		if (bs < 4096 || (bs & 4095)) {
			log_err("ascend_nds: bs must be a 4K multiple >=4K (O_DIRECT).\n");
			return 1;
		}
	}

	/* fio calls get_file_sizes() ONLY when the engine has NO ->setup
	 * (filesetup.c:1169-1172). We HAVE a ->setup, so file sizing is our
	 * responsibility. Skipping it leaves real_file_size = 0, so setup_files()
	 * sees (io_size + file_offset) > real_file_size, sets need_extend, and
	 * TRUNCATES + re-lays out the target before reading it. That is what
	 * destroyed the 16GiB DAOS seed on 2026-07-26. Unlike fio's own helper we
	 * fail loud instead of swallowing ENOENT: a missing file is precisely the
	 * condition that precedes a destructive layout. */
	for_each_file(td, f, i) {
		if (td_io_get_file_size(td, f)) {
			log_err("ascend_nds: get_file_size(%s) failed: %s\n",
				f->file_name, td->verror);
			return 1;
		}
		if (!f->real_file_size || f->real_file_size == -1ULL) {
			log_err("ascend_nds: %s unusable size %llu — refusing (fio would "
				"truncate and re-lay out this file)\n",
				f->file_name, (unsigned long long)f->real_file_size);
			return 1;
		}
		log_err("ascend_nds: file %s real_file_size=%llu\n",
			f->file_name, (unsigned long long)f->real_file_size);
	}

	return 0;
}

static int fio_nds_init(struct thread_data *td)
{
	struct nds_options *o = td->eo;
	struct nds_data *nd;
	aclError r;
	int depth = (int)td->o.iodepth;

	nd = calloc(1, sizeof(*nd));
	if (!nd)
		return 1;
	nd->td = td;
	nd->zonedev_fd = -1;
	nd->depth = depth;
	nd->nworkers = depth;
	nd->sq_size = depth + 1;
	td->io_ops_data = nd;

	nd->sq = calloc(nd->sq_size, sizeof(struct io_u *));
	nd->cq = calloc(nd->sq_size, sizeof(struct io_u *));
	nd->ev = calloc(nd->sq_size, sizeof(struct io_u *));
	nd->w  = calloc(nd->nworkers, sizeof(struct nds_worker));
	if (!nd->sq || !nd->cq || !nd->ev || !nd->w) {
		log_err("ascend_nds: ring alloc failed\n");
		return 1;
	}
	pthread_mutex_init(&nd->sq_lock, NULL);
	pthread_mutex_init(&nd->cq_lock, NULL);
	pthread_cond_init(&nd->sq_cv, NULL);
	pthread_cond_init(&nd->cq_cv, NULL);

	r = aclInit(NULL);
	if (r) { log_err("ascend_nds: aclInit=%d (source set_env.sh?)\n", r); return 1; }
	nd->acl_inited = 1;

	r = aclrtSetDevice(o->devid);
	if (r) { log_err("ascend_nds: aclrtSetDevice(%u)=%d\n", o->devid, r); return 1; }
	nd->dev_set = 1;

	/* aclrtSetDevice creates an implicit context bound to THIS thread only.
	 * Capture it so workers can adopt it (required for bounce/p2pw, which
	 * call aclrtMemcpy; harmless for pure p2p reads). */
	r = aclrtGetCurrentContext(&nd->ctx);
	if (r) {
		log_err("ascend_nds: aclrtGetCurrentContext=%d\n", r);
		nd->ctx = NULL;
	}
	return 0;
}

/* ------------------------------------------------------------------ */

static int fio_nds_iomem_alloc(struct thread_data *td, size_t total_mem)
{
	struct nds_options *o = td->eo;
	struct nds_data *nd = td->io_ops_data;
	aclError r;

	nd->total = (total_mem + 4095) & ~((size_t)4095);  /* round up to page */

	if (o->mode == NDS_MODE_P2P || o->mode == NDS_MODE_P2PW) {
		char path[64];

		if (nd->total > (2ULL << 30)) {
			log_err("ascend_nds: p2p mapping %zu > 2GiB handler ceiling "
				"(iodepth*bs too large)\n", total_mem);
			return 1;
		}
		r = aclrtMalloc(&nd->devPtr, nd->total, ACL_MEM_MALLOC_HUGE_FIRST_P2P);
		if (r) { log_err("ascend_nds: aclrtMalloc(P2P,%zu)=%d\n", total_mem, r); return 1; }

		snprintf(path, sizeof(path), "/dev/davinci_zonedev%u", o->devid);
		nd->zonedev_fd = open(path, O_RDWR);
		if (nd->zonedev_fd < 0) {
			log_err("ascend_nds: open(%s)=%d(%s)\n", path, errno, strerror(errno));
			return 1;
		}
		nd->map = mmap(NULL, nd->total, PROT_READ | PROT_WRITE, MAP_SHARED,
			       nd->zonedev_fd, (off_t)nd->devPtr);
		if (nd->map == MAP_FAILED) {
			log_err("ascend_nds: mmap(offset=%p,len=%zu)=%d(%s)\n",
				nd->devPtr, total_mem, errno, strerror(errno));
			nd->map = NULL;
			return 1;
		}
		if (o->mode == NDS_MODE_P2PW) {
			/* prefill HBM with a known pattern device-side so fio never
			 * CPU-touches the Device-nGnRnE mapping */
			void *tmp = calloc(1, nd->total);
			if (tmp) {
				memset(tmp, 0xAB, nd->total);
				aclrtMemcpy(nd->devPtr, nd->total, tmp, nd->total,
					    ACL_MEMCPY_HOST_TO_DEVICE);
				free(tmp);
				log_err("ascend_nds: p2pw prefilled HBM with 0xAB, size=%zu\n", nd->total);
			}
		}
		td->orig_buffer = nd->map;
		log_err("ascend_nds: p2p devid=%u devPtr=%p mappedVA=%p size=%zu\n",
			 o->devid, nd->devPtr, nd->map, total_mem);
	} else {
		void *hbuf = NULL;
		if (posix_memalign(&hbuf, 4096, nd->total)) {
			log_err("ascend_nds: posix_memalign(%zu) failed\n", total_mem);
			return 1;
		}
		td->orig_buffer = hbuf;
		r = aclrtMalloc(&nd->devDst, nd->total, ACL_MEM_MALLOC_HUGE_FIRST);
		if (r) { log_err("ascend_nds: aclrtMalloc(HBM dst,%zu)=%d\n", total_mem, r); return 1; }
		log_err("ascend_nds: bounce host=%p devDst=%p size=%zu\n",
			 td->orig_buffer, nd->devDst, total_mem);
	}
	return 0;
}

/* Idempotent. Must run BEFORE the BAR4 mapping is torn down, and fio's
 * ordering of iomem_free vs cleanup is not relied upon — every teardown
 * entry point calls this first. */
static void nds_stop_workers(struct nds_data *nd)
{
	int i;

	if (!nd || !nd->workers_started)
		return;

	pthread_mutex_lock(&nd->sq_lock);
	nd->stop = 1;
	pthread_cond_broadcast(&nd->sq_cv);
	pthread_mutex_unlock(&nd->sq_lock);

	for (i = 0; i < nd->nworkers; i++) {
		if (nd->w[i].started) {
			pthread_join(nd->w[i].th, NULL);
			nd->w[i].started = 0;
		}
		if (nd->w[i].fd >= 0) {
			close(nd->w[i].fd);
			nd->w[i].fd = -1;
		}
	}
	nd->workers_started = 0;
}

static void fio_nds_iomem_free(struct thread_data *td)
{
	struct nds_options *o = td->eo;
	struct nds_data *nd = td->io_ops_data;

	if (!nd)
		return;

	nds_stop_workers(nd);

	/* p2p AND p2pw both took the mapped path in iomem_alloc — v1 tested
	 * only P2P here and thus called free() on the BAR4 VA in p2pw mode. */
	if (o->mode != NDS_MODE_BOUNCE) {
		/* CRITICAL: munmap BEFORE aclrtFree (proven-safe ordering). */
		if (nd->map)		 { munmap(nd->map, nd->total); nd->map = NULL; }
		if (nd->zonedev_fd >= 0) { close(nd->zonedev_fd); nd->zonedev_fd = -1; }
		if (nd->devPtr)		 { aclrtFree(nd->devPtr); nd->devPtr = NULL; }
		td->orig_buffer = NULL;
	} else {
		if (nd->devDst)      { aclrtFree(nd->devDst); nd->devDst = NULL; }
		if (td->orig_buffer) { free(td->orig_buffer); td->orig_buffer = NULL; }
	}
}

/* ------------------------------------------------------------------ */

static void *nds_worker_fn(void *arg)
{
	struct nds_worker  *w  = arg;
	struct nds_data    *nd = w->nd;
	struct thread_data *td = nd->td;
	struct nds_options *o  = td->eo;
	cpu_set_t set;

	if (nd->ctx)
		aclrtSetCurrentContext(nd->ctx);

	CPU_ZERO(&set);
	CPU_SET(w->cpu, &set);
	if (pthread_setaffinity_np(pthread_self(), sizeof(set), &set))
		log_err("ascend_nds: worker %d pin to cpu %d FAILED errno=%d(%s) — "
			"was fio launched under taskset?\n",
			w->idx, w->cpu, errno, strerror(errno));

	log_err("ascend_nds: worker %d cpu_req=%d cpu_actual=%d fd=%d\n",
		w->idx, w->cpu, sched_getcpu(), w->fd);

	for (;;) {
		struct io_u *io_u;
		ssize_t n;

		pthread_mutex_lock(&nd->sq_lock);
		while (!nd->sq_cnt && !nd->stop)
			pthread_cond_wait(&nd->sq_cv, &nd->sq_lock);
		if (!nd->sq_cnt && nd->stop) {
			pthread_mutex_unlock(&nd->sq_lock);
			break;
		}
		io_u = nd->sq[nd->sq_head];
		nd->sq_head = (nd->sq_head + 1) % nd->sq_size;
		nd->sq_cnt--;
		pthread_mutex_unlock(&nd->sq_lock);

		/* fio computes io_u->buf as PTR_ALIGN(orig_buffer,page)+mem_align.
		 * A nonzero mem_align would push every buffer off 4K alignment
		 * inside the BAR4 mapping and break O_DIRECT confusingly. */
		if (((uintptr_t)io_u->xfer_buf & 4095) && !nd->align_warned) {
			nd->align_warned = 1;
			log_err("ascend_nds: xfer_buf %p is not 4K-aligned "
				"(mem_align set?) — O_DIRECT will fail\n", io_u->xfer_buf);
		}

		if (io_u->ddir == DDIR_WRITE)
			n = pwrite(w->fd, io_u->xfer_buf, io_u->xfer_buflen, io_u->offset);
		else
			n = pread(w->fd, io_u->xfer_buf, io_u->xfer_buflen, io_u->offset);

		if (n != (ssize_t)io_u->xfer_buflen) {
			io_u->error = (n < 0) ? errno : EIO;
			io_u->resid = io_u->xfer_buflen - ((n < 0) ? 0 : (unsigned long long)n);
			log_err("ascend_nds: w%d %s n=%zd want=%llu off=%llu errno=%d(%s)\n",
				w->idx, (io_u->ddir == DDIR_WRITE) ? "pwrite" : "pread",
				n, (unsigned long long)io_u->xfer_buflen,
				(unsigned long long)io_u->offset, errno, strerror(errno));
		} else {
			io_u->error = 0;
			io_u->resid = 0;
			if (o->mode == NDS_MODE_BOUNCE) {
				size_t off = (char *)io_u->xfer_buf - (char *)td->orig_buffer;
				aclError r = aclrtMemcpy((char *)nd->devDst + off, io_u->xfer_buflen,
							 io_u->xfer_buf, io_u->xfer_buflen,
							 ACL_MEMCPY_HOST_TO_DEVICE);
				if (r) {
					log_err("ascend_nds: w%d aclrtMemcpy H2D=%d\n", w->idx, r);
					io_u->error = EIO;
				}
			}
		}

		pthread_mutex_lock(&nd->cq_lock);
		nd->cq[nd->cq_cnt++] = io_u;
		pthread_cond_signal(&nd->cq_cv);
		pthread_mutex_unlock(&nd->cq_lock);
	}
	return NULL;
}

static int nds_start_workers(struct thread_data *td, struct fio_file *f)
{
	struct nds_options *o = td->eo;
	struct nds_data *nd = td->io_ops_data;
	int i, flags;

	if (nd->workers_started)
		return 0;

	flags = (o->mode == NDS_MODE_P2PW) ? O_RDWR : O_RDONLY;
	if (td->o.odirect)
		flags |= O_DIRECT;

	for (i = 0; i < nd->nworkers; i++)
		nd->w[i].fd = -1;

	for (i = 0; i < nd->nworkers; i++) {
		struct nds_worker *w = &nd->w[i];

		w->nd  = nd;
		w->idx = i;
		w->cpu = (int)(o->cpu_base + (unsigned int)i * o->cpu_stride);

		/* private fd per worker: the proven-linear 24-stream config had
		 * 24 independent open()s; a shared struct file across 24 threads
		 * on this path is unproven. */
		w->fd = open(f->file_name, flags);
		if (w->fd < 0) {
			log_err("ascend_nds: worker %d open(%s)=%d(%s)\n",
				i, f->file_name, errno, strerror(errno));
			goto err;
		}
	}

	nd->workers_started = 1;	/* set before create so stop_workers can
					 * reap partial starts */
	for (i = 0; i < nd->nworkers; i++) {
		if (pthread_create(&nd->w[i].th, NULL, nds_worker_fn, &nd->w[i])) {
			log_err("ascend_nds: pthread_create(%d) failed errno=%d(%s)\n",
				i, errno, strerror(errno));
			goto err;
		}
		nd->w[i].started = 1;
	}

	log_err("ascend_nds: %d workers, cpu_base=%u cpu_stride=%u (%s axis)\n",
		nd->nworkers, o->cpu_base, o->cpu_stride,
		(o->cpu_stride >= 8) ? "WIDTH/distinct-queue" : "DEPTH/shared-queue");
	return 0;

err:
	nds_stop_workers(nd);
	return 1;
}

/* ------------------------------------------------------------------ */

static enum fio_q_status fio_nds_queue(struct thread_data *td, struct io_u *io_u)
{
	struct nds_data *nd = td->io_ops_data;

	fio_ro_check(td, io_u);	/* enforces read-only at the queue layer too */

	pthread_mutex_lock(&nd->sq_lock);
	if (nd->sq_cnt >= nd->depth) {
		pthread_mutex_unlock(&nd->sq_lock);
		return FIO_Q_BUSY;
	}
	nd->sq[nd->sq_tail] = io_u;
	nd->sq_tail = (nd->sq_tail + 1) % nd->sq_size;
	nd->sq_cnt++;
	pthread_cond_signal(&nd->sq_cv);
	pthread_mutex_unlock(&nd->sq_lock);

	return FIO_Q_QUEUED;
}

/* Workers are woken directly by queue(), so commit has nothing to do. Kept
 * non-NULL so behaviour never depends on iodepth_batch. */
static int fio_nds_commit(struct thread_data *td)
{
	(void)td;
	return 0;
}

static int fio_nds_getevents(struct thread_data *td, unsigned int min,
			     unsigned int max, const struct timespec *t)
{
	struct nds_data *nd = td->io_ops_data;
	struct timespec abs;
	int n;

	if (t) {	/* fio passes a RELATIVE timeout */
		clock_gettime(CLOCK_REALTIME, &abs);
		abs.tv_sec  += t->tv_sec;
		abs.tv_nsec += t->tv_nsec;
		if (abs.tv_nsec >= 1000000000L) {
			abs.tv_sec++;
			abs.tv_nsec -= 1000000000L;
		}
	}

	pthread_mutex_lock(&nd->cq_lock);
	while (nd->cq_cnt < (int)min) {
		if (!t) {
			pthread_cond_wait(&nd->cq_cv, &nd->cq_lock);
		} else {
			if (pthread_cond_timedwait(&nd->cq_cv, &nd->cq_lock, &abs) == ETIMEDOUT)
				break;
		}
	}

	n = nd->cq_cnt;
	if (n > (int)max)
		n = (int)max;
	if (n > 0) {
		memcpy(nd->ev, nd->cq, (size_t)n * sizeof(struct io_u *));
		if (n < nd->cq_cnt)
			memmove(nd->cq, nd->cq + n,
				(size_t)(nd->cq_cnt - n) * sizeof(struct io_u *));
		nd->cq_cnt -= n;
	}
	pthread_mutex_unlock(&nd->cq_lock);

	nd->ev_cnt = n;
	return n;
}

static struct io_u *fio_nds_event(struct thread_data *td, int event)
{
	struct nds_data *nd = td->io_ops_data;

	if (event < 0 || event >= nd->ev_cnt)
		return NULL;
	return nd->ev[event];
}

/* ------------------------------------------------------------------ */

static int fio_nds_open(struct thread_data *td, struct fio_file *f)
{
	int ret = generic_open_file(td, f);

	if (ret)
		return ret;
	if (nds_start_workers(td, f)) {
		int cret = generic_close_file(td, f);
		(void)cret;
		return 1;
	}
	return 0;
}

static int fio_nds_close(struct thread_data *td, struct fio_file *f)
{
	nds_stop_workers(td->io_ops_data);
	return generic_close_file(td, f);
}

static void fio_nds_cleanup(struct thread_data *td)
{
	struct nds_options *o = td->eo;
	struct nds_data *nd = td->io_ops_data;

	if (!nd)
		return;

	nds_stop_workers(nd);

	pthread_cond_destroy(&nd->sq_cv);
	pthread_cond_destroy(&nd->cq_cv);
	pthread_mutex_destroy(&nd->sq_lock);
	pthread_mutex_destroy(&nd->cq_lock);
	free(nd->sq);
	free(nd->cq);
	free(nd->ev);
	free(nd->w);

	if (nd->dev_set)    aclrtResetDevice(o->devid);
	if (nd->acl_inited) aclFinalize();
	free(nd);
	td->io_ops_data = NULL;
}

struct ioengine_ops ioengine = {
	.name        = "ascend_nds",
	.version     = FIO_IOOPS_VERSION,
	.flags       = FIO_NOEXTEND,	/* FIO_SYNCIO dropped — engine is async */
	.setup       = fio_nds_setup,
	.init        = fio_nds_init,
	.queue       = fio_nds_queue,
	.commit      = fio_nds_commit,
	.getevents   = fio_nds_getevents,
	.event       = fio_nds_event,
	.cleanup     = fio_nds_cleanup,
	.open_file   = fio_nds_open,
	.close_file  = fio_nds_close,
	.get_file_size = generic_get_file_size,	/* P0-7: without this fio treats
						 * the target as absent and
						 * truncates + relays it out */
	.iomem_alloc = fio_nds_iomem_alloc,
	.iomem_free  = fio_nds_iomem_free,
	.options     = options,
	.option_struct_size = sizeof(struct nds_options),
};
