#!/bin/bash
cd /home/t00906153/Mooncake/mooncake-transfer-engine
echo '=== rpc_communicator CMakeLists ==='
cat src/transport/rpc_communicator/CMakeLists.txt 2>/dev/null | head -20
echo '=== who references rpc_communicator ==='
grep -rn 'rpc_communicator' src/ CMakeLists.txt tent/ 2>/dev/null | grep -v rpc_communicator/CMakeLists | head -10
echo '=== python3-devel check ==='
rpm -q python3-devel 2>/dev/null || echo "python3-devel NOT installed"
ls /usr/include/python3.11/Python.h 2>/dev/null || echo "Python.h missing"
echo '=== yum available? ==='
which dnf yum 2>/dev/null
echo '=== tent CMakeLists entry ==='
grep -rn 'tent' CMakeLists.txt | head -10