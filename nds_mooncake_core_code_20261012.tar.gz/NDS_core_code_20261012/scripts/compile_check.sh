#!/bin/bash
source /usr/local/Ascend/cann/set_env.sh 2>/dev/null || true
T=/home/t00906153/Mooncake/mooncake-transfer-engine/tent
echo "=== check C++ standard in cmake ==="
grep -rn 'CXX_STANDARD\|cxx_std\|CMAKE_CXX_STANDARD' /home/t00906153/Mooncake/mooncake-common/common.cmake 2>/dev/null | head -5
echo "=== try compile with c++20 ==="
g++ -std=c++20 -c -fPIC \
  -I$T/include \
  -I/usr/local/Ascend/cann/include \
  -I/usr/local/include \
  -I/usr/include \
  -o /tmp/nds_transport.o \
  $T/src/transport/nds/nds_transport.cpp 2>&1 | head -60
echo "compile exit=$?"
ls -l /tmp/nds_transport.o 2>&1