#!/bin/bash
S=/root/tomer/nds/runtime-v9.0.0/build/_CPack_Packages/makeself_staging/runtime/lib
echo '=== nm libacl_rt.so P2P ==='
nm -D $S/libacl_rt.so 2>/dev/null | grep -i p2p
echo '=== nm libruntime.so P2P ==='
nm -D $S/libruntime.so 2>/dev/null | grep -i 'P2P\|MapHost' | head -20
echo '=== nm libacl_rt_impl.so P2P ==='
nm -D $S/libacl_rt_impl.so 2>/dev/null | grep -i 'P2P\|MapHost' | head -20
echo '=== grep all staging for MapHost ==='
for f in $S/*.so; do
  c=$(nm -D "$f" 2>/dev/null | grep -ic 'MapHost\|P2PMap')
  if [ "$c" -gt 0 ]; then
    echo "$f: $c matches"
    nm -D "$f" 2>/dev/null | grep -i 'MapHost\|P2PMap' | head -5
  fi
done
echo '=== acl_rt.h P2P lines ==='
grep -n 'P2P\|p2p' /usr/local/Ascend/cann/include/acl/acl_rt.h 2>/dev/null | head -10
echo '=== runtime-v9 source grep P2P ==='
grep -rn 'aclrtMemP2P\|aclrtRegisterP2P' /root/tomer/nds/runtime-v9.0.0/src/ 2>/dev/null | grep -i 'map\|register\|unmap\|unregister' | head -20