#!/bin/bash
cd /home/t00906153/Mooncake
source /usr/local/Ascend/cann/set_env.sh 2>/dev/null || true

echo "=== init pybind11 submodule ==="
ls extern/pybind11/CMakeLists.txt 2>/dev/null && echo "pybind11 has content" || {
  echo "pybind11 empty, trying submodule update..."
  git submodule update --init extern/pybind11 2>&1 | tail -5
  echo "submodule exit=$?"
}
ls extern/pybind11/CMakeLists.txt 2>/dev/null && echo "pybind11 OK" || echo "pybind11 STILL EMPTY"

echo "=== cmake configure ==="
rm -rf build_nds
mkdir -p build_nds
cd build_nds
cmake ../mooncake-transfer-engine \
  -DUSE_ASCEND=ON \
  -DUSE_NDS=ON \
  -DUSE_TENT=ON \
  -DBUILD_UNIT_TESTS=OFF \
  -DCMAKE_BUILD_TYPE=Release \
  2>&1 | tail -50
echo "cmake exit=$?"