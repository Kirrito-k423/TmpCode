#!/bin/bash
OBJ=$(find /home/t00906153/Mooncake/build_nds -name 'nds_transport.cpp.o' | head -1)
echo "=== obj: $OBJ ==="
echo '=== P2P symbols in obj ==='
nm -C "$OBJ" 2>/dev/null | grep -i 'P2PMap\|P2PUnmap'
echo '=== git commit cmake changes ==='
cd /home/t00906153/Mooncake
git add mooncake-transfer-engine/tent/src/CMakeLists.txt mooncake-transfer-engine/tent/src/transport/nds/CMakeLists.txt mooncake-common/FindYLT.cmake
git commit -m 'build(tent/nds): self-contained USE_NDS cmake wiring

- USE_NDS enables the backend standalone (no USE_ASCEND/MPI needed)
- ACL headers located via find_path; runtime P2P symbols come from
  the NDS staging libraries via LD_PRELOAD, not link time
- tent_link_group includes tent_xport_nds' 2>&1 | tail -3
echo '=== log ==='
git log --format='%h %an %s' -3