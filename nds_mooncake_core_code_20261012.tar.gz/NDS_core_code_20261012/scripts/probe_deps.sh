#!/bin/bash
cd /home/t00906153/Mooncake
echo '=== .gitmodules ==='
cat .gitmodules 2>/dev/null
echo '=== FindYLT.cmake ==='
cat mooncake-common/FindYLT.cmake 2>/dev/null | head -40
echo '=== common.cmake ylt context (670-690) ==='
sed -n '665,695p' mooncake-common/common.cmake 2>/dev/null
echo '=== system ylt version ==='
ls /usr/local/include/ylt/ 2>/dev/null | head -8
ls /usr/local/include/async_simple/ 2>/dev/null | head -5
echo '=== yalantinglibs cmake config installed? ==='
find /usr/local -name 'ylt-config.cmake' -o -name 'YLTConfig.cmake' 2>/dev/null | head -3
echo '=== Dependencies.cmake (transfer engine) ==='
cat cmake/Dependencies.cmake 2>/dev/null | head -30