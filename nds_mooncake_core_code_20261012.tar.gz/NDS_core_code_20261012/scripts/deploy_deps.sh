#!/bin/bash
set -e
cd /home/t00906153/Mooncake

echo '=== deploy pybind11 to extern/ ==='
rm -rf extern/pybind11
mkdir -p extern/pybind11
tar xzf /tmp/pybind11.tar.gz -C /tmp/
cp -r /tmp/pybind11-58c382a8e3d7081364d2f5c62e7f429f0412743b/* extern/pybind11/
ls extern/pybind11/CMakeLists.txt && echo "pybind11 deployed OK"

echo '=== verify ylt tarball sha256 ==='
SHA=$(sha256sum /tmp/yalantinglibs.tar.gz | awk '{print $1}')
echo "actual:   $SHA"
echo "expected: 2a4b93c256c09fa84e1507bf4d5b33571ee47a4e2c65316ca255680ad3cdfc1e"

echo '=== patch FindYLT.cmake to use local file ==='
F=mooncake-common/FindYLT.cmake
cp $F ${F}.bak
sed -i "s|URL \${GH_MIRROR}https://github.com/alibaba/yalantinglibs/archive/\${YLT_COMMIT}.tar.gz|URL file:///tmp/yalantinglibs.tar.gz|" $F
grep -n 'URL ' $F
echo 'patched OK'