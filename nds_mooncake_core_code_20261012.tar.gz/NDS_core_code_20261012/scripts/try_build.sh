#!/bin/bash
set -e
cd /home/t00906153/Mooncake
source /usr/local/Ascend/cann/set_env.sh 2>/dev/null || true

echo "=== checking deps ==="
ldconfig -p 2>/dev/null | grep -q glog && echo "glog: found" || echo "glog: MISSING"
ldconfig -p 2>/dev/null | grep -q jsoncpp && echo "jsoncpp: found" || echo "jsoncpp: MISSING"
pkg-config --exists glog 2>/dev/null && echo "glog-pc: found" || echo "glog-pc: MISSING"
cmake --version 2>&1 | head -1

echo "=== checking existing build ==="
ls -d /home/t00906153/Mooncake/build* 2>/dev/null || echo "no build dir"

echo "=== checking ascend includes ==="
ls /usr/local/Ascend/cann/include/acl/acl.h 2>&1
ls /usr/local/Ascend/cann/include/acl/acl_rt.h 2>&1

echo "=== try cmake configure (transfer engine only) ==="
mkdir -p /home/t00906153/Mooncake/build_nds
cd /home/t00906153/Mooncake/build_nds
cmake ../mooncake-transfer-engine \
  -DUSE_ASCEND=ON \
  -DUSE_NDS=ON \
  -DUSE_TENT=ON \
  -DCMAKE_BUILD_TYPE=Release \
  2>&1 | tail -40
echo "cmake exit=$?"