#!/bin/bash
source /usr/local/Ascend/cann/set_env.sh 2>/dev/null || true
T=/home/t00906153/Mooncake/mooncake-transfer-engine/tent
echo "=== verify file exists ==="
ls -la $T/src/transport/nds/nds_transport.cpp
echo "=== syntax check ==="
g++ -std=c++17 -fsyntax-only \
  -I$T/include \
  -I/usr/local/Ascend/cann/include \
  -I/usr/include \
  $T/src/transport/nds/nds_transport.cpp 2>&1 | head -50
echo "syntax exit=$?"