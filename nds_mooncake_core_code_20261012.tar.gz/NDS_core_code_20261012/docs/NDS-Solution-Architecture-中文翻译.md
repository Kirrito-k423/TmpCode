﻿# NPU 直接存储（NDS）— 解决方案架构

> 本文件为 `NDS - Solution Architecture.docx`（Issue 1.0，2026-07-13）的中文逐行翻译汇总。技术术语保留英文原词，描述性文本译为中文。

---

## 封面

**NPU Direct Storage (NDS)**
**Solution Architecture**

Zero-Copy PCIe Peer-to-Peer DMA between the Huawei DPU and Ascend NPU HBM
（华为 DPU 与昇腾 NPU HBM 之间的零拷贝 PCIe P2P DMA）

- Issue 1.0
- Date: 2026-07-13
- Huawei Technologies Co., Ltd.
- All Rights Reserved

---

## 修订历史

| Issue | Date | Description | Author |
|-------|------|-------------|--------|
| 1.0 | 2026-07-13 | Initial release.（初始发布。） | Tomer Cigler、Ben Ben Ishay、Boris Kleiman、Yaron Mor |

---

## 目录

1. **FSaaS 项目：介绍与动机** … 8
   - DPU 高层设计 … 8
   - DPU 文件系统卸载 — 动机 … 8
   - 1.3 VirtIO、virtio-fs 与 FUSE 简介 … 9
     - 什么是 VirtIO？… 9
       - Virtio 接口 … 10
       - Virtqueue (VQ) … 10
       - Virtio 设备 … 10
     - 什么是 VirtIO-fs？… 11
       - 什么是 FUSE？… 12
   - 1.4 FSaaS：由 DPU 提供的文件系统 … 12
2. **NPU 直接存储（NDS）：介绍** … 14
   - 2.1 问题 … 14
   - 2.2 NDS 目标 … 14
   - 2.3 面向应用的模型 … 14
   - 2.4 预期价值 … 15
3. **NDS 解决方案工作块** … 16
   - 3.1 块 A：主机侧 P2P 使能 … 16
   - 3.2 块 B：DPU 存储数据面 … 16
   - 3.3 块 C：DAOS 零拷贝后端 … 16
4. **高层架构** … 17
   - 4.1 架构栈与变更边界 … 17
   - 4.2 端到端零拷贝愿景 … 18
   - 4.3 组件角色 … 19
   - 4.4 设计原则：传输层无 NDS 代码 … 19
   - 4.5 主数据面流程 … 20
6. **块 A：主机侧内核路径** … 22
   - 6.1 设计依据 — 为何 PCIe P2P、为何 ZONE_DEVICE、为何打补丁 FUSE … 22
   - 6.2 FUSE / VFS … 22
   - 6.3 Virtio-FS / Virtio-PCI … 23
   - 6.4 暴露现有 NPU HBM 用于直接 I/O … 23
   - 6.5 昇腾内核空间驱动 … 25
   - 6.6 应用层示例：前后对比 … 26
7. **块 B：DPU 平台（增强 UDAA 与 FSaaS）** … 29
   - 7.1 UDAA — 统一 DPU 架构 API … 29
     - 7.1.1 什么是 UDAA … 29
     - 7.1.2 它解决的问题 … 29
     - 7.1.3 UDAA 解决方案与价值 … 29
     - 7.1.4 UDAA 能带来什么 … 29
     - 7.1.5 目标用例 … 30
     - 7.1.6 架构一览 … 30
     - 7.1.7 库的逻辑结构 … 30
   - 7.2 增强 UDAA 及其对 NDS 的价值 … 31
     - 7.2.1 增强 UDAA 工作概述 … 31
     - 7.2.2 如何加速 NDS 项目 … 32
     - 7.2.3 增强 UDAA 设计与实现 … 32
     - 7.2.4 性能证据 … 33
     - 7.2.5 小结 … 35
   - 7.3 跨 PCIe 内存映射（DPU 侧）… 35
8. **块 C：UDAA-DAOS 零拷贝后端** … 38
   - 8.1 概述 … 38
   - 8.2 DAOS 后端 — 以及为何选择 DAOS … 38
   - 8.3 库组成 … 39
   - 8.4 DAOS / Mercury 集成 … 40
   - 8.5 启动顺序与线程模型 … 40
   - 8.6 每请求生命周期与处理器清单 … 42
   - 8.7 FUSE_INIT 能力协商 … 42
   - 8.8 多租户隔离、缓存与 Unlink 状态机 … 43
   - 8.9 批量数据路径：DMA 对比零拷贝 … 44
   - 8.10 配置面与故障模型 … 46
   - 8.11 性能：DMA 对比零拷贝 … 46
9. **实测解决方案性能** … 48
   - 9.1 测量范围与阅读指南 … 48
   - 9.2 按传输大小与并发度的吞吐 … 48
   - 9.3 对主机内存压力的韧性 … 49
   - 9.4 本地 NVMe 路径 … 49
   - 9.5 可重复性 … 50
   - 9.6 多 NPU 并行加载 … 50
- **附录 A — 术语表** … 52
- **附录 B — UDAA 平台定位（背景）** … 54
- **附录 C — 相关文档** … 55

---

## 图目录

- **图 1**：在 FSaaS 下，主机将一个未修改的内核内置驱动绑定到它视为普通 PCIe 硬件的设备上。所有文件系统软件运行在 DPU 上。… 13
- **图 2**：NDS 从存储到 NPU 的路径中移除了 DPU-DRAM 与主机 DRAM 暂存：三次内存落地变为一次。… 14
- **图 3**：NDS 工作块及其详细章节。… 16
- **图 4a**：设置：启动时注册与缓冲区注册。… 17
- **图 4b**：稳态数据路径：直接读写 NPU HBM。… 18
- **图 5**：一个只产生一次的地址端到端传播：控制路径沿栈下行，而载荷只穿越一次网络。… 18
- **图 6**：从应用缓冲区到 NPU HBM 的直接 I/O 函数流程 … 20
- **图 7**：数据面流程显式失败、绝不静默：未对齐在 FUSE 返回 -EINVAL，不可路由对在 DMA 映射返回 -EREMOTEIO。… 21
- **图 8**：注册增加一个主机可用视图，不引入新的分配权限：分配仍走现有未修改路径。… 24
- **图 9**：一次 HBM 分配，两个虚拟地址。aclrtMalloc(..., ACL_MEM_MALLOC_HUGE_FIRST_P2P) 创建 NPU 计算指针；预期的 aclrtRegisterP2P() API 在同一物理 HBM 上创建第二个主机可用直接 I/O 映射。… 25
- **图 10**：每交付字节对应的主机内存流量，对照暂存路径不可避免的 2.00 下限。… 28
- **图 11**：华为 DPU 架构：SPU 软件域与 NPU 硬件/数据搬运域 … 30
- **图 12**：UDAA 的逻辑分层与核心构建块。… 31
- **图 13**：DPU 数据面可扩展性证据 [已验证，基础级]：单 virtio-fs-function 吞吐 vs. 块大小（fio，passthrough 后端）。旧的 10GB/s 平台被消除。非端到端 NDS 结果。… 34
- **图 14**：单一地址形式跨越两个内存域：GPA 标志位选择主机（VFID + GPA）或 DPU 本地寻址。… 36
- **图 15**：带 RDMA 重定向的零拷贝写路径。… 37
- **图 16**：一个守护进程服务多个隔离租户：每个客户 VM 拥有自己的 VirtioFS function、池与命名空间。… 38
- **图 17**：DAOS 在 libfabric 层对称，且超过 eager 阈值的批量传输是原生 RDMA — 零拷贝模式利用的结构钩子。… 39
- **图 18**：启动顺序是正确性契约：ZC 钩子必须在 daos_init() 之前注册，fs_startup 必须在任何 mount 之前。… 41
- **图 19**：每个请求遵循同一条五阶段路径。畸形输入在分发阶段、任何处理器运行之前被拒绝。… 42
- **图 20**：POSIX unlink-while-open 通过每租户回收目录桥接到 DAOS 语义。仅当两个引用计数都归零时才触发清理。… 44
- **图 21**：零拷贝模式完全移除 DPU 侧 ARM memcpy：NIC 直接写入请求的页。… 45
- **图 22**：一次性占位邻居表项将仅用于 bind 的 QP 带到 RTS，从不发送任何包。… 45
- **图 23**：UDAA-DAOS 零拷贝证据 [已验证，组件级]：fio，只读，24 个 job，每点五次重复，100 Gb/s 客户端与 40 Gb/s 服务端 NIC，RAM 支撑的 DAOS 池。零拷贝在 256 KiB、iodepth 8 时领先 28.1%，在 4 KiB 领先 4~9%，在 256 KiB、iodepth 1 时落后 15.3%（此时 DMA 已饱和）。非端到端 NDS 结果。… 47
- **图 24**：直接路径相对暂存路径的吞吐，按传输大小与读者数量。… 49
- **图 25**：随主机内存竞争流量增加的吞吐。… 49
- **图 26**：从本地固态盘读取时直接路径的优势。… 50
- **图 27**：各工作点重复之间的离散度。… 50
- **图 28**：两块 NPU 同时加载：每交付字节的主机内存成本，以及八设备投影。… 51

---

## 表目录

- **表 1**：应用改变了什么、未改变什么 … 14
- **表 2**：NDS 数据路径中的组件角色 … 19
- **表 4**：昇腾内核驱动中的复用与新增 … 25
- **表 5**：第二虚拟地址插入：两种候选机制 … 26
- **表 6**：数据路径对比 … 27
- **表 9**：udaa_fsaas_bridge 库组成 … 39
- **表 10**：对 DAOS 2.6.5.p1 的构建时补丁 … 40
- **表 11**：FUSE 处理器清单 … 42
- **表 12**：协商的 FUSE 能力及其效果 … 43
- **表 13**：缓存清单 … 43
- **表 14**：配置面 … 46
- **表 15**：DMA 与零拷贝读带宽，MiB/s，24 个 job … 47
- **表 20**：术语表 … 52

---

# 1 FSaaS 项目：介绍与动机

本文档描述 NPU 直接存储（NDS）项目。NDS 直接建立在先前的一项工作 —— FSaaS 项目之上，该项目将存储服务放置在数据处理单元（DPU）上。要理解 NDS 设计，读者首先需要了解 DPU 的作用以及 FSaaS 如何使用它。本章给出这一背景。NDS 项目本身在第 2 章介绍。

## DPU 高层设计

华为 DPU 是一种 SmartNIC，自带处理器并能在卡上运行服务。其中两个部分与本文档相关：

- **SPU** 是一组 ARM 核，运行我们的软件，包括 UDAA 框架及其上构建的服务。
- **NPU+MPU**（DPU 内部）是硬件与固件，负责向主机呈现 PCIe 设备、驱动 DMA 引擎并搬运网络流量。

> 关于"NPU"一名需要澄清。DPU 内部，NPU 指 DPU 自身的网络处理单元。它不是昇腾 NPU —— 后者是华为的 AI 加速器，类似于 GPU，其中 N 代表 Neural（神经网络）。NDS 项目针对的是昇腾 NPU。从此处开始，除非另有说明，NPU 均指昇腾 NPU。

## DPU 文件系统卸载 — 动机

随着现代人工智能（AI）工作负载规模扩大，主机 CPU 已成为关键系统瓶颈。在当代集群中，主机处理器被数据预处理、分布式编排和高吞吐加速器喂料的需求严重超订。将这一计算负担与分布式文件系统栈及用户空间守护进程（如 FUSE）的管理叠加，会引入严重的中断开销和频繁的上下文切换。对于 I/O 密集型 AI 操作 —— 如流式传输多 TB 训练数据集、执行同步权重检查点，或处理高并发检索增强生成（RAG）查询 —— 这一开销表现为延迟抖动，最终使昂贵的 GPU 资源饥饿。

本项目通过将整个文件系统栈卸载到数据处理单元（DPU）来解决这些系统性低效。通过将存储 I/O 与主机计算解耦，并向主机呈现标准化虚拟化接口（类似 virtio-fs 范式），该架构对扩展下一代 AI 基础设施至关重要。它通过在三个核心维度上提供关键优势，解决了根本性的架构限制：

- **p99 可预测性与计算最大化**
  将文件系统生命周期卸载到 DPU 可直接回收宝贵的主机 CPU 周期。通过消除主机上 I/O 引起的上下文切换与中断处理，系统对存储操作保证严格的 p99 延迟可预测性。这种确定性 I/O 性能确保 GPU 计算管线保持满载，缓解海量数据摄入或分布式检查点阶段的计算停顿。

- **严格隔离与零信任安全**
  将存储客户端迁移到 DPU 在租户计算域与存储基础设施层之间建立明确的硬件边界。主机 OS 仅与看似标准的本地 PCIe 挂载交互，有效实现了对后端存储网络的空气隔离。该零信任模型隔离故障，并确保被攻破或配置错误的主机无法直接访问底层分布式存储网络。

- **配置简化与主机抽象**
  将文件系统客户端集中在 DPU 上极大简化了主机生命周期管理。基础设施运维方可在 DPU 上统一部署、补丁和管理复杂存储客户端，而无需在主机 OS 上安装专用驱动、内核模块或用户空间依赖。这种硬件级抽象标准化了供给，防止依赖冲突，并显著减少了计算节点的运维面。

## 1.3 VirtIO、virtio-fs 与 FUSE 简介

### 什么是 VirtIO？

VirtIO 规范的最初目的是确保虚拟环境与客户机拥有一种简单、高效、标准且可扩展的虚拟设备机制，而非针对每个环境、每个 OS 或每个厂商的定制机制。该规范由非营利标准组织 OASIS OPEN 的 Virtual I/O Device 技术委员会开发与维护，旨在简化虚拟设备，使其更具可扩展性与可识别性。

VirtIO 是虚拟机（VM） over 主机设备的（软件）抽象层。它是一个接口，允许 VM 通过称为 VirtIO 设备的"更薄"虚拟设备使用其 hypervisor/主机的设备。这些 VirtIO 设备之所以最小化，是因为它们仅以收发数据所必需的最少功能实现。所有其他功能 —— 如设置、维护、与真实物理设备通信等 —— 均由主机处理。

VirtIO 规范（当前版本 v1.2）定义了 VirtIO 设备与驱动必须满足的标准要求，如特性位、状态、配置和通用操作。这意味着无论使用 VirtIO 的环境或 OS 是什么，其实现的核心框架必须相同。VirtIO 兼容多种 hypervisor 与客户 OS。例如 Hyper-V 支持多个版本的 Windows Server、Windows 和 Linux 发行版作为客户 OS 在 VM 中运行。

VirtIO 最初被设计为半虚拟化接口，意味着客户 VM 必须意识到自己运行在虚拟化环境中，以便部署其 VirtIO 驱动与虚拟模拟设备通信（只有这些设备知道自己运行在虚拟化环境中）。半虚拟化场景经过优化，将客户-hypervisor-主机（及返回）之间的切换次数降到最低，以获得合理性能。后来 VirtIO 演进为全虚拟化接口，即在其自身内存空间创建描述符，然后通过单次写操作触发执行。

#### Virtio 接口

VirtIO 接口位于特定 VirtIO 设备驱动与（软件）模拟设备之间。

任何 VirtIO 接口由以下必备部分组成：

- 设备状态字段
- 特性位
- 通知
- 一个或多个 virtqueue

#### Virtqueue (VQ)

VQ 是向/从 VirtIO 设备进行批量数据传输的机制。VQ 是设备消费的客户缓冲区队列 —— 设备从中读取或向其写入。当前 VQ 实现的内存布局是环形内存环，常称为"vring"。

每个 VirtIO 设备可有零个或多个 VQ，例如最简单的 virtio-net 网络设备有 2 个 VQ：一个用于 Tx，另一个用于 Rx。

每个 VQ 最多可由 3 部分组成：

- 描述符区 — 用于描述（由客户）分配的缓冲区
- 驱动区 — 驱动向设备提供的额外数据
- 设备区 — 设备向驱动提供的额外数据

（客户）驱动通过向 VQ 的驱动区添加可用缓冲区，并可选地触发驱动事件（向设备发送"可用缓冲区"通知）来向设备提交请求。设备执行请求，完成后向 VQ 的设备区添加已用缓冲区（将缓冲区标记为"已用"），并可选地触发设备事件（向驱动发送"已用缓冲区"通知）。注意：设备通常不要求以驱动提交的相同顺序使用缓冲区。

#### Virtio 设备

VirtIO 设备是模拟设备，暴露 VirtIO 接口供软件管理与交换信息。VirtIO 设备的主要任务是将来自 VM 外部格式的信号转换为通过 VirtIO 数据面交换所需格式，反之亦然。VirtIO 设备是在主机物理硬件与 VM 之间传递数据的"桥接"机制。

VirtIO 标准定义了 3 种通信"传输"选项：

- PCIe 总线（大多数设备…）
- 内存映射 IO
- S/390 通道 IO（当前两种都不支持时…）

VirtIO 设备的内存布局由配置空间（包含设备状态、特性、通知等）和 VQ（由客户 VM 分配）组成：一个"可用环"（用于来自驱动的新请求）和一个"已用环"（用于设备向驱动返回的完成）。

VirtIO 标准定义了 15 种不同设备类型。其中一些：网络、块、控制台、GPU、套接字、IOMMU、声音、文件系统等。最早的 VirtIO 设备用于网络和磁盘设备驱动。

### 什么是 VirtIO-fs？

VirtIO-fs 是一种共享网络文件系统，允许 VM 访问主机上的目录树。与现有方案不同，它旨在提供本地文件系统语义与性能。VirtIO-fs 由 Red Hat 发起，在 Linux、QEMU、FUSE 和 Kata Containers 开源社区中开发。它专门设计以利用 VM 及其 hypervisor 的局部性。VirtIO-fs 的目标是在共享目录树的多个 VM 之间提供本地文件系统语义。这对轻量 VM 工作负载尤其有用，因为共享卷是必需的。

VirtIO-fs 自 Linux 5.4、QEMU 5.0 和 libvirt 6.2 起在 Linux 主线可用。

为何要新文件系统？该问题的现有方案（如 virtio-9p）基于现有网络协议，未针对虚拟化用例优化。因此，它们性能不如本地文件系统，也不提供某些应用所依赖的语义。

VirtIO-fs 也可视为 VM 与其主机之间的"远程"文件系统。远程文件系统由两大组件组成：

- 传输 — 用于网络通信（如 TCP/IP、USB、RDMA）
- 协议 — 用于文件系统相关操作（如 NFS、MTP、FTP、CIFS）

当 VirtIO-fs 用于 VM 与其本地主机之间时，所用传输为共享内存，协议为 Linux 的 FUSE。

VirtIO-fs 以 FUSE（详见 1.4.2）为基础。VirtIO-fs 设备承载 FUSE 消息，并为传统 FUSE 中不可用的高级特性提供扩展。

VirtIO-fs 的常见用例：与 VM 共享主机目录、FSaaS、在主机上编译、在多个不同 VM 内测试、在 VM 安装时获取文件入 VM、从主机目录启动 VM 等。

#### 什么是 FUSE？

FUSE 是用户空间文件系统框架。它是一种文件系统，其数据和元数据由普通用户空间进程提供。该文件系统可通过内核接口正常访问。FUSE 不依赖网络栈，并暴露丰富的原生 Linux 文件系统接口，使 VirtIO-fs 设备能作为本地文件系统运作。FUSE 可用于 Linux、FreeBSD、OpenSolaris 和 MacOS。FUSE 使非特权（非 root…）用户能创建自己的文件系统，而无需编辑/修改内核代码。

FUSE 组件：

- **fuse.ko** — 可加载的（类 UNIX）内核模块
- **libfuse** — 用户空间库，提供与 fuse.ko 通信的参考实现，并与用户的文件系统实现链接。
- **fusermount** — FUSE 挂载工具

FUSE 协议读取文件的流程示例：

1. FUSE_INIT() 创建会话
2. nodeid = FUSE_LOOKUP(FUSE_ROOT_ID, "foo")  // 注：nodeid 是 inode 的句柄
3. fh = FUSE_OPEN(nodeid, O_RDONLY)  // 注：fh 是打开文件的句柄
4. nbytes = FUSE_READ(fh, offset, &buf, sizeof(buf))

## 1.4 FSaaS：由 DPU 提供的文件系统

选择 virtio-fs 作为卸载接口有四个原因：

- 它是开放的 OASIS 标准，拥有经过验证、活跃开发的生态，因此卸载一个标准 function 可继承该生态并降低采纳风险。
- 它是现有势能的自然下一步：virtio-net/blk/scsi 卸载已在 Hi1823 SmartNIC 上推进。
- 与 virtio-blk 不同，它提供文件级语义、共享目录树、FSaaS、每文件访问控制，并按设计提供本地文件系统性能。
- 主机与客户侧仅需未修改的内核内置 virtio-fs 驱动，这也使 NDS 后续能保持整个 Virtio-FS/Virtio-PCI 层不含 NDS 专有代码（见 4.4 节）。

DPU 文件系统模拟架构基于 virtio-fs 模型，但有一个决定性变化：除客户机的 VirtIO-fs 驱动外，所有软件组件都迁移到 DPU 内运行。DPU 将模拟的 virtio-fs 设备作为 SR-IOV VF 暴露，因此主机及任何客户 VM 都将其视为普通硬件。

virtiofsd 软件结构被 UDAA 框架取代：UDAA 核心（内存管理、工作执行、function 配置）、UDAA emulation_dev（虚拟 function 配置）和 UDAA FSaaS（在 SPU 上实现文件系统的文件系统库，包括一个 passthrough 参考文件系统）。

> 注：UDAA 框架将在第 7 章详述。

**图 1**：在 FSaaS 下，主机将一个未修改的内核内置驱动绑定到它视为普通 PCIe 硬件的设备上。所有文件系统软件运行在 DPU 上。

---

# 2 NPU 直接存储（NDS）：介绍

## 2.1 问题

在华为 AI 服务器平台上，在持久存储与 NPU 内存之间搬运数据正成为 AI 工作负载日益增长的瓶颈。在当前路径上，载荷在到达目的地之前被暂存两次。来自 DAOS 存储集群的 RDMA 传输首先落入 DPU 自身的 DRAM，然后 DPU 的 ARM 核将其继续拷贝。

随后主机再次在主机 DRAM 弹跳缓冲区中暂存数据，主机 CPU 通过显式的 aclrtMemcpy() 将其拷入 NPU HBM。

每次传输都要付出代价：两次全尺寸暂存拷贝、被仅过路数据消耗的主机 RAM 带宽与容量，以及花在数据搬运而非应用工作上的主机 CPU 周期。

## 2.2 NDS 目标

NDS（NPU 直接存储）移除两个暂存点。DPU 支撑的存储设备经 PCIe 将数据直接搬入昇腾 NPU 内存，因此载荷只穿越存储网络一次，且仅落在其最终目的地。它是 NVIDIA GPUDirect Storage 在昇腾生态中的对应物。使之成为可能的机制在第 4 章描述。

**图 2**：NDS 从存储到 NPU 的路径中移除了 DPU-DRAM 与主机 DRAM 暂存：三次内存落地变为一次。

## 2.3 面向应用的模型

数据面接口是普通 POSIX：带 O_DIRECT 的 open/read/write。由于 NDS 不需要 cuFile 式的 I/O 库，现有应用、数据加载器和 AI 框架无需任何改写即可受益。

仅需一个新调用，且它位于数据面之外。aclrtRegisterP2P() 接收一个现有 NPU HBM 分配，并为其返回第二个主机可用地址。原始设备指针与新映射地址只是同一物理 HBM 的两个视图。应用通过第一个进行计算，通过第二个进行文件 I/O。

**表 1**：应用改变了什么、未改变什么

| 方面 | NDS 之前 | 使用 NDS |
|------|----------|----------|
| 数据面接口 | POSIX O_DIRECT read/write | POSIX O_DIRECT read/write（不变） |
| 缓冲区分配 | 现有分配 API | 现有分配 API（不变） |
| 需要的新调用 | 无 | 一次注册调用以暴露 HBM 缓冲区的主机可用视图 |
| 主机 DRAM 暂存缓冲区 | 需要 | 移除 |
| 主机 CPU 拷贝（aclrtMemcpy） | 每次传输都需要 | 从数据路径中移除 |
| 应用 / 框架代码 | — | 无需改写；无新 I/O 库 |

## 2.4 预期价值

此处的价值是结构性的。暂存拷贝消失，主机 RAM 不再被仅过路的数据占用，主机 CPU 退出数据路径。

当前阶段的目标是功能性使能：打通 P2P 路径并展示 CPU 应用从中受益（通过使用 FIO）。更大的性能增益是目标，尚未成为结果。最终目标是高达 5× 的更低延迟、高达 3× 的更高带宽，以及约 5× 的 CPU 利用率优势。

---

# 3 NDS 解决方案工作块

**图 3**：NDS 工作块及其详细章节。

NDS 工作组织为三个块。它们共同构成一条将数据从 DAOS 存储集群搬入昇腾 NPU 内存的路径。该路径避免暂存拷贝，且不在传输本身上花费主机 CPU 周期。每个块拥有该路径的一部分。本章解释每个块是什么以及为何需要它。将各块联系起来的高层架构在第 4 章给出。每个块的详细设计各有其章节，见第 6、7、8 章。

## 3.1 块 A：主机侧 P2P 使能

**动机。** 昇腾 NPU 今天无法直接接收文件数据。主机内核未将 NPU 内存暴露为对等（P2P）PCIe 传输的有效目标。因此每次传输都必须经过主机 DRAM，而该主机 DRAM 拷贝正是 NDS 要移除的。

**描述。** 块 A 是一组主机内核变更，使文件读或写直接落入 NPU 内存。昇腾驱动注册 NPU 内存区域，使内核可将其视为 PCIe 对等目标。FUSE 路径中的小改动使这些区域可作为文件 I/O 的源或目的地。应用仍使用普通 POSIX 文件调用且不改变。第 6 章详述此块。

## 3.2 块 B：DPU 存储数据面

**动机。** DPU 上的数据路径必须精简且可预测。原始 UDAA 数据面绑定于较重的库层与固定队列池。该设计增加了开销并限制了扩展。NDS 需要 DPU 以线速搬运文件数据并为增长保留余量。

**描述。** 块 B 是 DPU 侧基础。FSaaS 呈现主机与之对话的 virtio-fs 设备。增强的 UDAA 框架提供搬运数据的队列与内存机制。增强工作移除了对旧库层的依赖，使队列与内存按需分配，并增加了零拷贝传输所依赖的跨 PCIe 寻址。第 7 章涵盖此块，包括增强的实测效果。

## 3.3 块 C：DAOS 零拷贝后端

**动机。** 文件系统前端只有在背后有真实存储时才有用。后端必须到达 DAOS 集群。在快速路径上，它还必须在不先将批量数据拷入 DPU 内存的情况下搬运它们。

**描述。** 块 C 是 DPU 上的用户空间服务，终止 virtio-fs 流量并从 DAOS 提供服务。它运行在块 B 的增强 UDAA 平台上。其批量数据路径可通过跨 PCIe 映射主机内存来跳过中间拷贝。这是块 A 在主机上打开的直接路径的 DPU 端。第 8 章涵盖此块，包括零拷贝结果。

---

# 4 高层架构

## 4.1 架构栈与变更边界

主机运行应用/AI 框架层与 NDS 主机变更：FUSE 直接 I/O 使能、昇腾 P2P 内存支持，以及 PCI P2P 主机桥白名单。Virtio-FS/Virtio-PCI 保持不变。

**图 4a**：设置：启动时注册与缓冲区注册。

**图 4b**：稳态数据路径：直接读写 NPU HBM。

## 4.2 端到端零拷贝愿景

本文档中的两条轨道 —— 主机内核 P2P 工作（第 6 章）与 DPU 侧 UDAA/DAOS 服务（第 7、8 章）—— 并非在某个缓冲区处缝合在一起的两个独立优化。它们是同一机制：一个由主机内核产生一次的地址，端到端传播，直到硬件将载荷送达该地址。

主机内核的 dma_map_sgtable() 将钉住的 ZONE_DEVICE 页转换为 NPU BAR4 总线地址（若 IOMMU 启用则为 IOVA）。该地址随后沿 virtio 描述符下行到 DPU，经 UDAA 进入 udaa_fsaas_bridge，进入 DAOS 客户端的 SGL，进入零拷贝内存窗口 bind，直到它成为远端 DAOS 服务器持有的字面 RDMA 目标。

控制路径沿栈下行。载荷从不如此。它只移动一次。

**图 5**：一个只产生一次的地址端到端传播：控制路径沿栈下行，而载荷只穿越一次网络。

零拷贝模式承载 NDS 地址。它不是独立的优化。在 DMA 模式下，最后一跳是向目标页的 CPU 拷贝，这对 BAR4 设备内存不适用。因此零拷贝是 NPU 目标的预期工作模式。

## 4.3 组件角色

**表 2**：NDS 数据路径中的组件角色

| 层 | 在 NDS 数据路径中的角色 |
|----|--------------------------|
| 应用 / AI 框架 | 对从 aclrtMalloc 获得的 NPU 虚拟地址发起普通直接 I/O 系统调用（O_DIRECT read/write）。 |
| VFS / FUSE | 通过标准 iov_iter_extract_pages(ITER_ALLOW_P2PDMA) 钉住目标页 —— 与任何 O_DIRECT 请求相同的调用，对 NPU 内存无分支。页的 ZONE_DEVICE/P2P 状态是页自身携带的属性，由昇腾驱动的注册更早设置。 |
| Virtio-FS / Virtio-PCI | 从钉住的页构建散列链表并调用标准的、P2P 感知的内核 DMA 映射 API dma_map_sgtable()。不含 NDS 专有逻辑。 |
| 华为 DPU (Hi1823E) | 在其 ARM 核上运行 FSaaS 存储服务（UDAA → udaa_fsaas_bridge → DAOS 客户端），并承载搬运载荷的 PCIe 引擎 —— 在 ZC 模式下嵌入式 RoCE NIC 的入站 DMA 是朝向 BAR4 的 PCIe 发起者。两种模式下均地址无关（见 4.4 节）。 |
| PCIe 网络 | 根端口、根复合体段以及（若存在）连接两个端点的交换机。 |
| 昇腾 910B NPU | PCIe DMA 目标。HBM 通过 64 GB 可预取 BAR4 窗口暴露，由昇腾主机驱动注册为 ZONE_DEVICE PCI P2P 内存。 |
| DAOS 集群 | 数据所在之处。DAOS 服务器是 RDMA 对端，经 RoCE 对 BAR4 支撑的窗口执行写（文件读）或读（文件写）载荷（见 8.3 节）。 |

## 4.4 设计原则：传输层无 NDS 代码

一个原则支配分层。Virtio-FS/Virtio-PCI 与内核的通用 DMA 映射层完成所有拓扑与 ACS 验证，且不存在 NDS 专有代码。NDS 专有逻辑位于三处：FUSE（钉住页）；昇腾驱动（处理 ZONE_DEVICE 注册与第二视图映射）；以及 PCI 子系统中一条对等主机桥白名单条目。

内核的 DMA 映射核心已在 dma-direct 与 dma-iommu 两种后端中自行评估 ZONE_DEVICE PCI P2P 页的拓扑与 ACS 兼容性。事实上，一旦该处理移入 dma_map_sg()/dma_map_sgtable()，旧的显式 pci_p2pdma_map_sg()/unmap_sg() API 即在上游被移除。图 4a 与 4b 直观地表明：这三个变更点就是 NDS 补丁面的全部。

DPU 侧有匹配的推论。dma_map_sgtable() 不仅是批准传输：它为所选映射类型发出可路由总线地址，virtio 描述符随后像其他任何地址一样携带该 dma_addr_t。

作用于它的 DPU 侧引擎是地址无关的 —— ZC 模式下的嵌入式 RoCE NIC 入站 DMA，以及 DMA 模式下的 DMA 引擎。每个都只是对描述符或 SGL 携带的任何总线地址发出 PCIe 内存 TLP，而不知道它指向主机 DRAM 还是某个对等体的 BAR4。正是这一性质让未修改的 NVMe 控制器在硬件前验证期间能作为内核门控发起者代位。

这对平台的依赖在于网络而非发起者：TLP 必须可对等路由，这由拓扑基线与 ACS 契约治理。在硬件上验证第二虚拟地址映射是对 DPU 发出的 TLP 对 BAR4 的首次真正演练，该验证包括确认 UDAA 重定向映射与 ZC 父 MR 注册覆盖 BAR4 地址范围。

**图 6**：从应用缓冲区到 NPU HBM 的直接 I/O 函数流程。

在零拷贝模式下，DAOS RDMA 操作直接针对 BAR4 支撑的内存窗口。DPU 不在 DPU DRAM 中暂存载荷，也不执行单独的 RDMA 后 PCIe 拷贝；嵌入式 RoCE NIC 向目标 BAR4 地址发出对等定向的 PCIe 事务。

## 4.5 主数据面流程

规范流程从主机到存储再返回。以下是概念序列。确切机制 —— 页钉住、DMA 映射、寻址、RDMA、子 MTU 尾部与页释放 —— 在第 6、8 章规定。

1. 应用以 O_DIRECT 针对 NPU 虚拟地址发起 read()/write()。
2. FUSE 通过 iov_iter_extract_pages(…, ITER_ALLOW_P2PDMA) 钉住目标页 —— 与每个 O_DIRECT 请求相同的调用。无 FUSE 侧"这是否是 NPU 内存"分支。若昇腾驱动已将页注册为 ZONE_DEVICE PCI P2P 页，ITER_ALLOW_P2PDMA 在内部设置 FOLL_PCI_P2PDMA，钉住成功。未对齐请求在此以 -EINVAL 失败。
3. Virtio-FS 构建散列链表并调用标准 dma_map_sgtable()。该调用评估拓扑与 ACS 兼容性并发出可路由总线地址 —— 对 P2P 可行对是 NPU BAR4 总线地址，或若 IOMMU 启用则为 IOVA。不可行对以 -EREMOTEIO 失败。无静默弹跳缓冲区回退。
4. 携带这些 BAR4 地址的请求描述符穿越 virtio 队列到达 DPU，FSaaS 服务在此取走它们：UDAA 取回请求，udaa_fsaas_bridge 分发 FUSE 操作码，处理器以 SGL 段为 BAR4 地址的 dfs_read()/dfs_write() 发起调用（见 8.8 节）。
5. 打补丁的 libdaos 在 IOVA SGL 上强制走批量路径。零拷贝钩子随后在地址范围上 bind 一个内存窗口，并将 rkey 与窗口地址交给 DAOS 服务器（见 8.9 节）。
6. 数据路径，文件读。DAOS 服务器对该窗口发起 RDMA WRITE。DPU 的嵌入式 RoCE NIC 接收它，其入站 DMA 向 NPU BAR4 地址发出 PCIe 内存写 TLP。根复合体将其对等路由入 HBM。文件写是镜像：服务器发起 RDMA READ，NIC 向 BAR4 发出 PCIe 读 TLP，从 HBM 拉取并流向服务器。两个方向上载荷都只穿越存储网络一次，且从不落入任何 DRAM —— 主机或 DPU。
7. 读路径上的子 MTU 尾部。非 MTU 整倍数的尾部片段通过软件尾部路径交付（见 8.9 节）。协商的请求整形保证每请求最多一个此类尾部，位于文件末尾。
8. 完成时，页通过 P2P 感知的释放路径释放（见 6.2 节）：ZONE_DEVICE 页绕过脏账务并以 unpin_user_page() 释放，匹配提取调用的 FOLL_PIN 语义。

**图 7**：数据面流程显式失败、绝不静默：未对齐在 FUSE 返回 -EINVAL，不可路由对在 DMA 映射返回 -EREMOTEIO。

---

# 6 块 A：主机侧内核路径

本章是主机侧 NDS 工作的组件级设计，按层组织，最后以将各部分联系起来的应用层示例收尾。

## 6.1 设计依据 — 为何 PCIe P2P、为何 ZONE_DEVICE、为何打补丁 FUSE

**为何使用 PCIe P2P。** 传输的两个端点 —— DPU 支撑的 Virtio-FS 设备与 NPU 的 BAR4 暴露的 HBM —— 是同一根复合体上的 PCIe 设备。经主机 RAM 路由的每个字节都要付出第二次拷贝、主机 RAM 带宽与容量，以及主机 CPU 周期（见 6.6 节）。P2P DMA 是唯一能同时移除这些的机制。

复用现有 RDMA 对等内存路径的替代方案因范围原因被搁置：它服务于 verbs 消费者，而非未修改 AI 工作负载实际使用的 POSIX 文件 API。

**为何 ZONE_DEVICE（对比现有 remap_pfn_range() P2P 映射）。** 整个标准 O_DIRECT 管线在 struct page 上工作：iov_iter_extract_pages()/GUP 页钉住、散列链表构造，以及 dma_map_sgtable() 的拓扑/ACS 评估。昇腾驱动现有的 ACL_MEM_MALLOC_*_P2P 分配落在正确的 BAR4 物理地址，但它们通过原始 remap_pfn_range() 映射，因此不存在对应的 struct page（见 6.5 节）。这使它们对管线不可见，且无法事后补丁。

在启动时通过 pci_p2pdma_add_resource() 将 BAR4 注册为 ZONE_DEVICE PCI P2P 内存，会创建携带内核 DMA 核心所需 P2P 提供者元数据的真实 struct page。这正是"传输层无 NDS 代码"原则（见 4.4 节）的基础：通用内核可做拓扑验证，因为页本身声明了它们是什么。

因此 NDS 的分配侧工作（见 6.4 节）不是创建这些页，而是给应用一个映射到它们的主机可用虚拟地址。

**为何不用 DMA-BUF。** DMA-BUF 与 remap_pfn_range() 和 ZONE_DEVICE 一同评估后被拒绝。它是用于在内核驱动间共享缓冲区的导出者/导入者框架，例如 GPU 导出到视频解码器。NDS 中的消费者是通用 VFS/FUSE O_DIRECT 路径，它通过标准 POSIX read()/write() 在用户虚拟地址上工作。存储栈中没有任何导入者子系统，因此 read(fd, npuPtr) 无法消费 dma-buf。

强行加入 DMA-BUF 意味着在 Virtio-FS 与 FUSE 内部定制附加管线，这破坏了传输层原则。相比之下，ZONE_DEVICE 将 P2P 路由知识直接嵌入 struct page，让未修改的通用管线完成其工作。

**为何 FUSE 是唯一的主机内核补丁点。** Virtio-fs 的协议是 FUSE，而 FUSE 绕过内核的通用直接 I/O 路径，包括其页钉住行为与对齐检查（见 6.2 节）。因此 O_DIRECT 的 P2P 能力页钉住只能在 FUSE 内部启用，在 fuse_copy_fill() 与 fuse_get_user_pages() 中。下方的每一层已使用通用的、P2P 感知的内核 DMA 映射 API，无需任何改动。

这产生了尽可能小的补丁面：两处调用点替换加上匹配的释放路径变更。

## 6.2 FUSE / VFS

**已提交变更。** FUSE 使能补丁（"Enable P2P DMA support for direct-io operations"）做两处调用点替换：

- fuse_copy_fill() (fs/fuse/dev.c)：iov_iter_get_pages2() 替换为 iov_iter_extract_pages(cs->iter, &page_ptr, PAGE_SIZE, 1, ITER_ALLOW_P2PDMA, &off)。
- fuse_get_user_pages() (fs/fuse/file.c)：相同替换，以 P2P 标志提取到 ap->pages[…]。

ITER_ALLOW_P2PDMA 允许提取路径接受已注册的 PCIe 对等 ZONE_DEVICE 页。内核在钉住它们时内部应用 FOLL_PCI_P2PDMA，因此请求继续通过标准 DMA 映射路径，而非被 get_user_pages_fast() 拒绝并强制拷贝。

**约束。**

- FOLL_LONGTERM 与 FOLL_PCI_P2PDMA 互斥 —— P2P 页不能被长期钉住。
- 对齐契约：针对 NPU P2P 内存的 O_DIRECT 请求必须在偏移与长度上 4 KB 对齐。NDS 在其 FUSE 补丁中显式强制此要求，因为原生 FUSE 不执行任何内核级 O_DIRECT 对齐检查（不同于 FUSE 所绕过的通用直接 I/O 路径）。4 KB 这一数值匹配昇腾驱动的非 huge P2P 池粒度与 NPU 侧的 ATU 对齐。两侧更细的内部粒度是实现细节，不作为面向应用的要求暴露。
- 回退与错误行为：无打开时拒绝（因为打开时目标 NPU 未知），无静默弹跳缓冲区回退。两种每 I/O 失败模式可区分：未对齐请求返回 -EINVAL（NDS 自身的检查）；拓扑或 ACS 不兼容对返回 -EREMOTEIO（来自 dma_map_sgtable()）。

**释放路径语义。** 由于 iov_iter_extract_pages() 以 FOLL_PIN 语义钉住页，fuse_release_user_pages() 中的释放路径相应处理 P2P 页，对它释放的每页以两种方式：

```c
/* fuse_release_user_pages() -- per-page release semantics */
if (should_dirty && !is_zone_device_page(page))
        set_page_dirty_lock(page);  /* ZONE_DEVICE P2P pages bypass
                                       dirty accounting */
unpin_user_page(page);              /* releases the FOLL_PIN taken by
                                       iov_iter_extract_pages() */
```

各元素的理由如下。set_page_dirty_lock() 假定页缓存或匿名内存账务，这不适用于 ZONE_DEVICE PCI P2P 页，因此需要 is_zone_device_page() 守卫。以 FOLL_PIN 钉住的页携带与其普通 refcount 不同的钉计数，因此 unpin_user_page() 是匹配的释放。验收标准是：在针对 P2P 页的重复 O_DIRECT 读/写周期中无钉计数泄漏或下溢，且对普通页行为不变。此释放路径变更的实现安排在第二映射验证之前。

## 6.3 Virtio-FS / Virtio-PCI

此层不需要也不允许 NDS 专有代码。唯一要求是对所有散列链表（P2P 或非 P2P）使用标准的、当前的 dma_map_sgtable() 调用。此处不添加任何 PCI-P2P 专有代码、设备指针管线或手动距离计算。内核的通用 DMA 映射核心已在内部评估 ZONE_DEVICE PCI P2P 页的拓扑与 ACS 兼容性（在 dma-direct 与 dma-iommu 后端中），这些在 6.6 基线之前早已存在。

- **ACS 处理。** 两种不同情况不可混淆。第一种，P2P 不合格对（即不同根复合体段、无可路由对等路径）被拒绝。dma_map_sgtable() 返回错误，I/O 以 -EREMOTEIO 失败。此情况无弹跳缓冲区回退，即"无静默回退"保证。第二种，P2P 可映射但位于做 ACS 重定向的端口之后的对，由内核现有行为处理。
  映射经主机桥路由并伴有内核诊断而非硬拒绝。这不是主机 DRAM 暂存拷贝，因为载荷仍对等移动。它只是更长的 PCIe 路由。它匹配华为对现有昇腾到昇腾 P2P 的文档立场，即将主机 BIOS 与端口 ACS 使能视为部署时前置条件。
- **IOMMU 与 SMMU 处理。** NDS 依赖同一通用 dma_map_sgtable() 机制，其 dma-iommu 后端原生支持 P2P 页。完整的启用/禁用决策矩阵计划在本文档未来修订中给出。
- **昇腾侧控制面：** 现有 devid 范围的 P2P 控制面（aclrtDeviceCanAccessPeer / aclrtDeviceEnablePeerAccess）不被 NDS 使用 —— 它限定于昇腾 NPU 设备 ID，对非昇腾对端体（如 DPU）无表示。

## 6.4 暴露现有 NPU HBM 用于直接 I/O

**验证路径说明。** 本文档中的实测结果通过字符设备映射路径产生：fio 打开 /dev/davinci_zonedev<N> 并直接映射所选 BAR4 区域。它不调用 aclrtRegisterP2P()。aclrtRegisterP2P() 仍是暴露现有 NPU HBM 分配的主机可用视图的预期产品接口。

**ZONE_DEVICE 注册。** 启动时，按每 NPU，昇腾主机驱动对整个约 64 GB BAR4 窗口调用 pci_p2pdma_add_resource()。这给 BAR4 内的每个物理地址一个内核 struct page，且每设备记录 (bar4_phys, bar4_size, zone_registered) 存于按物理设备 id 索引的每设备窗口表中。这对全部八块 NPU 已在线确认，每设备 BAR4 物理范围正确记录。释放路径在 ACL 层完全透明：aclrtFree() 需要零运行时层变更。

**核心设计决策：注册，不分配。** 与其教驱动一种新的分配方式，NDS 消费现有未修改 aclrtMalloc(…P2P) 已分配并填充的内存，仅产生同一 HBM 的第二个主机 CPU 可用视图。不引入新的分配权限，不产生预留问题。

**为何需要第二视图。** 正常 aclrtMalloc(…P2P) 之后，用户的设备指针无主机页表项，因此主机 CPU 无法通过它加载或存储。其 VMA（来自 SVM 初始化路径）为 VM_PFNMAP 类型，不能携带 FUSE 与 O_DIRECT 所需的 struct-page 映射。

然而该指针背后的物理 HBM 位于启动时注册已用 ZONE_DEVICE struct page 覆盖的 BAR4 窗口内。换言之，内存在物理层是真实的且有 struct page 支撑。只有用户的虚拟地址对主机 I/O 不可用。

同一物理内存上的第二个、类型正确的虚拟地址解决此问题。且由于原始映射以原始 PFN 在 VM_PFNMAP VMA 上建立，它无法就地重新装饰 —— 独立的第二 VMA 是必需的，而非捷径。

**新 API。** 用户最终持有同一 HBM 的两个句柄：用于 NPU 计算与其他 ACL 调用的原始设备指针，以及用于 POSIX / O_DIRECT 的新映射虚拟地址。由于调用者必须有意识地正确使用正确句柄，第二地址通过新的公开运行时 API 作为一等值返回：

```c
aclError aclrtRegisterP2P(void *devPtr, size_t size, aclrtP2PRegInfo *out);
aclError aclrtUnregisterP2P(void *devPtr);
```

此注册沿与其他运行时调用相同的三代码库栈下行：ACL/CANN 运行时，然后用户空间 HAL 驱动，然后内核驱动，并在每层紧密参照现有 aclrtMemAdvise 分发路径建模，因此它继承既有的装饰器、错误与性能分析跳数，而非引入新的分发形状。

**图 8**：注册增加一个主机可用视图，不引入新的分配权限：分配仍走现有未修改路径。

**图 9**：一次 HBM 分配，两个虚拟地址。aclrtMalloc(..., ACL_MEM_MALLOC_HUGE_FIRST_P2P) 创建 NPU 计算指针；预期的 aclrtRegisterP2P() API 在同一物理 HBM 上创建第二个主机可用直接 I/O 映射。

**字符设备映射路径。** 映射处理器不重新推导地址逻辑。它调用现有的、已导出的、自锁的生产步行器（devmm_get_mem_pa_list）—— 机组已在运行它将设备虚拟地址范围转换为主机可用物理地址，包括将缓存的设备物理地址转为主机可见 BAR 地址的强制设备到主机翻译，以及防止并发 aclrtFree 的页引用。

在此之上，处理器添加只读诊断：对每个返回的物理地址，它针对所有已注册 BAR4 窗口的并集测试成员关系（而非信任调用者提供的设备 id），然后仅对匹配地址检查 pfn_valid()，最后 is_zone_device_page()。此顺序故意防错 —— 范围检查、然后 pfn_valid、然后 struct-page 访问，绝不反过来 —— 因此缓存未命中、翻译失败或越界地址都是被记录的跳过，绝非故障。

## 6.5 昇腾内核空间驱动

注册处理器本身已在上面介绍。关于周围内核驱动的以下事实塑造了设计，并已从源码确认。下表区分 NDS 不变复用什么、新增什么：

**表 4**：昇腾内核驱动中的复用与新增

| 不变复用（现有、已导出代码） | NDS 新增 |
|------------------------------|----------|
| 生产 VA→主机物理步行器（devmm_get_mem_pa_list / devmm_put_mem_pa_list），自锁，含强制设备到主机翻译与页引用 | 注册处理器外壳及其 (file, arg) 分发包装器 |
| 启动时 BAR4 ZONE_DEVICE 注册与每设备窗口表 | 请求上的 2 MB 对齐与仅 P2P 验证 |
| 堆与页位图查找（devmm_svm_get_heap, devmm_get_page_bitmap_with_heap） | 窗口并集诊断及其日志 |
| is_zone_device_page() / pfn_valid() | |

设计所纳入的关于驱动环境的额外事实：

- **访问门。** /dev/devmm_svm 注册了两套处理器集。任意程序的原始 open() 命中其 .open 返回 -EACCES 的处理器集。真正访问仅通过库初始化执行的注册路径获得 —— 这正是注册调用通过正常 HAL 文件描述符工作、且验证以真实 ACL 进程而非独立 ioctl 框架运行的原因。
- **专用 VMA 所有权。** 驱动唯一的现有 .mmap 处理器无条件设置 VM_PFNMAP 且专用于 SVM 初始化。向 VM_PFNMAP VMA 执行 vm_insert_page() 按内核契约非法。因此注册路径在它控制的新代码中创建自己的 VM_MIXEDMAP VMA，将 VMA 类型控制完全保持在 NDS 内部，不触碰任何共享处理器。
- **构建目标纪律。** 新主机侧代码从主树构建入活跃主机模块（drv_devmm_host.ko）。同名源文件存在于构建入不同模块的若干树中，因此构建目标被显式钉住。
- **现有 P2P 页无 struct page。** 正常 …P2P 分配落在正确 BAR4 物理地址，但以原始 remap_pfn_range() 映射，因此该映射上无 struct page —— 这正是需要第二 struct-page 支撑视图而非就地变更的原因。

**表 5**：第二虚拟地址插入：两种候选机制

| 维度 | 主方案：仅主机插入 | 回退：设备远端映射 |
|------|---------------------|---------------------|
| 机制 | 将启动时注册的 ZONE_DEVICE 页插入自有的 VM_MIXEDMAP VMA | 驱动现有计数的、硬件窗口支撑的设备路径 |
| 设备消息 | 无 | 每注册一次设备 map / unmap |
| 硬件窗口资源 | 不消耗 | 消耗；槽耗尽时注册可失败 |
| 支撑证据 | 上游 p2pmem sysfs 路径已在此硬件上做双向 O_DIRECT | 演练一条经证明的、计数的设备路径 |
| 注销拆卸 | 丢弃映射 | 丢弃映射并驱动设备 unmap |
| 决定者 | 硬件上的开放问题：插入的 BAR4 页的主机 CPU 访问能否在无活跃设备窗口时成功？ | 若主路径未通过该测试则选用 |

**第二虚拟地址映射决策。** 第二虚拟地址插入有两种候选机制，均从源码完整阅读。在主设计中（仅主机插入），注册处理器将已注册的 ZONE_DEVICE struct page 插入其自己的 VM_MIXEDMAP VMA。不涉及设备消息与硬件窗口资源。支撑证据是上游 p2pmem sysfs 路径（纯启动时注册、无设备远端映射）已确认在此硬件上做双向 O_DIRECT。

回退方案（设备远端映射）驱动一条现有的、计数的、硬件窗口支撑的设备路径。那将扩展 API 契约：窗口槽耗尽时注册可失败，注销将驱动设备 unmap。

一个问题决定二者：插入的 ZONE_DEVICE BAR4 页的主机 CPU 访问能否在无活跃设备侧窗口时成功？通过在硬件上构建并运行来回答。设计承诺主路径并保持回退完全映射，因此无论硬件如何回答，契约与拆卸均已理解。

## 6.6 应用层示例：前后对比

第 2 章两条路径的代码级呈现。两种情况下 DPU 侧服务相同。变化的仅是载荷所走的主机侧路径。

**NDS 之前，读路径（主机 RAM 弹跳缓冲区）。**

```c
// 1. Allocate a host-side staging buffer -- the bounce buffer.
void *hostBuf = nullptr;
aclrtMallocHost(&hostBuf, size);

// 2. Read file content from the Virtio-FS mounted file into host RAM.
int fd = open("/mnt/virtiofs/dataset.bin", O_RDONLY);
read(fd, hostBuf, size);                        // DPU -> host RAM (copy #1)
close(fd);

// 3. Allocate NPU HBM and copy the staged data into it.
void *npuPtr = nullptr;
aclrtMalloc(&npuPtr, size, ACL_MEM_MALLOC_HUGE_FIRST);
aclrtMemcpy(npuPtr, size, hostBuf, size,
            ACL_MEMCPY_HOST_TO_DEVICE);         // host RAM -> NPU HBM (copy #2)
```

写路径是镜像：aclrtMemcpy(DEVICE_TO_HOST) 入暂存缓冲区，后接普通 write()。

严格地说，遗留端到端路径将载荷暂存三次而非两次。在它到达主机之前，来自 DAOS 服务器的 RDMA 传输首先落入 DPU 守护进程的 DRAM，DPU 的 ARM 核将其继续拷贝（约 130 µs 每 16 KB，即 8.9 节的 DMA 模式路径）。UDAA-DAOS 零拷贝模式自行移除第一次暂存，独立于 NDS 并有实测增益（见 8.11 节）。上面代码所示的主机 DRAM 暂存是 NDS 主机内核轨道所移除的。

代码示例停留在主机侧，因为从应用视角看 DPU 侧服务前后相同。综合效果（如图 2 所示）是三次内存落地坍缩为一次，载荷仅落在其最终目的地。

**NDS 之后，读路径（零拷贝 P2P）。**

预期产品路径以现有 P2P 分配策略分配 NPU HBM，用 aclrtRegisterP2P() 注册第二主机可用视图，并对该映射地址发起直接 I/O。当前 fio 验证路径改为通过 /dev/davinci_zonedevX 映射所选 BAR4 区域：

```c
// 1. Allocate NPU HBM with the existing, unmodified P2P allocation.
void *devPtr = nullptr;
aclrtMalloc(&devPtr, size, ACL_MEM_MALLOC_HUGE_FIRST_P2P);

// 2. Register a second, host-usable view over the same HBM (new NDS API).
aclrtP2PRegInfo info = {0};
aclrtRegisterP2P(devPtr, size, &info);  // host-mapped VA in info.mappedVa

// 3. Read from the Virtio-FS file straight into NPU HBM.
int fd = open("/mnt/virtiofs/dataset.bin", O_RDONLY | O_DIRECT);
read(fd, info.mappedVa, size);          // DPU -> NPU HBM, zero-copy
close(fd);

// ... compute on devPtr ...

aclrtUnregisterP2P(devPtr);
aclrtFree(devPtr);
```

写方向对称：带 O_DIRECT 的 write(fd, info.mappedVa, size) 将 NPU HBM 内容单跳搬到存储设备。除 aclrtRegisterP2P/aclrtUnregisterP2P 外上述所有 AscendCL 调用均为现有公开 API。

**表 6**：数据路径对比

| 维度 | NDS 之前 | NDS 之后 |
|------|----------|----------|
| 载荷拷贝次数 | 2（DPU→主机 RAM，主机 RAM→NPU HBM） | 1（DPU→NPU HBM 直接） |
| 用作暂存的主机 RAM | 是 — 每次传输全传输大小 | 否 |
| 主机 CPU 角色 | 发起 read()/write() 并执行 aclrtMemcpy | 仅发起 read()/write()；DPU 执行 DMA |
| 数据路径中的 API 调用 | read()/write() + aclrtMemcpy | 仅 read()/write() |
| PCIe 路径上的 DRAM 暂存 | 载荷在两链路间落入主机 DRAM | 经根复合体直接 P2P 路由；无 DRAM 落地 |
| 端到端内存落地（含 UDAA-DAOS ZC） | 3 — DPU DRAM、主机 DRAM、然后 HBM | 1 — 载荷仅落入 HBM |

DPU<->主机与主机<->NPU 连接是接到同一根复合体的两条不同 PCIe 链路。NDS 移除的是它们之间的主机 DRAM 暂存。NDS 之前，载荷落入 DRAM 弹跳缓冲区并由 CPU 继续拷贝。NDS 之后，根复合体将同一传输对等路由，因此载荷从不落入任何 DRAM，CPU 拷贝消失。

**暂存代价在何处付出。** 暂存路径将载荷写入主机内存再读出，因此每交付字节代价它两次穿越主机内存：一次写入、一次读出。这就是 2.00 所代表的。测量将暂存路径置于其附近 —— 每交付字节 1.93 到 2.46 字节的主机内存流量，而直接路径在 0.08 到 0.34 之间。略低于 2.00 的值出现在低并发且尚未完全解释；按实测报告而非调整。直接路径上的残余是簿记 —— 钉住页、头、队列描述符 —— 而非载荷。这是第 9 章报告的吞吐与负载结果背后的机制。

**图 10**：每交付字节对应的主机内存流量，对照暂存路径不可避免的 2.00 下限。

---

# 7 块 B：DPU 平台（增强 UDAA 与 FSaaS）

## 7.1 UDAA — 统一 DPU 架构 API

### 7.1.1 什么是 UDAA

UDAA（Unified DPU Architecture API，统一 DPU 架构 API）是华为的软件框架，通过一个统一的高层 API 向应用开发者暴露华为 DPU（数据处理单元 / SmartNIC）的全部能力，隐藏底层硅片、微码与驱动的复杂性。其指导愿景是成为"DPU 的 CUDA"：正如 CUDA 让开发者无需掌握 GPU 硬件即可利用它，UDAA 让团队无需学习低层华为栈即可构建 DPU 加速的基础设施服务。

### 7.1.2 它解决的问题

华为 DPU 功能强大，但历史上难以在其上构建：每个团队都需要对硬件、微码与专用驱动的深入低层知识。这一高入门门槛有真实业务成本：

- **速度** — 开发慢、爬坡时间长。
- **效率** — 工作在各业务单元间重复且分散。
- **可达性** — 功能被锁定在少数硬件专家手中。
- **竞争力** — 陡峭学习曲线使平台不如拥有干净 SDK 的对手有吸引力。

### 7.1.3 UDAA 解决方案与价值

UDAA 在 DPU 构建块之上引入单一抽象层与统一 API，将专业硬件平台转变为可广泛编程的平台。业务价值：

- **更快、更简单的开发** — 任何 DPU 支持的特性一个 API，复杂硬件被封装。
- **可移植性与投资保护** — 封装构建块使应用跨 DPU 代与配置可移植。
- **共享生态** — 所有华为业务单元与外部伙伴可共同构建的通用框架。

### 7.1.4 UDAA 能带来什么

在 UDAA 之上，华为构建软件定义的基础设施服务，DPU 将其作为标准设备呈现给主机服务器，因此主机无需特殊软件即可使用：

- **FSaaS** — 文件系统即服务：DPU 向主机提供网络/虚拟文件系统（当前旗舰参考应用）。
- **MaaS** — 内存即服务：DPU 向主机提供内存池并将热数据迁移到更靠近使用处。

### 7.1.5 目标用例

- 软件定义存储卸载 — 从 DPU 向主机服务器呈现文件系统，将存储数据路径移出主机并释放主机 CPU 核（今日经 FSaaS 交付）。
- 内存扩展与分解 — 向主机提供内存池并自动将常用数据提升至本地 RAM（经 MaaS 交付）。
- 新 DPU 服务平台 — 一个 API，华为业务单元与伙伴可在其上添加更多加速基础设施服务而无需低层硬件专长。

### 7.1.6 架构一览

华为 DPU 是一块具有两个区域的 SmartNIC。SPU 是运行 UDAA 与客户服务代码的一组 ARM 核。NPU 是向主机呈现 PCIe 设备、驱动高速 DMA 引擎并处理网络流的硅片与固件。UDAA 运行在 SPU 上并编排 NPU，因此主机仅看到普通 PCIe 设备，而重活被卸载到 DPU、远离主机 CPU。

**图 11**：华为 DPU 架构：SPU 软件域与 NPU 硬件/数据搬运域。

### 7.1.7 库的逻辑结构

逻辑上，UDAA 组织为一小栈层，每层隐藏其下层的复杂性。服务代码调用单一统一 API，UDAA 将其翻译为 DPU 硬件理解的低层操作。同一核心引擎被每个服务复用，这正是框架既简单易用又易扩展的原因。

从应用到硬件，各层为：

- **应用与服务** — 客户服务代码与 UDAA 附带的参考服务（FSaaS、MaaS）。它们以文件、内存或通用作业表达工作 —— 绝非原始硬件。
- **UDAA 库（Context）** — 每个加速能力（DMA、FSaaS 及未来的加密/压缩/流）打包为可插拔"context"。context 是 UDAA 的扩展点：添加新能力即添加一个 context，而非重接框架。
- **UDAA 核心** — 所有服务复用的可重用引擎（其构建块如下所述）。
- **驱动（VPMD / UDK）** — 实际与 DPU 硅片对话的薄层 —— virtio 轮询模式驱动、DMA 引擎访问，以及到内核驱动的通道。
- **DPU 平台** — 华为 SmartNIC 自身：SPU（运行 UDAA 与服务代码的 ARM 核）与 NPU（向主机呈现 PCIe 设备并驱动 DMA 引擎的硬件）。

**图 12**：UDAA 的逻辑分层与核心构建块。

UDAA 核心内部，一组协作构建块被每个服务复用：

- **模拟设备** — 表示 DPU 向主机呈现的虚拟 PCIe 设备，例如 virtio-fs 盘。这是主机服务器将 UDAA 服务视为普通硬件的方式。
- **模拟队列** — 将来自主机驱动的入站请求搬入 UDAA — 主机投递请求、UDAA 取走它的路径。
- **工作队列** — 向 DPU 提交作业并收集其完成的引擎。单条工作队列通过分发到匹配 context 服务任何作业类型。
- **Context** — 可插拔的按能力逻辑，将作业转为确切硬件描述符并解析结果回 — 因此核心从不需要知道"DMA"或"FS"作业实际是什么。
- **队列管理器** — 资源所有者，动态且 NUMA 感知地分配队列与内存，取代旧的刚性硬编码方案。
- **缓冲区与内存** — 缓冲区抽象加上按需内存子系统，钉住页、为 DMA 引擎准备它们，并按实际工作负载调整内存池大小。

稳态下这些部件按 CPU 核对齐：请求到达模拟队列，服务处理它，任何数据搬运以工作队列上的作业表达，后者交给 DMA context 并收获完成。由于队列、context 与内存均按需分配，同一结构可干净地跨多核扩展并以最少附加代码承载新服务。

## 7.2 增强 UDAA 及其对 NDS 的价值

### 7.2.1 增强 UDAA 工作概述

增强 UDAA 工作将 UDAA 重新架构为自包含框架，直接运行在 DPU 数据面驱动（VPMD/UDK）上，移除遗留 HiVIO 依赖。目标是更轻、更快、更灵活的 SPU 数据面 —— 与 NDS 对其存储路径的目标相同。关键交付物：

- **解耦的轻量 SPU 框架** — UDAA 直接运行在 VPMD/UDK 上而非 HiVIO，消除 UDAA→HiVIO 消息翻译及其数据面延迟/开销。
- **定制 UDAA 网络设备 + 队列管理器** — SPU<->主机流量经专用 UDAA netdev，以动态、NUMA 感知队列分配取代刚性硬编码队列。
- **统一队列与可插拔 context 模型** — 单一队列类型服务所有作业类型（如 DMA 与 FS）。添加新卸载即实现一个 context（含其提交、轮询与 WQE 翻译步骤），而非重接队列。
- **按需内存子系统** — 内存池大小从所附 context 的作业大小推导并绑定到 NUMA 节点，因此内存随工作负载类型与工作者数量扩展。
- **FSaaS / virtio-fs 数据面优化** — 模拟请求聚合、带弹跳缓冲区的全 IO 聚合，以及多 FUSE 会话支持 — 驱动近线性核扩展与高 IOPS。

### 7.2.2 如何加速 NDS 项目

NDS 与增强 UDAA 瞄准同一目标：将 CPU 移出存储数据路径并使 SPU/NPU 路径精简可扩展。解耦工作本身不是 NDS 特性集，但它提供了若干 NDS 任务所依赖的数据面基础、扩展性模型与性能基线。最强联系归为四个主题：

- **DPDK 式驱动上的精简 SPU 框架（无 HiVIO/HiVBS）** — 这本质上是 NDS 在"SPU 高级框架直接运行在 DPDK 上、无 hivio/hivbs 层"与"新 SPU 框架上的 virtio-fs"任务中所要求的。增强 UDAA 已在 VPMD/UDK 上验证无 HiVIO 的 SPU 数据面，因此 NDS 从工作基线而非从零开始。
- **零拷贝 / RDMA 路径的扩展性** — 统一队列与可插拔 context 设计意味着 RDMA 读或远端读/写成为附在现有工作队列上的新 UDAA context，而非队列重设计。RDMA SPU<->主机通道已在增强 UDAA 路线图上，直接对齐 NDS DPU 零拷贝（RDMA READ、远端 READ/WRITE）任务。
- **面向 NPU 路径的高吞吐 virtio-fs 基底** — NDS 主机面栈（华为 FS 驱动、virtio-fs P2P 增强、cuFile 式库、端到端集成）接入增强 UDAA 优化的 virtio-fs / FSaaS 数据面。抬高 virtio-fs 上限确保一旦 NPU 直接路径就位，数据面不是瓶颈。
- **CPU 轻量、可扩展的数据搬运** — 聚合与近线性核扩展降低每 IO 的 CPU 工作，直接支撑 NDS CPU 利用率与带宽目标。内存子系统与缓冲区模型也是计划中带用户提示的高级 P2P-DMA 页缓存接口的自然起点。

> 范围说明：与 NDS 专有硬件/内核/cuFile 代码绑定的 NDS 任务（如 1823E 上的部署与调优、内核 P2P-DMA 驱动内部、完整 NPU+DPU 集成测试）在此工作下游。它们受益于框架与性能基线但超出增强 UDAA 范围。

### 7.2.3 增强 UDAA 设计与实现

本节逐一查看上述每项增强，解释驱动它的问题、我们采取的决策，以及该决策为何对 NDS 重要。

- **解耦的轻量 SPU 框架。** 遗留栈运行在 HiVIO 上，它前向配置所有 VPMD 队列与内存池并强制每条 UDAA 消息翻译为 HiVIO 消息。该翻译在数据面上增加延迟并紧密耦合 UDAA，限制了灵活性与可扩展性。我们使 UDAA 在 VPMD 与 UDK 之上自包含，因此它直接拥有数据面并丢弃翻译层。这对 NDS 重要是因为 NDS 特别需要直接运行在 DPDK 式驱动上、无 HiVIO 与 HiVBS 层的 SPU 框架。解耦框架恰好交付该基线，且移除每消息翻译缩短关键路径，直接服务于 NDS 延迟与 CPU 利用率目标。
- **定制 UDAA 网络设备 + 队列管理器 — 为何这么做：** 遗留模型中队列创建与内存池逻辑刚性硬编码，每条工作队列需要两对固定 HiVIO 队列对，因此引入任何新协议意味着更多队列对与更多池。我们在 VPMD 之上构建专用 UDAA 网络设备加拥有所有队列与池并动态、NUMA 感知分配（含每设备流隔离）的队列管理器。**如何帮助 NDS：** 它给 NDS 一个灵活基底，新路径（RDMA、零拷贝）可在其上获得自己的队列而无需重设计框架，且 NUMA 感知放置在跨核扩展时保持 NPU 直接路径高效。
- **统一队列 + 可插拔 context 模型 — 为何这么做：** 我们希望添加新卸载无需重接队列，因此统一队列设计（一种队列类型服务所有作业类型）并将每种能力转为可插拔"context" — 小型提交/轮询加作业到描述符翻译。添加能力变为写一个 context 而非改引擎。**如何帮助 NDS：** NDS 零拷贝工作（RDMA READ、远端 READ/WRITE）可作为现有工作队列上的新 context 添加，而非队列重设计，将若干 NDS 任务从"从零构建"转为"扩展现有框架"。
- **按需内存子系统 — 为何这么做：** 静态前向内存池（HiVIO 方式）浪费内存且不随作业类型与工作者数量变化扩展。我们使池大小从所附 context 的作业大小推导、绑定池到 NUMA 节点并在工作队列启动时分配，因此内存按作业类型与工作者数量扩展。**如何帮助 NDS：** 按工作负载大小的内存与 NUMA 局部性是高带宽、多核 NPU 直接数据路径的前提，且此缓冲区/内存模型是计划中带用户提示的高级 P2P-DMA 页缓存接口的自然基础。
- **FSaaS 与 virtio-fs 数据面优化。** 解耦后，火焰图分析显示取回阶段 DMA 消耗约 30% 运行时。缓冲区钉住与 FUSE 每请求分配锁随后成为下一瓶颈。我们逐一解决每个实测瓶颈。模拟请求聚合对多请求发一次 DMA。带弹跳缓冲区的全 IO 聚合产生单一聚合响应与完成。多 FUSE 会话缓解锁竞争。合计将 4 KB I/O 的 virtio-fs 数据面上限提高约八倍，从约 950 K 到 1.7 M IOPS。因此一旦 NDS NPU 直接路径就位，数据面不是瓶颈。此工作也提供 NDS 复用以在新 SPU 框架上评估 virtio-fs 的基准与优化方法论。

**实现范围。** 增强 UDAA 实现在 UDAA_Hi1823_chip_solution 仓库，分支 boris/DPU2x100-UDAA-DAOS，提交 fcfe711467c。相对基线提交 8cfa59f484b^，tools/udaa 子树跨核心、接口头、库、DAOS 集成、应用与构建脚本新增 99 个文件与 18,287 行。该工作以 UDAA 自身拥有的队列、网络设备、工作队列、context、缓冲区与内存设备基础设施取代遗留 HiVIO 依赖。其上添加多收发队列、动态队列管理器分配、DMA 工作队列、context 集成、多 virtio-fs function 支持、批量取回与完成处理、散列聚合与 DMA 缓冲区合并、批处理异步处理、零拷贝重定向、内存窗口与散列链表绑定，以及大页支撑的钉住池。实现范围为 8cfa59f484b^..fcfe711467c。相同变更以不同提交 ID 出现在其他分支上（重定基结果）；那些不计为独立工作。

### 7.2.4 性能证据

解耦框架移除了基于 HiVIO 版本的扩展上限（平台在 10GB/s）并交付近线性扩展。下图 13 显示单 virtio-fs-function 吞吐对块大小。

**图 13**：DPU 数据面可扩展性证据 [已验证，基础级]：单 virtio-fs-function 吞吐 vs. 块大小（fio，passthrough 后端）。旧的 10GB/s 平台被消除。非端到端 NDS 结果。

- 近线性核扩展 — 解耦框架跨 16/24 核扩展，而基于 HiVIO 版本卡在约 8。
- 数据面优化 — 模拟请求聚合将取回阶段 DMA 从约 30% 降到约 16% 运行时。带弹跳缓冲区的全 IO 聚合在 4 KB I/O 上交付约八倍吞吐。
- 多 FUSE 会话 — 两个会话约翻倍 IOPS（≈950 K → ≈1.7 M IOPS），通过缓解 FUSE 分配锁竞争。
- 统一队列 — 显著减少内存占用，取决于服务多作业的后端队列数量。

### 7.2.5 小结

增强 UDAA 从 HiVIO 解耦给 NDS 在其最难的基础设施问题上一个先发优势：经证明的无 HiVIO SPU 数据面（在 DPDK 式驱动上）、零拷贝与 RDMA 路径干净落入的可扩展 context/队列模型、面向 NPU 直接路径的高吞吐 virtio-fs 基底，以及带清晰优化剧本的实测性能基线。净效果是若干 NDS 任务从"从零构建"转为"扩展现有、CPU 轻量框架"，直接服务于 NDS 延迟、带宽与 CPU 利用率目标。

## 7.3 跨 PCIe 内存映射（DPU 侧）

在现代 DPU 使用中，DPU 上运行的 RDMA 应用必须访问位于主机上的数据。无特殊机制时，所有收发数据先拷入 DPU 内存再移到最终目标。跨 PCIe 内存映射设计移除该中间拷贝。其寻址模型保持现行并支撑已实现的零拷贝路径。内存窗口流程本身在 8.9 节描述。

一种特殊地址形式寻址主机内存。位 63 指示地址为客户物理地址（GPA）。若 GPA 位置位，位 62:52 携带该 GPA 所属主机的 VFID，位 51:0 携带 GPA 本身。若该位清零，位 62:0 为本地 DPU 地址。工作请求从不混合地址类。一条工作请求包含要么关联同一主机的 GPA，要么 DPU 本地地址。

**图 14**：单一地址形式跨越两个内存域：GPA 标志位选择主机（VFID + GPA）或 DPU 本地寻址。

主机内存访问使用带 GPA 地址形式的 DMA_MR。作为 RDMA 目标的应用从不直接共享 DMA_MR 的 RKey。它改为在 MR 上 bind 一个内存窗口并共享 MW 的 RKey，DPU 丢弃任何提交 DMA_MR RKey 的入站请求。

以 FUSE_WRITE 流程为例。主机载荷由 DAOS 服务器直接从主机内存读取 — DPU 上无暂存拷贝。已实现的零拷贝写路径（称为 RDMA 重定向）以五步实现该模型：

1. **注册一次，在 init。** udaa_rdma_redirection_reg_dma_mr() 创建覆盖主机可见内存的 DMA MR，因此一个 rkey 服务任何主机地址 — 无每 I/O 注册。MR 在初始化期间建立并在进程生命周期内保持有效。
2. **转换 SGL，不转换数据。** 在 FUSE WRITE 上，后端以 udaa_rdma_redirection_convert() 原地重写只读 SGE，然后调用 dfs_write()。DAOS 与 Mercury 照常构建其批量描述符；仅 SGE 内的地址字段被重写为重定向形式。DPU 上不触碰任何载荷字节。
3. **重定向寄于地址。** 位 63 (RD) 标记重定向地址。RD 置位时，位 62:52 携带标识主机 function 的 GFID；否则这些位只是 DPU 本地地址的高半。位 51:0 保留地址。此编码是上述 GPA 地址形式的具体实现：同一 64 位字段描述本地 DPU 缓冲区或主机侧缓冲区，无需每 SGE 的单独边带结构。
4. **固件重定向传输。** 服务器发起 RDMA READ 时，NPU 检查 SGE[0] 的 RD。若置位，它从 RD_MD 取 GFID，跨 SGL 清除 RD/RD_MD，并重写 TDMA 命令以从主机内存取。否则正常路径原样运行。所有后续 SGE 继承同一重定向决策，保证整条传输的源域一致。
5. **结果。** 载荷主机 → 服务器单跳。SPU 仅触碰描述符；完成与响应缓冲区经现有路径返回。中间 DPU 暂存缓冲区从不分配也从不写入，同时移除拷贝延迟与相关 PCIe 带宽消耗。

**图 15**：带 RDMA 重定向的零拷贝写路径。

这样，跨 PCIe 内存映射设计不仅是寻址约定：通过 RDMA 重定向它成为让主机载荷无需在 DPU 上暂存即可到达 DAOS 服务器的操作路径。

---

# 8 块 C：UDAA-DAOS 零拷贝后端

## 8.1 概述

udaa_fsaas_bridge 是一个用户空间守护进程，在承载 Hi1823E DPU（ARM 应用核带嵌入式 RoCE NIC）的机器上终止来自一个或多个客户 VM 的 VirtioFS 流量，并针对 DAOS 分布式存储集群提供完整类 POSIX 文件系统。具体而言：

- 多个客户 VM 各看到一个 VirtioFS 设备。守护进程从单进程并发服务它们。
- 实现完整 FUSE 协议面 — 23 个处理器覆盖 lookup、open、read/write、mkdir/rmdir、rename、fallocate、statfs、readdirplus、listxattr 等。
- 每个客户 VM（物理功能，"PF"）隔离：自己的 DAOS 池、容器与 DFS 挂载，自己的 inode 缓存命名空间，自己的回收目录，自己的目录句柄表。
- 对批量数据（即 FUSE_READ 与 FUSE_WRITE 的载荷部分），存在两种工作模式，启动时以 -zc 命令行标志选择。DMA 模式下，服务器传输落入守护进程 RAM，DPU 经主机 DMA 路径将其拷入客户页。零拷贝模式下，服务器传输经内存窗口 bind 直接落入客户主机页，DPU 不在数据路径中。所有元数据操作在两种模式下相同运行。

**图 16**：一个守护进程服务多个隔离租户：每个客户 VM 拥有自己的 VirtioFS function、池与命名空间。

三个角色协作。客户内核经其 VirtioFS 设备发出 FUSE 协议消息。DPU 上的 udaa_fsaas_bridge 经 libudaa 从每队列工作队列接收这些消息，通过 FUSE 操作码表分发，并经同一队列写回响应。独立主机上的 DAOS 引擎经 RoCE 提供实际数据。

## 8.2 DAOS 后端 — 以及为何选择 DAOS

后端选择直接源于项目的零拷贝前提。DAOS 从底层为现代非易失内存与高速网络构建。其数据路径端到端绕过内核 — 用户空间客户端库、用户空间网络（libfabric/RDMA）与用户空间存储驱动（PMDK/SPDK），且按目标分片无跨目标锁。

此处特别重要的两个性质：

- DAOS 在内联 eager 阈值之上的批量传输是原生 RDMA：Mercury 将目标缓冲区暴露为批量句柄，服务器 RDMA 写或读直接入它，这正是 ZC 模式（见 8.9 节）利用的结构钩子。
- DAOS 声明的 AI/ML 用例恰好是本项目的 — 高吞吐零拷贝管线，将大型非结构化数据集直接喂入加速器内存而无中间缓冲。

类 POSIX 访问仍作为顶层可用（DFS API），这正是 udaa_fsaas_bridge 处理器所消费的。

以下各节依赖的架构事实：拓扑是三平面共享无关 — 控制（daos_server，Raft 复制管理服务）、数据（daos_engine，每 CPU 插槽一个，承载每目标 VOS 实例）与客户（libdaos 加每节点 daos_agent，仅位于连接路径）。

存储分层：SCM 用于 VOS 元数据与小值，NVMe 经 SPDK 用于批量 extent，轮询、无锁、无内核页缓存。数据模型为 Pool → Container → Object → dkey → akey → value，DFS 将路径名映射其上。栈在客户与服务器对称：libdaos → CaRT → Mercury (RPC + bulk) → libfabric。

**图 17**：DAOS 在 libfabric 层对称，且超过 eager 阈值的批量传输是原生 RDMA — 零拷贝模式利用的结构钩子。

## 8.3 库组成

**表 9**：udaa_fsaas_bridge 库组成

| 构件 | 角色 |
|------|------|
| udaa_fsaas_bridge (binary) | 链接 libudaa.so（平台层），加 udaa_fs_* 的内部弱空操作桩。以 --export-dynamic 构建以便预加载库可解析二进制定义的符号。含 main() 与 CLI、VirtioFS 设备管理器（uhf_*：枚举设备、附加队列、批量取回与完成请求）、每队列分发器与执行线程，以及 FUSE 操作码到处理器路由表。libabt (Argobots) 依赖已移除：守护进程全程使用普通 pthread。 |
| libudaa.so | 预构建平台库：udaa_core_init（启动）、udaa_eml_dev_*（VirtioFS 设备模拟原语）、udaa_workq_*/udaa_ctx_*（DMA 工作队列与 context），以及 udaa_rdma_redirection_* — 持有客户物理地址与主机物理页绑定的 DPU IOVA 映射，导出"这是否是 IOVA？"谓词与 SGE 到扁平 iovec 的翻译。 |
| libudaa_daos_handlers.so | LD_PRELOAD 处理器库：覆盖二进制弱桩的强 udaa_fs_* 实现、四个 Mercury 零拷贝钩子回调、23 个 DAOS FUSE 处理器、inode 缓存与每 PF 状态。允许未定义符号链接，因其覆盖的 udaa_fs_* 定义位于二进制中、钩子设置器位于打补丁的 Mercury 中 — 两者在运行时解析。 |

## 8.4 DAOS / Mercury 集成

处理器库需要两个原始 DAOS 不提供的集成点。构建时对原始 DAOS 2.6.5.p1 树应用六个补丁。零拷贝补丁除非应用通过注册钩子并设置环境变量选择加入否则保持惰性，因此默认 DAOS 行为不变：

**表 10**：对 DAOS 2.6.5.p1 的构建时补丁

| 补丁 | 目的 |
|------|------|
| 0001 | 构建卫生：将 stringop-overflow 警告放宽为非致命。 |
| 0002 | SCons 修复：允许以相对源根的路径引用补丁。 |
| 0003 | CaRT：当 DAOS_FORCE_RDMA_BULK=1 时禁用 Mercury bulk-eager — 强制所有批量经线上 RDMA 路径（ZC 钩子操作处）。 |
| 0004 | Mercury：四个 ZC 钩子的函数指针注册（na_ofi_set_zc_hooks）；默认 NULL 保留原始行为。 |
| 0005 | libdaos：daos_set_zc_iova_hook 谓词；批量决策逻辑在 IOVA SGL 上强制批量。 |
| 0006 | libdaos：在 IOVA SGL 上跳过 obj_sgls_dup 合并 memcpy（对 IOVA 的 CPU 读会故障）。 |

## 8.5 启动顺序与线程模型

**启动形态：**

```
LD_PRELOAD=./libs/libudaa_daos_handlers.so \
udaa_fsaas_bridge    ./udaa_fsaas_bridge start [-d[=<path>]] [-zc] [-e <n>] <pf> <q> <fs> <mnt> ...
```

启动序列以固定顺序运行。首先 udaa_core_init() 与设备枚举。然后分配钉住的请求槽池，为本轮所有队列定大小。然后处理器库中 udaa_fs_startup(is_zc)，其 ZC 专有工作仅在 ZC 启用时运行：经 na_ofi_set_zc_hooks 注册四个钩子、设置 IOVA 谓词并设置 DAOS_FORCE_RDMA_BULK=1。然后 daos_init()。然后 inode 缓存初始化与 23 个 FUSE 处理器注册。然后每设备一次 udaa_fs_mount(pf_id, "pool/container")，后接 uhf_device_start。然后每队列创建线程，执行线程先、分发器最后。最后主线程睡眠直到 SIGINT 或 SIGTERM。

三条排序规则不可协商：

1. na_ofi_set_zc_hooks() 必须在 daos_init() 之前运行，因为 Mercury 在 DAOS init 期间创建其 NA 上下文时捕获钩子指针。
2. udaa_fs_startup() 必须在任何 udaa_fs_mount() 之前运行，因为 mount 调用仅在 daos_init() 之后安全的 DAOS API。第三，某队列的执行线程必须在其分发器之前存在，以便分发器从不在有线程接手之前发出请求槽。

**图 18**：启动顺序是正确性契约：ZC 钩子必须在 daos_init() 之前注册，fs_startup 必须在任何 mount 之前。

每条 VirtioFS 队列由一小组普通 OS 线程服务：一个分发器与 N 个执行线程，全部钉到该队列的单一 CPU 核。因此队列仍局限于一核，且队列间从不共享状态。守护进程任何地方都不使用 Argobots 执行流或用户级线程。

**分发器。** 每队列一个，是队列上下文的唯一所有者：请求槽、完成掩码与暂存缓冲区。它取回一批请求，将每个槽索引交给执行线程池，等待该批，然后单次调用完成整批。队列为空时它睡眠而非自旋，因为它与做真正工作的执行线程共享一核。

**执行线程。** 每队列 N 个，不拥有任何东西。每次取一个槽索引并为其运行处理器，在 dfs_read() 或 dfs_write() 内阻塞直到操作返回，然后报告槽归还。分发器在交出前发布槽且在报告前不再触碰，因此给定槽仅被一个线程访问。

N 由 -e 标志设置：默认 4，最多 16。由于处理器阻塞，这是单队列可同时在飞的请求数，-e 1 复现早期每队列一线程行为。并发来自并行运行多个阻塞处理器而非异步 I/O，守护进程下方的一切依赖此：内存窗口在单条 dfs_read() 或 dfs_write() 中、单线程上 bind、使用并释放。DAOS 内的 Mercury 推进引擎运行其自身内部线程，与此模型无关。

## 8.6 每请求生命周期与处理器清单

**图 19**：每个请求遵循同一条五阶段路径。畸形输入在分发阶段、任何处理器运行之前被拒绝。

分发器集中处理输入长度健全性（头/长度不匹配返回 EIO）、未知操作码处理（优雅 ENOSYS）、输出头簿记，以及为异步响应处理器（如 FORGET）的无回复哨兵。处理器仅关注文件系统逻辑。全部 23 个处理器分组如下：

**表 11**：FUSE 处理器清单

| 组 | 操作码 | 行为 |
|----|--------|------|
| 会话 | INIT, DESTROY | 能力协商（见 8.7 节）； provision 每 PF 回收目录。INIT 每 PF 幂等。 |
| 命名 | LOOKUP, FORGET, BATCH_FORGET, RENAME, RENAME2 | 在 inode 缓存中维护内核引用计数；原地原子 rename。 |
| 元数据 | GETATTR, SETATTR, STATFS, LISTXATTR | 属性读写；合成 statfs（DAOS 不经 DFS 暴露池容量）。 |
| 目录 | MKDIR, RMDIR, OPENDIR, RELEASEDIR, READDIRPLUS | 每 PF 目录句柄表带魔值验证；批量 dfs_iterate。 |
| 文件 | CREATE, OPEN, RELEASE, UNLINK, FALLOCATE | 缓存打开句柄（内核将其作为不透明 fh 传回）；经回收目录延迟 unlink。 |
| 批量数据 | READ, WRITE | 唯一演练 DMA 对比 ZC 批量传输的操作码（见 8.9 节）。 |

## 8.7 FUSE_INIT 能力协商

INIT 处理器协商的 FUSE 特性集其效果超越协议兼容 — 它塑造内核对每请求使用的 I/O 大小与对齐：

**表 12**：协商的 FUSE 能力及其效果

| 能力 / 参数 | 效果 |
|-------------|------|
| max_write = 4 MiB | 广告为 4 MiB。内核仅在协商 FUSE_MAX_PAGES 时尊从更大请求大小。部署后端确实协商它，因此有效上限由 fs.fuse.max_pages_limit 设置，受支持部署钉在 64 页即 256 KiB。 |
| max_readahead = 4 MiB | 内核以 4 MiB 窗口为顺序访问预读。 |
| max_pages = 1024 | 已广告，但实际被限：协商 FUSE_MAX_PAGES 时内核从 fs.fuse.max_pages_limit 取其页限，因此请求缓冲区为 64 页即 256 KiB。 |
| map_alignment = 12 (4 KiB) | 客户页对齐到每散列聚合段的页边界。 |
| FUSE_BIG_WRITES | 允许大于 4 KiB 的写；无它则每次写退化为多个 4 KiB 包 — 对 ZC bind 吞吐毁灭性。 |
| FUSE_DO_READDIRPLUS | 用 READDIRPLUS 替代 READDIR 加每条目 LOOKUP；更少往返。 |
| FUSE_PARALLEL_DIROPS / FUSE_ASYNC_READ / FUSE_ASYNC_DIO | 每队列多个在飞操作。 |
| FUSE_HANDLE_KILLPRIV_V2 | 内核中无竞争 SUID 清除。 |
| FUSE_ATOMIC_O_TRUNC | O_TRUNC \| O_CREAT 一次往返。 |
| FUSE_SECURITY_CTX | SELinux/AppArmor 标签随每请求交付守护进程。 |

在本文档所测构建中，有效请求大小因此为 256 KiB 而非 4 MiB，第 9 章报告的每个性能结果均在该大小下取得。其余能力仍重要。FUSE_BIG_WRITES 防止写退化为 4 KiB 包（对零拷贝 bind 吞吐毁灭性），map_alignment 保证每散列聚合段从页边界开始（这让内存窗口精确覆盖一段）。

**所需挂载配置。** 挂载文件系统前将 fs.fuse.max_pages_limit 设为 64。这是数据面安全要求，非调优偏好。限值提到 256 时，1 MiB 直接 I/O 请求变为 256 段请求，在部署后端中这些请求从不完成：发出它们的线程在内核中保持阻塞，挂载无法释放直到机器重启。以下顺序重要，因为请求大小在文件系统挂载时协商，事后更改设置对现有挂载无效。

```
modprobe virtiofs
sysctl -w fs.fuse.max_pages_limit=64
mount -t virtiofs <tag> <mountpoint>
```

## 8.8 多租户隔离、缓存与 Unlink 状态机

每个 VirtioFS PF 获得一个每 PF 状态槽（最多 24 租户），持有其 pf_id、该 PF 池/容器的 DFS 挂载、回收目录句柄、原子 init 标志，以及互斥锁下 128 条目魔值验证目录句柄表。inode 缓存键为复合 {pf_id, inode}，因此一个 PF 的条目从不与另一个碰撞。

**表 13**：缓存清单

| 缓存 | 范围 | 目的 / 收益 |
|------|------|-------------|
| Inode 缓存 | 进程 | 映射 FUSE inode 号 → 打开的 dfs_obj_t *，避免每次操作 dfs_lookup。4096 哈希桶，各有自己的 rwlock；哈希将 pf_id 混入 inode 位，因此繁忙 PF 不退化其他 PF 的桶分布。 |
| 目录句柄表 | 每 PF | 安全句柄间接：内核收到小经验证索引而非原始指针。挺过 FORGET 竞争；让守护进程拒绝伪造句柄。 |
| FUSE fh 直传 | 每文件 | OPEN 将缓存的 dfs_obj_t * 直接写入 fuse_open_out.fh；内核在每次 READ/WRITE 回传 — O(1)，热 R/W 路径无 inode 缓存往返。 |
| 每 PD 上下文 (ZC) | 每 PF | 父 MR、IB 端口、GID 索引、以太网设备；在钩子创建时按 ibv_pd * 查找 — 每保护域一条（每 PF 一条）。 |
| 每线程 MW 池 + rkey (ZC) | 每执行线程 | 最多 40 个 Type-1 内存窗口池。每散列聚合段在 DAOS 调用发出前 bind 一个窗口；Mercury 注册钩子随后依次发出每窗口 rkey，每段无额外 verbs 调用。 |
| 回收目录 | 每 PF | 持有仍活跃时被 unlink 的文件，以便 DAOS 稍后移除而不使打开句柄失效。 |
| 内核条目/属性超时 | 客户内核 | 各协商 10 s；客户缓存 name→inode 映射与 stat 数据，本地应答重复 LOOKUP/GETATTR。 |

inode 缓存跟踪两个引用计数：kernel_refs（每次返回该 inode 的 LOOKUP 递增，FORGET/BATCH_FORGET 递减）与 active_refs（将每在飞处理器操作与缓存句柄配对）。清理 —— 关闭 DAOS 句柄、释放条目、可选从回收目录移除 —— 仅在两者归零时发生。

**Unlink 状态机。** 客户内核可 unlink 仍打开的文件。POSIX 要求文件保持可读写直到最后描述符关闭，但 DAOS 移除立即使句柄失效。守护进程以每 PF 回收目录桥接该差距。

在文件活跃使用时到达的 UNLINK 生成唯一回收名、标记条目已回收、将文件移入回收目录，因此原始句柄保持有效。对空闲文件的 UNLINK 是直接移除。当最后引用计数归零，条目被删除、句柄关闭、已回收文件移除。

若每 PF 回收目录在 INIT 时打开失败，守护进程回退到直接移除。客户可能在病态情况下看到 EBUSY，但守护进程保持正确。

**图 20**：POSIX unlink-while-open 通过每租户回收目录桥接到 DAOS 语义。仅当两个引用计数都归零时才触发清理。

## 8.9 批量数据路径：DMA 对比零拷贝

工作模式在启动时按设备经 -zc CLI 标志设置，仅影响 FUSE_READ/FUSE_WRITE 的载荷部分。

**DMA 模式（默认）。** 服务器批量传输落入守护进程钉住的 RAM。DPU 随后经主机 DMA 路径将载荷拷入客户 IOVA 页，约 130 微秒每 16 KB 拷贝。这在任何链路上工作，但 ARM 核上限约 1 到 2 GB/s。

**零拷贝模式 (-zc)。** RoCE NIC 经每散列聚合段一次内存窗口 bind，将载荷数据直接 RDMA 写入客户 IOVA 页，约 30 微秒每 bind。DPU RAM 与 DPU CPU 完全不在数据路径中。

**图 21**：零拷贝模式完全移除 DPU 侧 ARM memcpy：NIC 直接写入请求的页。

ZC 机制有两个范围。每保护域（每 PF 一个）有一个父 MR：覆盖整个重定向管理 IOVA 窗口的单次注册，由附在该 PD 的每个线程共享，连同在首次钩子创建时一次解析的身份信息（IB 端口、GID 索引、以太网设备、verbs 上下文）。

每执行线程有专用 256 条目完成队列、专用 RC QP（经下述邻居表项过程带到 RTS，专用于 ibv_bind_mw），以及最多 40 个 Type-1 内存窗口池。池按线程因为处理器同步：一个执行线程一次运行一个请求，因此没有线程需要考虑另一线程的 bind。

bind 在读与写处理器中、DAOS 调用发出之前发生。处理器先检查段是否为重定向 IOVA。然后它在每线程 QP 上、父 MR 之上、每段发一个 ibv_mw_bind，访问权限从传输方向推导：读为远端写、写为远端读。仅最后发出的 bind 被信号通知，因此单次完成覆盖整集。

Mercury 每段注册钩子随后依次发出窗口，每段一个 rkey，并在到达最后段时轮询那单次完成。在 DAOS 调用之前发 bind 是故意的：硬件在 CPU 仍在 DAOS RPC 提交路径内时执行它们，因此其代价被隐藏而非串行付出。

**QP RTS 建立。** RC QP 在到达 RTS 状态前不能接受 ibv_bind_mw 工作请求，且 INIT→RTR 转换强制内核解析目的链路层地址，因此目的必须在 ibv_modify_qp 时刻位于主机邻居缓存中。由于此 QP 从不与真实对端通信，代码制造一次性邻居表项：在 INIT→RTR 之前立即注入静态 ARP 表项、执行转换（邻居查找现在成功）、之后立即移除表项，并完成纯本地 RTR→RTS 转换。

占位地址是常量且从不在线上出现，它们仅满足内核的本地合理性检查。

**图 22**：一次性占位邻居表项将仅用于 bind 的 QP 带到 RTS，从不发送任何包。

**为何每线程 QP、CQ 与 MW？** 三个原因。

1. 共享完成队列会跨每个做 I/O 的线程串行 MW-bind 完成轮询，而每线程 CQ 让每个执行线程仅轮询自己的。
2. 共享内存窗口池需要外部同步以确立当前 rkey 授权谁的 RDMA，而每线程池结合同步每线程处理器流完全消除该问题。
3. 创建代价被摊销：每执行线程在 Mercury 上下文初始化时付一次，然后在该执行线程进程生命周期内服务的每次批量中复用。

## 8.10 配置面与故障模型

**表 14**：配置面

| 旋钮 | 效果 |
|------|------|
| -zc (CLI) | 为该设备读/写处理器启用 ZC 模式；关 → 仅 DMA。 |
| -d (CLI) | 调试日志。裸 -d 写 stderr；-d=<path> 改为追加到该文件。 |
| DAOS_FORCE_RDMA_BULK=1 | 即使对小载荷也强制 Mercury 走线上 RDMA 批量路径。ZC 模式下由 udaa_fs_startup 自动设置；先前值被保存并在关机时恢复。 |
| -e <n> (CLI) | 每队列执行线程数：默认 4，最多 16。设置单队列可同时在飞的请求数。 |
| 编译时常量 | 4 MiB 最优 I/O 大小、10 s 条目/属性缓存超时、每 PF 128 目录句柄、256 条目 readdir 批、合成 statfs 值、24 租户上限。 |

**故障模型。** 处理器检查每个 DAOS 返回码并翻译为 FUSE 协议错误。分发器在任何处理器运行前拒绝畸形输入头（长度不匹配 → EIO）与未知操作码（优雅 ENOSYS）。FUSE_INIT 每 PF 幂等，因此来自并行队列挂载的多个 INIT 被容忍。

守护进程对 dfs_* 调用不加超时。若 DAOS 引擎停顿，调用执行线程阻塞且该客户请求等待。该队列其他执行线程继续服务自己的槽，其他队列完全不受影响，因为此处每个线程都是独立 OS 线程。停顿请求确实占用其槽直到返回，因此足够多最终会停顿到某队列的取回。

打包自包含，构建将所需共享库以相对 RPATH 置于二进制旁，因此部署包仅依赖系统库。

## 8.11 性能：DMA 对比零拷贝

**测试环境。** 客户端 NIC 100 Gb/s、服务端 NIC 40 Gb/s，均 MTU 9000。DAOS 池 120 GB 全 RAM 支撑（ram:/mnt/daos0）无 NVMe 层，因此存储介质不会是限制因素。单引擎承载八个目标。守护进程在一个物理功能上运行 24 个 VirtioFS 队列，每队列默认四个执行线程。

测量使用 fio 直接 I/O、24 个 job、每配置五次重复、5 秒预热（排除在统计外）后 20 秒实测运行时。DMA 与零拷贝在独立扫描中测量，各扫描前两台机器均完整电源循环，因此无池状态从一次扫描带入另一次。

仅读。写用于准备数据集且不测量。其带宽跟踪池有多满而非关于代码的任何事：单一配置五次重复跨 311 到 3571 MB/s，变异系数 28 到 69%，而读为 2 到 6%。数据集每扫描准备一次为 24 个 1280 MiB 文件，每配置读同一数据。因此本节对两种模式的写吞吐不做声明。

**可靠性。** 跨全部十二个测量配置，变异系数范围 0.94 到 5.50%，均值 3.0%，因此每个结果远在测试框架标记测量不可靠的 15% 阈值内。以下所有数字为五次重复的均值，非单样本。任一扫描的任一运行未报告错误、警告或短 I/O。

**表 15**：DMA 与零拷贝读带宽，MiB/s，24 个 job

| 配置 | DMA MiB/s | 零拷贝 MiB/s | ZC 增益 |
|------|-----------|--------------|---------|
| 4 KiB, iodepth 1 | 150.2 | 163.6 | +8.9% |
| 4 KiB, iodepth 8 | 148.6 | 154.6 | +4.0% |
| 64 KiB, iodepth 1 | 1687.8 | 1773.8 | +5.1% |
| 64 KiB, iodepth 8 | 1813.2 | 1780.6 | −1.8% |
| 256 KiB, iodepth 1 | 3089.6 | 2618.4 | −15.3% |
| 256 KiB, iodepth 8 | 2921.6 | 3742.0 | +28.1% |

**图 23**：UDAA-DAOS 零拷贝证据 [已验证，组件级]：fio，只读，24 个 job，每点五次重复，100 Gb/s 客户端与 40 Gb/s 服务端 NIC，RAM 支撑的 DAOS 池。零拷贝在 256 KiB、iodepth 8 时领先 28.1%，在 4 KiB 领先 4~9%，在 256 KiB、iodepth 1 时落后 15.3%（此时 DMA 已饱和）。非端到端 NDS 结果。

- 大传输的胜利在于移除的拷贝。在 256 KiB、队列深度八 —— 二十四个活跃队列，预期工作点 —— 零拷贝交付 3742.0 MiB/s 对 DMA 的 2921.6，增益 28.1%，并将 99 百分位完成延迟从 26.3 ms 降到 20.5 ms，降幅 22.1%。DMA 花费 ARM 周期将每载荷从守护进程缓冲区拷入客户 IOVA；零拷贝让 NIC 直接写入客户页且不花任何。
- 队列深度决定结果，256 KiB 对证明它。iodepth 1 同一块大小显示零拷贝落后 15.3%。原因在延迟中可见。将 DMA 从深度 1 提到 8 使其完成延迟乘 7.6 而带宽完全不动，因此 DMA 在深度 1 已饱和。
- 零拷贝给定同一八倍增长，仅以 5.8 倍延迟上升获得 42.9% 带宽。因此深度 1 的损失与深度 8 的胜利是一个发现而非两个：零拷贝需要并发请求以在其下隐藏内存窗口 bind，而深度 1 下无可隐藏。
- 小传输现在也偏向零拷贝。4 KiB 时 iodepth 1 增益 8.9%、iodepth 8 增益 4.0%，每测量百分位延迟更低。
- 64 KiB 时两路径持平。iodepth 1 增益 5.1%、iodepth 8 损失 1.8% 是平局，按平局报告。最佳观察吞吐约 3.7 GiB/s，位于 40 Gb/s 服务端链路原始容量的 75% 附近，因此到线的余量现已狭窄。确定剩余上限位于何处需在同一两 NIC 间做独立于 DAOS 与此栈的原始 RDMA 带宽测试。

---

# 9 实测解决方案性能

## 9.1 测量范围与阅读指南

本章报告所测内容。它比较将文件数据送入昇腾 NPU 内存的两种方式。在暂存路径上，载荷先写入主机内存再继续拷入 NPU，这是无 NDS 时系统的行为。在直接路径上，载荷经 PCIe 网络直接送入 NPU 内存，任何点都不在主机内存中拷贝。本章每张图在同一硬件、同一会话、无其他改变的情况下比较这两条路径。

引用两条测量记录。第一条覆盖单 NPU，于 2026 年 8 月 2 日采集。第二条覆盖两块 NPU 同时从一个存储源加载，于 2026 年 8 月 3 日采集；此处使用其第二修订（在以正确请求大小限值重复整个 DPU 阶段之后）。第一修订的读数不使用。

**测量如何采集。** 两种方式到达存储：经 DPU 从 100 千兆网络上 DAOS 集群，以及从附于同一主机的固态盘。负载生成器为 fio，以 O_DIRECT 发随机读、每读者一个未完成请求，因此每个结果反映单请求延迟而非深队列。每点为三次重复均值。最大请求大小钉在 64 页即 256 KiB。图中给出的百分比为直接路径在同一工作点对暂存路径的测量。

**主机内存流量如何计数。** 部分图报告每交付字节的主机内存字节。该数为测量窗口内主机内存控制器所见流量除以实际交付到 NPU 的载荷。它是显示暂存代价在何处付出的量，机制在 6.6 节解释。

**这些结果不确立什么。** 写路径未演练。也未演练：超过两块 NPU 同时加载、两设备从独立存储源喂料、NPU 计算与同设备上直接 I/O 同时运行、高于一的队列深度、两设备研究中非 256 KiB 的传输大小，或任何真实人工智能应用。结果仅针对所列配置报告，不作进一步声明。

## 9.2 按传输大小与并发度的吞吐

直接路径在每个测量工作点都更快。在 otherwise 空闲主机上十二个读者时，优势随传输大小增长：4 KiB 时 4%、16 KiB 时 6%、64 KiB 时 18%、256 KiB 时 49%、1 MiB 时 52%。256 KiB 点是预期工作大小，吞吐从 5,481 升到 8,146 MiB/s。

改为按并发度读，在 256 KiB，模式反转：优势在少数读者活跃时最大 —— 一个读者时 94%、四个时 90% —— 并在十二个读者时收窄到 49%、二十四个时 19%，因两路径都接近链路极限。单读者列有一告诫：暂存路径在此不稳定，三次重复返回 493、984 与 490 MiB/s，因此应引用其范围而非单值。

**图 24**：直接路径相对暂存路径的吞吐，按传输大小与读者数量。

## 9.3 对主机内存压力的韧性

暂存路径与工作负载其余部分竞争同一主机内存带宽，因此当该内存系统繁忙时其吞吐下降。在 256 KiB、十二个读者、竞争流量升到 281 GB/s 时，暂存路径丢失 18.5% 吞吐而直接路径丢失 3.4%。因此直接路径的优势在负载下扩大，从空闲主机的 48.6% 到 76.1%。1 MiB 时同一效应更弱出现，暂存路径丢失 13.8%、直接路径 1.5%。

**图 25**：随主机内存竞争流量增加的吞吐。

## 9.4 本地 NVMe 路径

同一主机机制在完全排除 DPU 的情况下测量，从附于主机的固态盘读取。这隔离主机侧变更与 DPU 的任何贡献，且剖面与 9.2 节相反：增益在小传输时最大 —— 4 KiB 时 36 到 53% —— 并随传输增长缩小。原因是到本地盘的往返短，因此直接路径移除的固定每请求主机成本占更大份额。在二十四个读者、128 KiB 及以上传输时两路径收敛，因为两者都受盘的 PCIe 槽限制而非任一路径所为。

由此测量而非理论得出一个部署约束：盘与 NPU 必须位于同一根复合体。无对等可路由路径的对在传输映射时被网络拒绝，且无暂存拷贝回退。

**图 26**：从本地固态盘读取时直接路径的优势。

## 9.5 可重复性

直接路径明显比暂存路径更可重复。在每个工作点三次重复间，直接路径的离散度保持在 0.04 到 3.4%，而暂存路径从 1.2% 到单读者时 43%。可重复性对存储路径与速度同等重要：在相同运行间变动数十百分点的结果无法据此规划。直接路径还在不同日期、重建驱动与重启后以 0.2% 以内复现了早先会话的数字。

**图 27**：各工作点重复之间的离散度。

## 9.6 多 NPU 并行加载

九十四个有效测量点覆盖两块 NPU 同时从一个存储源加载，跨两种传输、在空闲主机与负载下、在 256 KiB。核心结果是每交付字节的主机内存成本属于路径而非设备数量：暂存路径经 DPU 在 1.93 到 2.30 之间，暂存路径从本地盘在 1.56 到 1.70 之间，直接路径在 0.07 到 0.16 之间 —— 无论喂一块还是两块设备。因此暂存路径上主机内存的聚合压力跟踪聚合交付带宽，而直接路径上保持平坦。

直接路径在此研究全部十六个工作点都更快。在空闲与负载臂上均稳定、应被引用的配置是两设备各两读者：空闲主机上快 90.8%、负载下快 103.9%。本地盘上直接路径在空闲主机上快 8.3 到 22.4%、负载下快 19.9 到 45.2%，且在主机繁忙时退化远少 —— 丢失 4.6 到 10.8% 而暂存路径丢失 13.9 到 25.4%。

随附的八设备数字是从每字节成本测量的投影，非测量。本文档无测试加载超过两设备，且机箱无法供给投影所假定的每设备带宽。

**图 28**：两块 NPU 同时加载：每交付字节的主机内存成本，以及八设备投影。

---

# 附录 A — 术语表

**表 20**：术语表

| 术语 | 含义 |
|------|------|
| ACS | Access Control Services — 治理/重定向端口间对等路由的 PCIe 特性集。 |
| AscendCL / ACL | Ascend Computing Language — 昇腾用户空间运行时 API（aclrt* 调用）。 |
| BAR4 | 昇腾 910B 的 64 GB 可预取 PCIe 基址寄存器区域，暴露 HBM。 |
| CaRT | Collective and RPC Transport — DAOS 基于 Mercury 的节点间消息层。 |
| CQ | Completion Queue — 轮询以收获 verbs 完成的完成队列。 |
| DAOS / DFS | Distributed Asynchronous Object Storage；DFS 是其类 POSIX 文件 API（dfs_*）。 |
| DPU | Data Processing Unit — 华为 SmartNIC（SPU ARM 核加 DPU 内部 NPU）。 |
| FSaaS / MaaS | File System / Memory as a Service — UDAA 参考服务（见 7.1 节）。 |
| FUSE | Filesystem in Userspace — 内核<->用户空间文件系统协议；virtio-fs 的协议。 |
| GPA / VFID | Guest Physical Address / Virtual Function ID — 用于跨 PCIe 寻址模型（见 7.3 节）。 |
| HBM | High-Bandwidth Memory — 昇腾 NPU 的设备内存，NDS DMA 目标。 |
| HCCS | Huawei Cache-Coherent System — 专有 NPU 到 NPU 互连（非 PCIe）。 |
| IOVA | I/O Virtual Address — 由 DPU IOMMU/重定向层管理的客户物理地址；ZC 模式下的直接 RDMA 目标。 |
| MR / MW / rkey | Memory Region / Memory Window / remote key — 授权远端 DMA 访问的 verbs 对象；Type-1 MW 在 ZC 模式下按 SGL 重 bind。 |
| MTU | Maximum Transmission Unit — RoCE 载荷包大小；驱动读的子 MTU 尾部处理（见 8.9 节）。 |
| NDS | NPU Direct Storage — 本项目；GPUDirect Storage 的昇腾对应物。 |
| NPU | 昇腾 Neural Processing Unit（本文档默认含义）；仅 DPU 内部图中指 Network Processing Unit — 见图 11 下注。 |
| O_DIRECT | POSIX 直接 I/O 标志，绕过页缓存 — NDS 路径的面向应用触发器。 |
| PD | Protection Domain — 分组 MR/MW/QP 的 verbs 命名空间；ZC 模式下每 PF 一个。 |
| PF | Physical Function — 对一个客户 VM / 租户可见的 PCIe VirtioFS function。 |
| pgmap / ZONE_DEVICE | 经 pci_p2pdma_add_resource() 给设备内存（此处为 BAR4）真实 struct page 的内核机制；使 NPU HBM 对通用 DMA 管线可见（见 6.1 节）。 |
| QP / RC | Queue Pair — verbs 收/发引擎；RC = Reliable Connection 传输（MW bind 所需）。 |
| RoCE | RDMA over Converged Ethernet — DPU<->DAOS 网络。 |
| SGL / SGE | Scatter-Gather List / Entry — 描述逻辑连续缓冲区的 {addr, len} 段。 |
| SPU | DPU 的 ARM 核区域，运行 UDAA 与服务代码（见 7.1 节）。 |
| SR-IOV / VF | Single-Root I/O Virtualization / Virtual Function — DPU 暴露模拟 virtio-fs 设备的方式。 |
| UDAA | Unified DPU Architecture API（见 7.1 节）。 |
| VPMD / UDK | DPU 数据面驱动（virtio 轮询模式驱动 / 驱动套件），UDAA 直接运行其上（见 7.2 节）。 |
| VQ / vring | Virtqueue — VirtIO 的基于环的批量传输（见 1.3 节）。 |
| ZC | Zero-Copy — NIC 直接 RDMA 写入客户 IOVA 页的 UDAA-DAOS 工作模式（见 8.9 节）。 |

---

# 附录 B — UDAA 平台定位（背景）

本附录收集更广的 UDAA 平台叙事，因它是背景而非 NDS 架构，故不放入主线。

UDAA 的指导愿景是成为"DPU 的 CUDA"：正如 CUDA 让开发者无需掌握 GPU 硬件即可利用它，UDAA 让团队无需学习低层华为栈即可构建 DPU 加速的基础设施服务。

它解决的问题有真实业务成本。历史上，每个在 DPU 上构建的团队都需要对硬件、微码与专用驱动的深入知识，这导致开发缓慢、各业务单元间工作重复，以及功能被锁定在少数专家手中。

UDAA 的答案是 DPU 构建块之上的单一抽象层与统一 API。这将专业平台转变为可广泛编程的平台，使应用跨 DPU 代可移植，并为所有业务单元与外部伙伴创建共享生态。

在 UDAA 之上，华为构建软件定义的基础设施服务，DPU 将其作为标准设备呈现给主机：FSaaS（文件系统即服务）与 MaaS（内存即服务，带热数据迁移的 DPU 服务内存池）。

---

# 附录 C — 相关文档

- 昇腾侧高层设计与每层微架构（专门文档）。
- 文件系统/DPU 侧高层设计与每层微架构（专门文档）。
- NDS 项目主文档（完整任务清单与长期路线图）。
- UDAA 框架概述与增强 UDAA 贡献分析。
- FSaaS 项目报告与 UDAA-DAOS 应用概述。

---

> 翻译完成。原文档共 949 个段落，本中文翻译保留了原文的章节结构、表格、代码块与图示说明，技术术语保留英文原词并附中文释义。