# NDS 接口梳理与 Mooncake 接入可行性分析

> **生成时间**：2026-08-31
> **分析依据**：
> - 本地 `NDS_实验复现报告.md`（实测取证，2026-08-29）
> - 本地 `NDS-Solution-Architecture-中文翻译.md`（NDS 解决方案架构 Issue 1.0，2026-07-13）
> - Mooncake TENT GDS 接入参考：https://shaojiemike.top/1-infer/2026/08/26/Mooncake-TENT-GDS/
>   （代码截面 Mooncake commit `89da2c3a`）
> **目标**：梳理 NDS 当前暴露了哪些接口（从 benchmark 与架构文档入手），判断接入 Mooncake（作为 TENT 的一个新 transport 后端，对标 GDS）时这些接口是否够用，给出缺口与接入路径建议。

---

## 1. 背景与目标对齐

### 1.1 NDS 是什么

**NDS = NPU Direct Storage**，是 NVIDIA GPUDirect Storage (GDS) 在华为昇腾生态中的对应物。在昇腾 910B NPU + 鲲鹏 + SP925D-VL DPU 平台上，让 virtiofs（virtio-fs）走 P2P DMA 直达 NPU HBM 显存，实现"存储 → NPU HBM"零拷贝，避免"存储 → 主机 DRAM → NPU"的 bounce 中转。

### 1.2 Mooncake TENT 是什么

Mooncake 的 TENT 是统一传输运行时，通过实现 `Transport` 基类契约接入不同后端。已接入的后端包括 GDS（基于 NVIDIA cuFile API）和 IOURING 等。**接入 NDS = 为 TENT 实现一个新 transport 后端（类比 `GdsTransport`），把 NDS 的能力包装成 TENT 契约。**

### 1.3 关键对照关系

| 概念 | GDS（NVIDIA 生态） | NDS（华为昇腾生态） |
|------|---------------------|---------------------|
| 加速器内存 | GPU HBM（CUDA buffer） | NPU HBM（Ascend ACL buffer） |
| 直存机制 | cuFile API | virtiofs + P2P 内存映射 |
| 文件访问 | cuFile handle + batch API | POSIX O_DIRECT read/write 到 virtiofs 挂载点 |
| 零拷贝对象 | GPU ↔ 文件 | NPU HBM ↔ 文件 |

**接入 Mooncake 时，NPU 在 TENT 中对应 GPU 的角色，NPU HBM 对应 CUDA buffer。**

---

## 2. NDS 当前暴露的接口梳理

NDS 的接口分四层，从架构文档（设计预期）与实验报告（实测实现）交叉确认。

### 2.1 运行时层：P2P 内存映射 API（核心新增接口）

这是 NDS 唯一新增的、面向应用的运行时 API，**位于数据面之外**，作用是把已分配的 NPU HBM 暴露成一个主机可用的虚拟地址视图，供 POSIX 文件 I/O 直接写入。

**设计文档预期的产品 API**（架构文档 §6.4「新 API」、§6.6 应用层示例）：

```c
aclError aclrtRegisterP2P(void *devPtr, size_t size, aclrtP2PRegInfo *out);
aclError aclrtUnregisterP2P(void *devPtr);
// out->mappedVa 即同一物理 HBM 的第二个、主机可用的虚拟地址
```

**实测实现（实验报告 §1、§4.1）**：在 Ascend CANN runtime v9.0.0 移植中实际落地的命名为：

- `aclrtMemP2PMapHost` —— P2P 内存映射
- `aclrtMemP2PUnmapHost` —— P2P 内存取消映射

两者通过移植后的运行时库暴露，需 `LD_PRELOAD` 六个 staging 库：

```
libascend_dump.so  liberror_manager.so  libruntime_common.so
libruntime.so  libacl_rt_impl.so  libacl_rt.so
```

库位置：`/root/tomer/nds/runtime-v9.0.0/build/_CPack_Packages/makeself_staging/runtime/lib/`

> ⚠️ **命名差异提示**：设计文档称 `aclrtRegisterP2P`/`aclrtUnregisterP2P`（标注为"预期产品接口"），实测实现为 `aclrtMemP2PMapHost`/`aclrtMemP2PUnmapHost`。接入前需确认实测命名是否已稳定为产品 API，或两者是否为同一接口的不同命名阶段。

### 2.2 数据面接口：普通 POSIX（不变）

架构文档 §2.3「面向应用的模型」明确：

> 数据面接口是普通 POSIX：带 O_DIRECT 的 open/read/write。由于 NDS 不需要 cuFile 式的 I/O 库，现有应用、数据加载器和 AI 框架无需任何改写即可受益。

**NDS 之后的完整读路径（架构文档 §6.6）**：

```c
// 1. 用现有未修改的 P2P 分配策略分配 NPU HBM
void *devPtr = nullptr;
aclrtMalloc(&devPtr, size, ACL_MEM_MALLOC_HUGE_FIRST_P2P);

// 2. 注册第二主机可用视图（NDS 新 API）
aclrtP2PRegInfo info = {0};
aclrtRegisterP2P(devPtr, size, &info);   // info.mappedVa = 主机可用 VA

// 3. 从 virtiofs 文件直接读入 NPU HBM，零拷贝
int fd = open("/mnt/virtiofs/dataset.bin", O_RDONLY | O_DIRECT);
read(fd, info.mappedVa, size);           // DPU -> NPU HBM
close(fd);

// ... 在 devPtr 上做 NPU 计算 ...

aclrtUnregisterP2P(devPtr);
aclrtFree(devPtr);
```

**关键性质**：
- 数据面是**同步** POSIX 系统调用，没有原生异步/批量 I/O API。
- 文件路径是 virtiofs 挂载点（实测 `/mnt/daos`，由 `nds_a2_up.sh` 拉起）。
- 对齐契约：偏移与长度必须 4 KB 对齐（FUSE 补丁强制）。
- 无静默弹跳回退：未对齐返回 `-EINVAL`，拓扑不兼容返回 `-EREMOTEIO`。

### 2.3 验证/测试接口（非生产，但可从 benchmark 反推能力）

实验报告 §1、§4.1、§5.5：

- **fio 自定义引擎** `ascend_nds.so`（源码 `ascend_nds.c`，20KB）：
  - 三种模式：`p2p` / `bounce` / `p2pw`
  - 自带 **async worker pool**（在用户态把同步 POSIX I/O 调度成异步）
  - 参数：`--mode`、`--devid`（6=DPU/virtiofs，3=本地 NVMe）、`--cpu_base`、`--cpu_stride`
  - 门禁：拒绝 p2pw 外的写、numjobs>1、verify≠none、bs<4K、p2p 映射 >2GiB 等
- **字符设备映射路径**：fio 验证通过 `/dev/davinci_zonedev<N>` 直接映射 BAR4 区域（架构文档 §6.4 明确这是验证路径，**非产品 API**，不调用 `aclrtRegisterP2P`）。

> 💡 **从 benchmark 入手的启示**：fio 引擎的 async worker pool 证明了一件事——**NDS 数据面本身是同步的，异步性目前完全靠上层（fio 引擎）在用户态用线程池模拟**。这一点对接入 Mooncake 至关重要（见 §5）。

### 2.4 底层与环境接口

| 类别 | 接口/路径 | 说明 |
|------|-----------|------|
| 文件系统 | `mount -t virtiofs daosfs /mnt/daos` | virtiofs 挂载，由 `nds_a2_up.sh` 拉起 |
| NPU 设备 | `/dev/davinci_zonedev0-7` | 8 颗 NPU，字符设备 |
| HAL | `libascend_hal.so` | 含 `"Addr should be p2p mem"` 字符串 |
| 内核 | FUSE P2P 补丁 + PCI p2pdma + HiSilicon whitelist | 6-commit 补丁集，使 FUSE 接受 P2P 页 |
| DPU 固件 | `UDAA_Hi1823_chip_solution` | 向主机暴露 virtio-fs/virtio-9p 设备 |
| 存储 | DAOS 2.6.5.p1 over RoCE | 后端存储集群 |

### 2.5 NDS 接口清单汇总

| # | 接口 | 层次 | 类型 | 状态 |
|---|------|------|------|------|
| 1 | `aclrtRegisterP2P` / `aclrtUnregisterP2P`（设计预期） | 运行时 | P2P 内存映射 | 预期产品 API |
| 2 | `aclrtMemP2PMapHost` / `aclrtMemP2PUnmapHost`（实测） | 运行时 | P2P 内存映射 | 已实现（runtime-v9.0.0） |
| 3 | `aclrtMalloc(..., ACL_MEM_MALLOC_HUGE_FIRST_P2P)` | 运行时 | HBM 分配 | 复用现有 ACL API |
| 4 | `open/read/write` + `O_DIRECT`（到 virtiofs） | 数据面 | 同步 POSIX | 已可用 |
| 5 | `ascend_nds.so` fio 引擎（p2p/bounce/p2pw + async pool） | 测试 | 验证用 | 已可用（非产品） |
| 6 | `/dev/davinci_zonedev<N>` BAR4 映射 | 验证 | 字符设备 | 验证路径（非产品） |

---

## 3. Benchmark 佐证接口可用性

实验报告 §6.1 最终 2x2 对比结果（存储层为 DRAM tmpfs，差异纯粹来自主机侧投递路径）：

| 后端 | bs | mode | 带宽(MiB/s) | p50(µs) | p99(µs) |
|------|----|------|------------|---------|---------|
| DPU/virtiofs | 256k | bounce | ~5770 | 529 | 865 |
| **DPU/virtiofs** | **256k** | **p2p** | **~8140** | **360** | **530** |
| 本地 NVMe | 256k | p2p | ~4800 | 599 | — |

**核心结论**：
- DPU 256k P2P ~8.1 GB/s vs bounce ~5.8 GB/s，**P2P 快约 40%，p99 更低**。
- ACL E2E 验证日志含 `via aclrtMemP2PMapHost (ACL API)`，证明 P2P 加速确实经由 `aclrtMemP2PMapHost` zero-copy 路径产生。
- **接口层面**：`aclrtMemP2PMapHost` + POSIX read/write 已能跑通端到端 zero-copy 数据面，接口可用性已被 benchmark 证实。

> ⚠️ **性能层面的未完成缺口**（不影响接口够不够用的判断，但影响实机性能）：实验报告 §1、§8.8 指出 virtio_ring 在任何内核版本都无 P2P DMA 感知，当前 P2P 加速靠 NPU 侧 `aclrtMemP2PMapHost` zero-copy 绕过 virtio_ring 限制；端到端 virtiofs P2P 仍需 3-5 个 virtio_ring 补丁。

---

## 4. Mooncake TENT 对新后端的接口契约

参考文章基于 Mooncake commit `89da2c3a` 代码截面，明确了一个新 transport 后端（类比 GDS）必须实现的完整契约。

### 4.1 Transport 基类契约（新后端必须回答的问题）

| TENT 接口 | 后端必须回答的问题 | GDS 的答案（参考） |
|-----------|-------------------|-------------------|
| `install/uninstall` | 怎样初始化配置、依赖、全局资源；怎样停止清理 | 保存 runtime，设置 depth/caps；清理 batch/pool/元数据 |
| `capabilities` | 能处理哪些本地内存与 Segment 组合 | `dram_to_file=true`、`gpu_to_file=true` |
| `allocateSubBatch` | 一组请求需要哪些稳定存储、队列槽位、底层 handle | 分配 GdsSubBatch，复用/创建 batch handle |
| `freeSubBatch` | 何时能安全复用或销毁底层资源 | 正常回池；仍被引用的进 quarantine |
| `submitTransferTasks` | 怎样把 TENT Request 翻译、切片并**异步提交** | 构造 CUfileIOParams_t，调 `cuFileBatchIOSubmit` |
| `getTransferStatus` | 怎样**轮询**、聚合进度和错误 | `cuFileBatchIOGetStatus` + slice event 聚合 |
| `add/removeMemoryBuffer` | 是否需要预注册本地内存，怎样管理生命周期 | CUDA buffer 调 `cuFileBufRegister/Deregister` |
| `getName` | 怎样标识后端 | 返回 `"gds"` |
| cancellation | 已提交工作能否取消 | GDS 未公开 task cancel；内部 batch cancel 仅失败清理 |

**关键约束（参考文章反复强调）**：
- TENT 的 `Transport` 基类很多方法默认返回 `NotImplemented`，"能编译"≠"后端已接通"。
- 最容易漏掉的是 `freeSubBatch` 的安全条件：异步设备仍可能引用参数/用户 buffer 时释放会变成 use-after-free。
- 不能只替换 `submitTransferTasks`，必须实现从 `install` 到 `freeSubBatch` 的**完整异步契约**，尤其是"底层何时不再引用参数和用户内存"这个终态边界。
- 还需接通四个位置：①类型与名字（TransportType + 字符串解析 + 绑定）②构建与装载（CMake + TransportLoader）③选择策略（Segment/内存/capability 优先级与回退）④Segment/Buffer 语义（能否复用 `file://` 和现有内存注册）。

### 4.2 GDS 实际使用的 cuFile API（参考标杆）

| API 族 | 代表接口 | GDS 是否用 | TENT 职责 |
|--------|----------|-----------|-----------|
| 驱动生命周期 | `cuFileDriverOpen/Close` | 用 Open | 构造时 `call_once` 初始化 |
| 文件句柄 | `cuFileHandleRegister/Deregister` | 是 | POSIX fd 登记为 CUfileHandle_t |
| GPU buffer | `cuFileBufRegister/Deregister` | 是 | 登记/注销 CUDA buffer |
| 同步 I/O | `cuFileRead/Write` | 否 | TENT 不走逐次同步 |
| **Batch I/O** | `cuFileBatchIOSetUp/Submit/GetStatus/Cancel/Destroy` | **是** | SubBatch 创建/提交/轮询/取消/销毁 |
| stream 异步 | `cuFileReadAsync/WriteAsync` | 否 | 不以 CUDA stream 为完成模型 |

**核心观察**：GDS 后端走的是 **Batch I/O 异步模型**（SetUp → Submit → GetStatus 轮询 → Destroy），同步 `cuFileRead/Write` 和 stream 异步都没用。

---

## 5. 逐项对照分析：NDS 接口 vs Mooncake 契约

### 5.1 两种接口模型的本质差异

| 维度 | NDS 模型 | Mooncake GDS 模型 |
|------|----------|-------------------|
| 范式 | **内存映射 + 同步 POSIX** | **批量异步文件 I/O** |
| 加速器内存暴露 | `aclrtRegisterP2P` 映射成主机 VA | `cuFileBufRegister` 注册 CUDA buffer |
| 文件 I/O | 同步 `read/write` 系统调用 | 异步 `cuFileBatchIOSubmit` + 轮询 |
| 异步性来源 | 上层用户态线程池（fio 引擎） | 底层 cuFile batch API 原生异步 |
| 批量化 | 无（每次 read/write 独立） | 有（SubBatch + slice 切片） |
| 文件句柄 | POSIX fd 直接用 | `cuFileHandleRegister` 包装 fd |

### 5.2 Transport 契约逐项对照

| TENT 契约 | NDS 现状 | 够不够用 | 说明 |
|-----------|----------|---------|------|
| `install/uninstall` | 有环境拉起脚本 `nds_a2_up.sh`；运行时库需 LD_PRELOAD 六个 .so | 🟡 部分 | 需把"拉起 + LD_PRELOAD + runtime 初始化"包装成 `install`；无现成单点初始化 API |
| `capabilities` | NDS 本质是 NPU_HBM↔File（对应 `gpu_to_file`）；普通 host buffer 也能 read/write virtiofs（`dram_to_file`） | 🟢 够用 | 声明 `dram_to_file=true`、`gpu_to_file=true`（NPU 当 GPU） |
| `allocateSubBatch` | 无批量 I/O handle 概念，每次 read/write 独立系统调用 | 🔴 不够 | **需新建批量管理层**（类似 GdsSubBatch：参数数组 + 事件数组 + 完成缓存） |
| `freeSubBatch` | 同步 I/O 完成即返回，无异步引用残留问题 | 🟡 部分 | 若用线程池包装异步，需保证池中在途请求完成前不复用 SubBatch |
| `submitTransferTasks` | 仅同步 POSIX read/write，**无异步提交 API** | 🔴 不够 | **最大缺口**。需在 NDS 之上构建异步提交层（线程池 dispatch 同步 read/write，返回 immediately） |
| `getTransferStatus` | 同步 I/O 无独立轮询 | 🔴 不够 | 需配合异步层实现：查线程池 future / completion queue |
| `addMemoryBuffer` | `aclrtRegisterP2P`/`aclrtMemP2PMapHost` 把 NPU HBM 映射成主机 VA | 🟢 够用 | **核心匹配点**。语义对应 `cuFileBufRegister`：把加速器内存登记为 I/O 可用 |
| `removeMemoryBuffer` | `aclrtUnregisterP2P`/`aclrtMemP2PUnmapHost` | 🟢 够用 | 对应 `cuFileBufDeregister` |
| `getName` | — | 🟢 够用 | 返回 `"nds"` |
| cancellation | 同步 I/O 可被信号中断，无批量取消 | 🟡 部分 | `supportsCancellation` 可返回 false（GDS 也未真正支持 task cancel） |
| 文件句柄管理 | POSIX fd 直接用（virtiofs 文件） | 🟢 够用 | NDS 本身就是 POSIX 语义，可直接用 fd，无需额外 handle 注册层 |
| Segment 语义 | virtiofs 挂载点 `/mnt/daos` 下文件 = POSIX 路径 | 🟢 够用 | 可直接复用 TENT 的 `file://` Segment，无需新 Segment 类型 |

### 5.3 对照结论速览

- 🟢 **直接够用**（4 项）：`capabilities`、`add/removeMemoryBuffer`（P2P 映射 API）、`getName`、文件句柄/Segment 语义。
- 🟡 **部分够用，需包装**（4 项）：`install/uninstall`、`freeSubBatch`、cancellation。
- 🔴 **不够用，是主要缺口**（3 项）：`allocateSubBatch`、`submitTransferTasks`、`getTransferStatus` —— **即整个异步批量 I/O 层**。

---

## 6. 结论与接入路径建议

### 6.1 总体判断

> **NDS 的"加速器内存暴露"能力（`aclrtRegisterP2P`/`aclrtMemP2PMapHost`）与 Mooncake 的 `addMemoryBuffer`/`cuFileBufRegister` 语义匹配，且 NPU HBM ↔ File 对应 TENT 的 `gpu_to_file` capability，文件/Segment 可直接复用 POSIX 语义——接入的基础是够用的。**
>
> **但 NDS 当前只暴露同步 POSIX read/write 数据面，没有暴露原生异步批量 I/O API；而 TENT Transport 契约要求 `submitTransferTasks`（异步提交）+ `getTransferStatus`（轮询）+ `allocateSubBatch`/`freeSubBatch`（批量管理）这一整套异步批量契约。这是接入的主要缺口，需要在 NDS 之上额外构建一层异步批量包装。**

### 6.2 接入路径建议

#### 路径 A（推荐）：薄包装路径——在 NDS 之上用线程池实现异步批量契约

**思路**：NDS 的 P2P 映射保证 zero-copy 数据面，异步性由包装层（线程池）提供，把同步 POSIX read/write 调度成符合 TENT 契约的异步批量 I/O。

**实现要点**：
1. `NdsTransport::install`：拉起 virtiofs（或假定已拉起）、设置 LD_PRELOAD/runtime、初始化线程池。
2. `NdsTransport::addMemoryBuffer`：对 NPU HBM buffer 调 `aclrtMemP2PMapHost`，得到主机可用 VA，存入 transport 私有 context。
3. `NdsTransport::allocateSubBatch`：分配请求槽位数组 + completion 记数（无底层 batch handle，因为 NDS 没有这层）。
4. `NdsTransport::submitTransferTasks`：把每个 TENT Request 翻译成一次 `read(fd, mappedVa + offset, len)` / `write(...)`，投递到线程池，立即返回；记录 future/槽位。
5. `NdsTransport::getTransferStatus`：查线程池 completion，按 task 聚合完成字节数与状态。
6. `NdsTransport::freeSubBatch`：等待所有在途请求终态后再复用（关键安全条件）。
7. `capabilities`：`dram_to_file=true`、`gpu_to_file=true`。
8. 选择策略：在 `transport_selector` 中为 `file://` Segment + NPU 内存类型加入 NDS 候选（优先级可置于 GDS 之后或并列，取决于运行时是否有 NPU）。

**工作量评估**：中等。核心是写一个 `NdsTransport` 类 + 线程池调度，参照 `GdsTransport` 的三层映射（Request → IOParamRange → slice）简化为（Request → 单次 POSIX I/O → 槽位）。NDS 的 fio 引擎 `ascend_nds.c` 的 async worker pool 可作为线程池实现的现成参考。

**优点**：不依赖 NDS 后续开发；可立即推进；zero-copy 由 NDS 保证。
**缺点**：异步性是用户态线程池模拟，非硬件原生异步；批量提交的并发度受线程池大小限制，可能不如 cuFile batch 的硬件队列。

#### 路径 B：等 NDS 暴露原生异步批量 I/O API

若 NDS runtime 侧后续新增类似 cuFile batch 的异步批量接口（当前架构文档与实验报告中**均无此规划**），则可直接对接，性能更优。**当前不可行，依赖 NDS 团队后续开发。**

#### 路径 C：复用 fio 引擎的 async pool 思路，但走 IOURING 回退

TENT 已有 IOURING 后端。若 NPU HBM 能通过 `aclrtMemP2PMapHost` 暴露为主机 VA，理论上可让 TENT 的 IOURING 后端直接对该 VA 做 `io_uring` 异步 I/O 到 virtiofs 文件——即**不写新 transport，复用现有 IOURING**，仅在 `addMemoryBuffer` 阶段做一次 NDS P2P 映射。

> ⚠️ 此路径需验证：IOURING 后端是否接受非普通 host DRAM 的 mapped VA（ZONE_DEVICE P2P 页）作为 I/O buffer。若接受，则是**工作量最小的路径**（只需在 buffer 注册环节插入 NDS 映射）。这是值得优先 spike 验证的方向。

### 6.3 接入必须额外接通的四个位置（参考文章 §4.2）

1. **类型与名字**：在 `TransportType` 枚举、字符串解析、C/Python 绑定中加入 `NDS` 类型。
2. **构建与装载**：CMake 找到 Ascend CANN runtime SDK 后定义构建宏（如 `USE_NDS`），`TransportLoader` 根据配置 `transports/nds/enable` 创建实例。
3. **选择策略**：为 `file://` Segment + NPU 内存类型配置 NDS 优先级与回退（如 `NDS → IOURING`）。
4. **Segment/Buffer 语义**：复用 `file://` Segment（指向 virtiofs 路径）；NPU buffer 通过 transport 私有 context 承载 `aclrtMemP2PMapHost` 返回的 mapped VA。

---

## 7. 风险与前置条件

| # | 风险/前置 | 影响 | 建议 |
|---|----------|------|------|
| 1 | **API 命名未稳定**：设计文档称 `aclrtRegisterP2P`，实测为 `aclrtMemP2PMapHost`，且文档标注前者为"预期产品接口" | 接入可能踩到非稳定 API | 接入前向 NDS runtime 维护者确认产品 API 命名与稳定性；优先用 `aclrtMemP2PMapHost`（已有 benchmark 佐证） |
| 2 | **247 构建节点未登录**（实验报告 §8.1） | runtime 源码主仓库不可达，无法改 runtime 侧 | 路径 A/C 不改 runtime 则不受影响；若需路径 B 则必须拿到 247 访问权 |
| 3 | **virtio_ring 无 P2P 感知**（实验报告 §8.8） | 端到端 virtiofs P2P 仍有缺口，当前靠 NPU 侧 zero-copy 绕过 | 不影响接口契约接入，但影响实机性能；接入后需在真机上重测带宽 |
| 4 | **NPU vs GPU 角色映射**：Mooncake 是 CUDA 生态，`location.type()=="cuda"` 判断需扩展 | buffer 注册分支可能漏掉 NPU | 在 `addMemoryBuffer` 中识别 Ascend NPU 内存类型（非 `"cuda"`），走 `aclrtMemP2PMapHost` 分支 |
| 5 | **对齐契约**：NDS 要求 4 KB 对齐；TENT/GDS 用 16 MiB slice | 不对齐请求会被 NDS 拒绝（-EINVAL） | 在 `submitTransferTasks` 切片时保证每片 4 KB 对齐（GDS 的 16 MiB slice 天然满足，但需确认 offset 对齐） |
| 6 | **p2p 映射 >2GiB 限制**（fio 引擎门禁） | 单次映射大小受限 | 大 buffer 需分段映射，或在 `addMemoryBuffer` 中按 2GiB 分块注册 |
| 7 | **同步 I/O 的取消语义** | `supportsCancellation` 若声明 true 必须实现 `cancelTransferTask` 且遵守 best-effort 契约 | 建议初期声明 `false`（与 GDS 一致），仅做失败清理 |
| 8 | **下游消费者冲突**：A2-110 的 `itamaro` 在做 vllm+lmcache+NDS 集成（实验报告 §8.12） | 改动 NDS runtime/引擎需同步知会 | 接入工作若触及 runtime，需与该下游协调 |

---

## 8. 一句话结论

**NDS 暴露的 P2P 内存映射接口（`aclrtMemP2PMapHost`/`aclrtRegisterP2P`）足以承担 Mooncake TENT 后端所需的"加速器内存登记"职责，文件与 Segment 语义可直接复用 POSIX——接入基础够用；但 NDS 数据面是同步 POSIX，缺少 TENT 要求的异步批量 I/O 契约（`submitTransferTasks`/`getTransferStatus`/`allocateSubBatch`），需在 NDS 之上用线程池包装一层异步批量（路径 A），或优先 spike 验证能否复用 TENT 现有 IOURING 后端 + NDS 映射（路径 C，工作量最小）。**

---

## 附录：关键源码/文档索引

### NDS 侧
- 运行时源码：`/root/tomer/nds/runtime-v9.0.0/`（A2-110），主仓库在 247 节点 `/home/tomer/NDS-Ascend`（分支 `e2e/runtime-v9.0.0`）
- staging 库：`.../build/_CPack_Packages/makeself_staging/runtime/lib/`（含 P2P 符号）
- fio 引擎源码：`/root/tomer/fio/engine/ascend_nds.c`（async worker pool 参考）
- 架构文档：本地 `NDS-Solution-Architecture-中文翻译.md`（§2.3 应用模型、§6.4 新 API、§6.6 应用示例）
- 实验报告：本地 `NDS_实验复现报告.md`（§1 接口、§6 benchmark）

### Mooncake 侧（commit `89da2c3a`）
- Transport 基类：`tent/include/tent/runtime/transport.h`
- 引擎实现：`tent/src/runtime/transfer_engine_impl.cpp`
- GDS 后端：`tent/src/transport/gds/gds_transport.cpp`（接入新后端的最佳参照）
- 装载器：`tent/src/runtime/transport_loader.cpp`
- 选择器：`tent/src/runtime/transport_selector.cpp`