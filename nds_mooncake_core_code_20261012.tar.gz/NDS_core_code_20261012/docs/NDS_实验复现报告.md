# NDS（NPU Direct Storage）实验复现报告

> **生成时间**：2026-08-29（已登录两台节点实地取证并修正）
> **数据来源**：登录 A2-110（71.14.10.110）与 storage_os（71.14.11.77）实地取证，阅读文件系统、`.bash_history`、脚本、实验结果 CSV、DAOS 配置、DPU 固件配置
> **原开发者**：Tomer Cigler（工号 t00823972，突然离职，无交接文档）
> **取证人**：t00906153

---

## 1. 项目概述

**NDS = NPU Direct Storage**。在华为昇腾 910B NPU + 鲲鹏 + SP925D-VL DPU 平台上，让 **virtiofs（virtio-fs）走 P2P DMA 直达 NPU HBM 显存** 的内核/运行时性能优化项目。核心目标：避免"存储→主机 DRAM→NPU"的 bounce 中转拷贝，实现"存储→NPU HBM"零拷贝（zero-copy）。

技术栈分四层：
1. **DPU 固件层**：SP925D-VL（Hi1823 芯片）运行 `UDAA_Hi1823_chip_solution` 固件，向主机暴露 virtio-fs/virtio-9p 设备，后端通过 100Gb RoCE 连 DAOS。
2. **内核层**：给 OLK-6.6 内核打 P2P DMA 补丁（FUSE/virtio/PCI p2pdma），使 virtiofs 能接受 P2P 页。
3. **运行时层**：移植 Ascend CANN runtime 到 v9.0.0，新增 `aclrtMemP2PMapHost` / `aclrtMemP2PUnmapHost` 两个 P2P 内存映射 API。
4. **测试层**：自定义 fio 引擎 `ascend_nds.so`，用 bounce vs p2p 两种模式对比测吞吐/延迟。

关键发现文档 `/root/virtio-ring-no-p2p-finding.md`（A2-110 上，2026-07-20）指出：**virtio_ring 在任何内核版本都没有 P2P DMA 感知**，当前补丁集让 FUSE 层能"接受"P2P 页，但 virtio 传输层无法"投递"它们——这是项目未完成的核心缺口。当前实验能跑出 P2P 加速，是靠 NPU 侧 `aclrtMemP2PMapHost` 做 zero-copy 绕过了 virtio_ring 限制。

---

## 2. 多设备登陆与组织关系

### 2.1 设备拓扑（已实测确认）

| 角色 | 主机名 | 管理 IP | DPU 内网 IP | 登录凭据 | OS / 内核 | 状态 |
|------|--------|---------|------------|----------|----------|------|
| **A2（应用/测试节点）** | `A2-110` | `71.14.10.110/24`（eno5/enp189s0f0） | `192.168.2.110`（DPU 侧，主机 OS 不可见但 storage_os 可 ping 通） | root / `Huawei@12#$` | openEuler 24.03 SP3 / 6.6.0-132 | ✅ 已登录 |
| **storage（DAOS 存储 + DPU 固件配置）** | `storage_os` | `71.14.11.77/24`（eno5） | `192.168.2.254/24`（enp65s0f1，UP） | root / `Huawei@12#$` | openEuler 22.03 SP4 / 5.10.0-216 | ✅ 已登录 |
| **DPU（数据加速卡）** | SP925D-VL / Hi1823 | — | `192.168.2.110 ↔ 192.168.2.254` | 固件层，由 storage_os 上 `UDAA_Hi1823_chip_solution` 配置 | — | 运行中，向 A2-110 暴露 virtio 设备 |
| **247（runtime 构建节点）** | hostname 含 `247` | IP 待确认（A2-110 known_hosts 有 `70.252.19.4`） | — | 未知 | — | ❌ 未登录（仅从 A2-110 history 推断） |

### 2.2 完整数据路径

```
A2-110 (fio P2P引擎 ascend_nds.so)
  ↓ NPU HBM zero-copy (aclrtMemP2PMapHost, devid=6)
  ↓ virtiofs 客户端 (PCI 0000:43:00.7 = 1af4:105a)
  ↓ DPU (SP925D-VL / Hi1823 固件, PCIe x16, 3455 virtio 队列对)
  ↓ 100Gb RoCE (ofi+verbs;ofi_rxm)
  ↓ storage_os (DAOS 2.6.5.p1, daos_engine 16 targets)
  ↓ /mnt/daos0 (DRAM tmpfs 132G, 故意不用磁盘)
```

### 2.3 各节点职责

- **A2-110（71.14.10.110）**：测试/验证节点。8 颗 NPU（`/dev/davinci_zonedev0-7`），跑 fio 引擎、demo 套件、回归测试。`/root/tomer/` 是主工作目录。内核 6.6 带 P2P 补丁。
- **storage_os（71.14.11.77）**：① **DAOS 存储服务器**（`daos_server` + `daos_engine` 运行 33 天，版本 2.6.5.p1，监听 10001）；② **DPU 固件配置调查节点**（`/root/boris_corner/UDAA_Hi1823_chip_solution`，调查 multi-host/PCIe/virtio 拓扑）。`/root/tomer/` 有 demo 监控脚本和日志。history 显示从它能 `ssh 192.168.2.110` 连 A2-110。
- **247**：runtime 源码编写/构建节点（第三个独立节点）。持有 `/home/tomer/NDS-Ascend`（git 仓库，分支 `e2e/runtime-v9.0.0`）、`/home/tomer/br_milan_v100r001c21_main`。负路径测试 `negpath.c` 在 247 上编写，打包后传到 A2-110 执行。**IP 与凭据未知，需找管理员确认**。
- **DPU（SP925D-VL）**：通过 PCI 桥 `0000:43:00` 向 A2-110 暴露 virtio 设备（见下表），固件由 storage_os 上的 `UDAA_Hi1823_chip_solution` 构建/配置。

### 2.4 A2-110 上的 virtio/DPU PCI 设备（`lspci -Dn`）

| BDF | 厂商:设备 | 类 | 含义 |
|-----|-----------|-----|------|
| `0000:43:00.0` / `.2` | `19e5:0224` | 0200 | 华为 HNIC 网卡（DPU 通道） |
| `0000:43:00.1` | `1af4:1053` | 0200 | virtio-net |
| `0000:43:00.3-6` | `1af4:0996` | 0200 | virtio-9p ×4（4 个 9p 通道） |
| **`0000:43:00.7`** | **`1af4:105a`** | 0200 | **virtio-fs**（DAOS 后端函数，`nds_a2_up.sh` 健康检查项） |

NPU（`19e5:d802`，类 1200 Accelerator）共 8 颗：`01:00`、`02:00`、`41:00`、`42:00`、`81:00`、`82:00`、`c1:00`、`c2:00`。

### 2.5 网络实测

- **A2-110**：`enp189s0f0` UP `71.14.10.110/24`，默认网关 `71.14.10.1`。`ping 71.14.11.77` ✅（0.3ms）。`ping 192.168.2.254/109` ❌（主机 OS 看不到 DPU 内网，DPU 网卡在固件层）。
- **storage_os**：`eno5` UP `71.14.11.77/24`；`enp65s0f1` UP `192.168.2.254/24`（DPU 内网）；`enp65s0f0` UP `192.168.100.1/24`。`ping 192.168.2.110` ✅（0.08ms，A2-110 的 DPU 侧可达）；`ping 71.14.10.110` ✅（0.08ms）。
- **storage_os known_hosts**：`71.14.11.75/76/79`（同网段其他存储节点）、`192.168.2.110`、`71.14.10.110`、`71.14.10.109`。
- **注意**：用户原说的"数据节点 192.168.2.109/24"实际是 **192.168.2.254**（storage_os 的 enp65s0f1）。192.168.2.109 不在线。

---

## 3. 实验虚拟环境

**不是虚拟机/容器环境，而是裸机 + 内核补丁 + DPU + DAOS 直连**：

### 3.1 A2-110（应用节点）
- **OS**：openEuler 24.03 SP3，内核 `6.6.0-132.0.0.111.oe2403sp3.aarch64`（ARM64）。
- **内核源码**：`/usr/src/linux-6.6.0-132*/`（OLK-6.6）。
- **fuse 模块**：已打补丁加载，`srcversion = A40B06664FFF3F314A82438`。
- **NPU 驱动**：`Version=25.2.0.b099`，`Innerversion=V100R001C21SPC010B226`，`ascendhal_version=7.35.23`（`/root/run_extract_v18/version.info`）。
- **HAL**：`/usr/local/Ascend/driver/lib64/driver/libascend_hal.so`，期望 md5 `135f4ea2f9e52f52771185860be0d966`，含字符串 `"Addr should be p2p mem"`。
- **CANN**：`/usr/local/Ascend/cann/`（`set_env.sh`）。
- **存储挂载**：`/mnt/TRC` ← `/dev/nvme0n1`（ext4，本地 NVMe 源数据盘）；`/mnt/daos` ← virtiofs `daosfs`（**当前未挂载**，需 `nds_a2_up.sh` 拉起）。
- **关键 sysctl**：`fs.fuse.max_pages_limit=64`（**必须在 mount 前设置**，默认 256 与后端 1024 不匹配会 wedge）。
- 无 virsh 虚拟机、无运行中 docker 容器、无 apptainer 实例。开发通过 vscode-server remote + kilo（kilocode AI 扩展）。
- 另一活跃用户 `itamaro`（`/home/itamaro`）在做 **vllm + lmcache + NDS 集成**，是下游消费者。

### 3.2 storage_os（存储节点）
- **OS**：openEuler 22.03 SP4，内核 `5.10.0-216.0.0.115.oe2203sp4.aarch64`。
- **DAOS 2.6.5.p1**（`/opt/daos-2.6.5.p1/`）：`daos_server` + `daos_engine` 运行中，监听 `192.168.2.254:10001`，provider `ofi+verbs;ofi_rxm`（RoCE），fabric_iface `enp65s0f1`，16 targets + 4 helpers。
- **DAOS 存储**：`/mnt/daos0` 是 **DRAM tmpfs 132G**（故意不用磁盘——`d_storage.sh` 注释明确：确保 bounce vs p2p 唯一变量是主机侧投递路径，而非存储设备）。pool `mypool` 120GB，24% 已用。
- **NVMe**：`nvme0n1`（2.9T）、`nvme1n1`（5.8T）存在但 DAOS 未使用（用 RAM tmpfs）。
- **DPU 固件源码**：`/root/boris_corner/UDAA_Hi1823_chip_solution`（Hi1823 芯片方案，git 仓库）。
- **DPU 驱动/SDK**：`/root/driver/DPU-Driver_17.12.5.0`、`SP925D-VL-sdk_17.12.5.0`、`/root/toCompute/firmware`。

### 3.3 DPU 固件配置（storage_os 上 `eth_2x100G_dpu_ecs_blk.xml` 关键字段）

| 字段 | 值 | 含义 |
|------|-----|------|
| `board_type` | 102 | 板型 |
| `scenes_id` | 100 | 场景 |
| `port_num` | 2 | 2 个 100G 端口 |
| `pcie_width` | 16 | PCIe x16 |
| `valid_host_bitmap` | 1 | 单主机模式 |
| `max_valid_host_id` | 0 | — |
| `srv_multi_host_mode` | 1 | — |
| `virtio_storage_total_qps` | 3455 | virtio 存储队列对数 |

配置目录：`/root/boris_corner/UDAA_Hi1823_chip_solution/tools/chip_cfg/cfg_data/asic_compute/eth_2x100G_dpu/`，含 `ecs_blk`/`bms_blk`/`bms_fs`/`bms_scsi` 多种 personality 的 `.xml`/`.xlsm`/`.ini`。

---

## 4. 关键代码位置路径

### 4.1 A2-110 主工作目录 `/root/tomer/`

| 路径 | 说明 |
|------|------|
| `nds/runtime-v9.0.0/` | **Ascend CANN runtime v9.0.0 移植源码**（git 仓库），含 `build.sh`、`CMakeLists.txt`、`src/`、`include/`。新增 P2P API 的核心。 |
| `nds/runtime-v9.0.0/build/_CPack_Packages/makeself_staging/runtime/lib/` | 构建产物 staging 库（`libacl_rt.so`、`libacl_rt_impl.so`、`libruntime.so` 等，带 P2P 符号）。 |
| `NDS-Tools/` | **NDS 工具集**（git 仓库，最新 8/26）。含 `bringup/`、`harness/`、`investigation/`、`regression/`、`README.md`。 |
| `NDS-Tools/fio/engine/ascend_nds.so` | **编译后的 fio P2P 引擎**（期望 md5 `965a95cd872889b02ab32d9d467237ea`）。 |
| `fio/engine/ascend_nds.c` | **fio P2P 引擎源码**（20KB，三模式 p2p/bounce/p2pw，async worker pool）。 |
| `fio/fio-src/fio` | fio 3.42 二进制。 |
| `fio/jobs/` | fio job 与 sweep 脚本（`run_mproc_sweep.sh`、`run_bs_sweep.sh`、`nds_smoke_p2p.fio` 等）。 |
| `fio/results/` | **183 个实验结果目录**。 |
| `nds_final_2026-08-06/` | **最终 2x2 对比实验结果**（含 `d_final.sh`、CSV、bwlogs）。 |
| `nds_negpath/` | ACL P2P 负路径测试（`negpath.c`，13 个 case）。 |
| `tests/` | N-series 回归测试（`n1,n2,n6,n7,n11,n10d`）+ H-series harness（`h/h.c`）。 |
| `logs/` | 所有操作日志。 |
| `demo/` | demo 套件依赖的 `d_run.sh` 等所在目录。 |

### 4.2 A2-110 内核补丁

| 路径 | 说明 |
|------|------|
| `/root/nds-patches/0001..0006-*.patch` | **6-commit 补丁集**：①PCI p2pdma set pgmap owner ②fuse ITER_ALLOW_P2PDMA ③HiSilicon Kunpeng root port whitelist ④samples virtiofs P2P test driver ⑤tools virtiofs P2P test utility ⑥gitignore。另有 `0100/0101/0102/0110` 重编号版。 |
| `/root/tomer/nds_fuse_patches/` | 3 个 FUSE 补丁（含 `0003-fuse-Fix-page-release-semantics`）。 |
| `/root/nds-local-patches/` | `p2pdma-hisi-whitelist.patch`、`makefile.patch`、`config.diff`、pristine 源码 rpm。 |
| `/root/tomer/nds-kernel/` | 内核 FUSE 仓库骨架（`prep_nds_kernel_repo.sh skeleton` 产物，目前只有 C0 pristine commit）。 |
| `/root/prep_nds_kernel_repo.sh` | 内核仓库准备脚本（`investigate` 只读调查 / `skeleton` 建 C0+C1）。 |

### 4.3 storage_os 上的关键路径

| 路径 | 说明 |
|------|------|
| `/etc/daos/daos_server.yml` | **DAOS server 配置**（access_points、provider、engines、storage）。 |
| `/opt/daos-2.6.5.p1/` | DAOS 安装目录（bin/lib64/include）。 |
| `/mnt/daos0` | DAOS tmpfs 存储（132G DRAM）。 |
| `/root/boris_corner/UDAA_Hi1823_chip_solution/` | **DPU 固件源码**（Hi1823 芯片方案，git 仓库，含 src/tools/build）。 |
| `/root/boris_corner/` | DPU 开发目录：`daos_src.tar.gz`、`linux-6.10.14`、`dpdk-19.11.14`、`fuse-3.17.4`、`Hinic3_flash.bin`、`mercury_zerocopy.patch`、`VirtioFS/`、`rdma-test/`。 |
| `/root/driver/DPU-Driver_17.12.5.0/`、`SP925D-VL-sdk_17.12.5.0/` | DPU 驱动与 SDK。 |
| `/root/tomer/demo/d_storage.sh` | 存储侧监控脚本（PANE 1 of 4，实时显示 DAOS engine 状态）。 |
| `/root/tomer/logs/` | P2-13 系列 DPU 固件 multi-host/PCIe/virtio 拓扑调查日志。 |

### 4.4 关键拉起/测试脚本（A2-110）

| 路径 | 说明 |
|------|------|
| `/root/tomer/nds_a2_up.sh`（亦在 `NDS-Tools/bringup/`） | **拉起 A2 节点**：设 max_pages_limit=64 → rescan virtiofs 设备 → mount virtiofs → 健康门禁。 |
| `/root/tomer/nds_demo_suite.sh` | **demo 验收套件**（P0-P8：门禁/读完整性/bounce读/P2P读/bounce写/写完整性/混合/P2P写）。 |
| `/root/tomer/nds_final_2026-08-06/d_final.sh` | **最终 2x2 对比**（nvme vs dpu × 4k/256k × bounce/p2p × k0/k96 × 3 rep）。 |
| `/root/boris_corner/VirtioFS/virtiofs_dev_rescan.sh` | virtiofs PCI 设备重扫描（remove 1af4:105a/0999 → rescan → modprobe）。 |
| `/root/tomer/fio/jobs/run_mproc_sweep.sh` | 多进程 sweep（N 个 fio 进程对应 N 个 virtio 队列）。 |
| `/root/tomer/NDS-Tools/harness/d_run.sh` | demo/final 套件公共运行框架。 |

---

## 5. 实验拉起命令

### 5.1 环境前置（一次性）

```bash
# === storage_os (71.14.11.77) 上：确保 DAOS server 运行 ===
ssh root@71.14.11.77   # 密码 Huawei@12#$
pgrep -a daos_engine   # 确认 daos_engine 在跑
export PATH=$PATH:/opt/daos-2.6.5.p1/bin
dmg -i pool list       # 确认 mypool Ready
# 若需重启：cd /opt/daos-2.6.5.p1/bin && . ./daos_server_configure.sh && ./daos_server_start.sh

# === A2-110 (71.14.10.110) 上 ===
ssh6.6.0-132  # 确认内核
cat /sys/module/fuse/srcversion   # → A40B06664FFF3F314A82438
ls /dev/davinci_zonedev*          # → 8 个
strings /usr/local/Ascend/driver/lib64/driver/libascend_hal.so | grep 'Addr should be p2p mem'  # → 命中

# 构建 runtime-v9.0.0（在 247 节点编写，在 A2-110 构建）
cd /root/tomer/nds/runtime-v9.0.0
sh build.sh --build_host_only \
  --ascend_install_path=/usr/local/Ascend/cann \
  --cann_3rd_lib_path=/root/tomer/nds/deps -j32
# 产物在 build/_CPack_Packages/makeself_staging/runtime/lib/
```

### 5.2 拉起 virtiofs + 健康门禁（A2-110）

```bash
# 等待开机 ≥450s（NPU 初始化），然后：
/root/tomer/nds_a2_up.sh
# 作用：sysctl fs.fuse.max_pages_limit=64 → virtiofs_dev_rescan.sh →
#       mount -t virtiofs daosfs /mnt/daos → 检查 43:00.7/mount/fuse srcversion/kdump/zonedev6,7
# 期望最后输出：== A2 GATE GREEN ==
```

### 5.3 运行 demo 验收套件（A2-110）

```bash
/root/tomer/nds_demo_suite.sh mylabel
# P0 门禁 → P1 读完整性(16G md5) → P2 bounce读 → P3 bounce engine读 →
# P4 P2P读(HEADLINE) → P5 bounce写 → P6 写完整性 → P7 混合读写 → P8 P2P写(实验性)
# 结果：/root/tomer/fio/results/suite_mylabel_<时间戳>/
```

### 5.4 运行最终 2x2 对比（A2-110）

```bash
# DPU/virtiofs 侧（需先 nds_a2_up.sh 挂载 /mnt/daos）
PHASE=dpu /root/tomer/nds_final_2026-08-06/d_final.sh

# 本地 NVMe 侧（对照）
PHASE=nvme /root/tomer/nds_final_2026-08-06/d_final.sh
# 结果 CSV：/root/tomer/fio/results/final_<日期>/final_{dpu,nvme}.csv
```

### 5.5 多进程 sweep / 单条 fio P2P 命令

```bash
# 多进程 sweep
bash /root/tomer/fio/jobs/run_mproc_sweep.sh bounce mylabel 24
bash /root/tomer/fio/jobs/run_mproc_sweep.sh p2p   mylabel 24

# 单条最小复现（P2P 读，devid=6=DPU，devid=3=本地NVMe）
source /usr/local/Ascend/cann/set_env.sh
S=/root/tomer/nds/runtime-v9.0.0/build/_CPack_Packages/makeself_staging/runtime/lib
SIX="$S/libascend_dump.so $S/liberror_manager.so $S/libruntime_common.so $S/libruntime.so $S/libacl_rt_impl.so $S/libacl_rt.so"
LD_PRELOAD="$SIX" LD_LIBRARY_PATH="$S:$LD_LIBRARY_PATH" \
/root/tomer/fio/fio-src/fio --name=r \
  --ioengine=external:/root/tomer/fio/engine/ascend_nds.so \
  --mode=p2p --devid=6 --cpu_base=0 --cpu_stride=8 \
  --filename=/mnt/daos/seed16g --rw=read --bs=1M --direct=1 \
  --numjobs=1 --iodepth=1 --readonly --size=15G --time_based --runtime=15 --ramp_time=5
```

### 5.6 storage_os 侧监控（demo 第 1 块面板）

```bash
# 在 storage_os 上，demo 运行期间实时监控 DAOS
bash /root/tomer/demo/d_storage.sh
# 显示：engine pid / targets / helper threads / tmpfs used / engine CPU% / load / state
```

### 5.7 ACL E2E 验证 / 负路径 / N-series 回归（A2-110）

```bash
# ACL E2E：用 LD_PRELOAD 六个 staging 库跑 nds_smoke_p2p_api.fio，
# 检查日志含 'via aclrtMemP2PMapHost (ACL API)' 且 aclshim 不在进程 maps 中
# 详见 history step22-24（2026-08-11）

# 负路径（13 个 case）
/root/tomer/nds_negpath/run_negpath.sh \
  /root/tomer/nds/runtime-v9.0.0/build/_CPack_Packages/makeself_staging/runtime/lib 2

# N-series 回归（n1,n2,n6,n7,n11,n10d）
cd /root/tomer/tests/n1 && gcc -O0 -g *.c -o n1 \
  -I$ASCEND_HOME_PATH/include -L$ASCEND_HOME_PATH/lib64 -lascendcl \
  -Wl,-rpath,$ASCEND_HOME_PATH/lib64 && ./n1
```

---

## 6. 实验结果文件

### 6.1 最终 2x2 结果（`/root/tomer/nds_final_2026-08-06/matched_2x2_final_2026-08-05/`）

**`final_dpu.csv`**（virtiofs/DPU，devid=6，12 workers，VALID 行摘录）：

| bs | mode | kload | 带宽(MiB/s) | p50(us) | p99(us) |
|----|------|-------|-----------|---------|---------|
| 4k | bounce | 0 | ~175 | 262 | 395 |
| 4k | p2p | 0 | ~183 | 250 | 403 |
| 256k | bounce | 0 | ~5770 | 529 | 865 |
| **256k** | **p2p** | **0** | **~8140** | **360** | **530** |
| 256k | p2p | 96(负载) | ~8000 | 360 | 550 |

**`final_nvme.csv`**（本地 NVMe，devid=3，对照）：

| bs | mode | kload | 带宽(MiB/s) | p50(us) |
|----|------|-------|-----------|---------|
| 4k | bounce | 0 | ~417 | 112 |
| 4k | p2p | 0 | ~590 | 75 |
| 256k | bounce | 0 | ~4620 | 609 |
| 256k | p2p | 0 | ~4800 | 599 |

**核心结论**：
- **DPU 256k P2P ~8100 MiB/s vs bounce ~5770 MiB/s → P2P 快 ~40%，且 p99 延迟更低**。
- NVMe 4k P2P ~590 vs bounce ~417 → P2P 快 ~40%。
- DPU 在 256k 时带宽（~8 GB/s）远超本地 NVMe（~4.8 GB/s），体现 DPU 后端带宽优势。
- k96（加 96 个 stress-ng CPU 负载）下 p2p 全 VALID，bounce 多 DISCARD-overlap（P2P 抗干扰）。
- **存储层是 DRAM tmpfs，故以上差异纯粹来自主机侧投递路径（bounce 拷贝 vs P2P 零拷贝），无存储设备干扰**。

### 6.2 其他结果位置

| 路径 | 内容 |
|------|------|
| `/root/tomer/fio/results/`（A2-110） | 183 个 sweep 结果目录 |
| `/root/tomer/nds_fio_raw_2026-08-04/` | fio 原始数据 |
| `/root/nds_m1_{run,fix,remote}_*.slog/.dmesg` | 早期（7/14-15）实验日志 |
| `/root/tomer/logs/`（A2-110） | ACL E2E、negpath、scope 等操作日志 |
| `/root/tomer/logs/`（storage_os） | P2-13 DPU 固件 multi-host/PCIe/virtio 拓扑调查日志 |
| `.../bwlogs_dpu/`、`.../bwlogs_nvme/` | per-second 带宽日志 |
| `/mnt/TRC/nds_*_pattern.bin`（A2-110） | 实验 pattern 文件 |

### 6.3 CSV 字段定义（`final_*.csv`）

```
key,phase,bs,kload,mode,rep,fio_mibs,hw_mibs,agree,iops,p50_us,p99max_us,dram_gibs,spread_s,verdict,ts
```
- `agree` = fio_mibs/hw_mibs（仪器一致性，0.85-1.15 才 VALID）
- `verdict`：`VALID` / `DISCARD-overlap` / `DISCARD-instruments` / `DISCARD-ddrc-wrap` / `DISCARD-load-missing`

---

## 7. 复现步骤（端到端）

1. **登录 storage_os**：`ssh root@71.14.11.77`（密码 `Huawei@12#$`），确认 `pgrep -a daos_engine` 有输出、`dmg -i pool list` 显示 mypool Ready。
2. **登录 A2-110**：`ssh root@71.14.10.110`（密码 `Huawei@12#$`）。
3. **确认环境**：`cat /sys/module/fuse/srcversion`（=A40B06664FFF3F314A82438）、`ls /dev/davinci_zonedev*`（8 个）、`lsmod | grep fuse`。
4. **等 NPU 就绪**：`uptime` ≥ 450s。
5. **拉起 virtiofs**：`/root/tomer/nds_a2_up.sh` → 看到 `== A2 GATE GREEN ==`。
6. **确认 seed**：`stat -c %s /mnt/daos/seed16g`（=17179869184，16GiB）。
7. **（可选）storage_os 侧开监控**：`bash /root/tomer/demo/d_storage.sh`。
8. **跑 demo 套件**：`/root/tomer/nds_demo_suite.sh repro` → 期望 `SUITE VERDICT: PASS`。
9. **跑最终对比**：`PHASE=dpu /root/tomer/nds_final_2026-08-06/d_final.sh` 与 `PHASE=nvme ...`。
10. **看结果**：`cat /root/tomer/fio/results/final_$(date +%F)/final_dpu.csv`，对比 256k p2p vs bounce 带宽。
11. **（可选）ACL E2E / 回归**：按 §5.7。

---

## 8. 已知问题与注意事项

1. **247 构建节点未登录**：247 是 runtime 源码主仓库（`/home/tomer/NDS-Ascend`，分支 `e2e/runtime-v9.0.0`）所在节点，IP 与凭据未知（A2-110 known_hosts 有 `70.252.19.4` 可能是它）。**拿到 247 访问权是继续 runtime 侧源码工作的前提**——需找管理员确认。

2. **`192.168.2.109` 不在线**：用户原记的"数据节点 192.168.2.109/24"实际应为 **192.168.2.254**（storage_os 的 enp65s0f1）。192.168.2.110 是 A2-110 的 DPU 侧（主机 OS 不可见，但 storage_os 可 ping 通）。

3. **`fs.fuse.max_pages_limit=64` 必须在 mount 前设置**：默认 256 与后端 1024 不匹配会 wedge。`nds_a2_up.sh` 已处理。

4. **virtiofs 当前未挂载**（A2-110）：`/mnt/daos` 只有 7/23 的旧测试文件，`seed16g` 不在。需 `nds_a2_up.sh` 拉起后才会有。

5. **DAOS 存储是 DRAM tmpfs**（storage_os `/mnt/daos0`，132G）：故意不用磁盘，确保 bounce vs p2p 唯一变量是主机侧投递路径。若 132G 不够（seed16g + 测试文件），需调 `scm_size`。DAOS pool `mypool` 120GB，当前 24% 已用。

6. **DAOS 证书问题**：`dmg pool query` 报证书缺失（`allow_insecure: true` 已配但仍需 cert 路径）。`dmg -i pool list` 可用。如需 query，配 `/etc/daos/certs/` 或用 `DAOS_DISABLE_CUDA` 等绕过。

7. **`.bash_history` 仅 1000 行**（两台都是，被 HISTSIZE 截断）：A2-110 只剩 2026-08-10/11 的 ACL E2E step19-24 和 negpath 操作；storage_os 剩 DAOS 配置 + DPU 固件 P2-13 调查。更早的拉起/构建/打补丁命令已丢失——流程需从脚本文件本身还原（本报告已做）。

8. **virtio_ring 无 P2P 感知（核心未完成缺口）**：见 `/root/virtio-ring-no-p2p-finding.md`。当前 6-commit 补丁集让 FUSE 接受 P2P 页，但 virtio 传输层无法 DMA 这些页。端到端 virtiofs P2P 还需 3-5 个 virtio_ring 补丁 + virtio 设备进 P2P 白名单 + IOMMU P2P passthrough。

9. **不要在 `taskset` 下跑 fio 引擎**：引擎自己 pin worker，继承单 CPU mask 会让所有 worker 塌缩到一个队列（`ascend_nds.c` 注释明确警告）。

10. **引擎拒绝门禁**（fail loud）：p2pw 外的写、numjobs>1（ACL 非 fork-safe）、verify≠none、bs<4K 或非 4K 对齐、nr_files>1、iodepth 越界、p2p 映射 >2GiB。

11. **关键 md5 校验值**（确认环境未被篡改）：
    - fuse srcversion：`A40B06664FFF3F314A82438`
    - HAL md5：`135f4ea2f9e52f52771185860be0d966`
    - engine `ascend_nds.so` md5：`965a95cd872889b02ab32d9d467237ea`（`NDS-Tools# bringup/`）
    - seed 16G md5：`a1771c1d8eb7f2da132f7574af40af1c`
    - drv_devmm_host srcversion：`89EF2FE8C65178766470691`

12. **下游消费者**：A2-110 的 `itamaro` 用户在做 vllm + lmcache + NDS 集成（`/home/itamaro/lmcache/`、`lmcache_nds.cpython-311`），改动 NDS runtime/引擎时需同步知会。

13. **storage_os 账户锁定风险**：连续密码试错会触发 `pam_tally` 锁定（"The account is locked due to 3 failed logins"）。正确密码是 `Huawei@12#$`（与 A2-110 相同）。

---

## 附录 A：关键路径速查表

```
=== A2-110 (71.14.10.110) ===
/root/tomer/nds/runtime-v9.0.0/                      # runtime 源码（构建）
/root/tomer/nds/runtime-v9.0.0/build/_CPack_Packages/makeself_staging/runtime/lib/  # staging 库
/root/tomer/NDS-Tools/                               # 工具集（git 仓库）
/root/tomer/NDS-Tools/fio/engine/ascend_nds.so       # fio P2P 引擎
/root/tomer/fio/engine/ascend_nds.c                  # 引擎源码
/root/tomer/fio/fio-src/fio                          # fio 二进制
/root/tomer/fio/jobs/                                # job/sweep 脚本
/root/tomer/fio/results/                             # 实验结果
/root/tomer/nds_final_2026-08-06/                    # 最终 2x2 结果
/root/tomer/nds_negpath/                             # 负路径测试
/root/tomer/tests/                                   # N-series/H-series 回归
/root/tomer/logs/                                    # 操作日志
/root/nds-patches/                                   # 6-commit 内核补丁
/root/tomer/nds_fuse_patches/                        # FUSE 补丁
/root/prep_nds_kernel_repo.sh                        # 内核仓库准备
/root/tomer/nds_a2_up.sh                             # 拉起 virtiofs
/root/tomer/nds_demo_suite.sh                        # demo 验收套件
/root/boris_corner/VirtioFS/virtiofs_dev_rescan.sh  # PCI 重扫描
/mnt/daos  (virtiofs，需拉起)   /mnt/TRC  (本地 NVMe)

=== storage_os (71.14.11.77) ===
/etc/daos/daos_server.yml                            # DAOS server 配置
/opt/daos-2.6.5.p1/                                  # DAOS 安装
/mnt/daos0                                           # DAOS tmpfs 存储(132G DRAM)
/root/boris_corner/UDAA_Hi1823_chip_solution/        # DPU 固件源码(Hi1823)
/root/boris_corner/                                  # DPU 开发目录
/root/driver/DPU-Driver_17.12.5.0/                   # DPU 驱动
/root/tomer/demo/d_storage.sh                        # 存储侧监控
/root/tomer/logs/                                    # P2-13 DPU固件调查日志
```

## 附录 B：设备登录速查

```
A2-110     (应用/测试节点):  ssh root@71.14.10.110    密码 Huawei@12#$   ✅
storage_os (DAOS存储+DPU固件): ssh root@71.14.11.77    密码 Huawei@12#$   ✅
247        (runtime构建节点):  IP/凭据未知(需找管理员)                    ❌
DPU        (SP925D-VL/Hi1823):  固件层,由storage_os配置                   运行中
```

## 附录 C：DAOS server 配置全文（`/etc/daos/daos_server.yml`）

```yaml
name: daos_server
access_points: ['192.168.2.254:10001']
port: 10001
disable_vmd: true
disable_vfio: true
transport_config:
  allow_insecure: true
provider: ofi+verbs;ofi_rxm
engines:
  - targets: 16
    nr_xs_helpers: 4
    fabric_iface: enp65s0f1
    fabric_iface_port: 31416
    log_file: /var/log/daos/engine_0.log
    storage:
      - class: ram
        scm_mount: /mnt/daos0
        scm_size: 132
```
