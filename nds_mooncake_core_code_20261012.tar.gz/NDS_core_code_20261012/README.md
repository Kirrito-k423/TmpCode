# NDS-Mooncake 接入项目核心修改代码汇总

> **打包时间**：2026-10-12
> **项目**：为 Mooncake TENT（统一传输运行时）实现 NDS（NPU Direct Storage）transport 后端，对标 GDS 后端。NDS 在昇腾 910B NPU + SP925D-VL DPU 平台上通过 `aclrtMemP2PMapHost` P2P 内存映射 + virtiofs 实现"存储 → NPU HBM"零拷贝。
> **说明**：本包汇总了当前可获得的核心代码。完整集成树曾位于 A2-110（71.14.10.110）`/home/t00906153/Mooncake/`，该实验室节点当前不可达（机器疑似下电），runtime-v9.0.0 移植源码、内核补丁、NDS-Tools、实验结果暂缺（见文末清单）。

## 目录结构

```
NDS_core_code_20261012/
├── README.md                        # 本文件
├── nds_impl/                        # ★ 新增代码：NDS transport 后端（路径 A 薄包装实现）
│   ├── include/tent/transport/nds/
│   │   └── nds_transport.h          # NdsTransport 类声明（TENT Transport 基类契约）
│   ├── src/transport/nds/
│   │   ├── nds_transport.cpp        # 核心实现：aclrtMemP2PMapHost 映射 + 线程池异步包装
│   │   │                            #   同步 POSIX read/write → TENT 异步批量契约
│   │   └── CMakeLists.txt           # tent_xport_nds 构建目标（USE_NDS 宏控制）
│   ├── tests/
│   │   ├── nds_smoke_test.cpp       # ACL E2E 冒烟测试（验证 P2P 映射 + O_DIRECT 数据面）
│   │   ├── nds_run_smoke.sh         # 冒烟运行脚本（LD_PRELOAD 六个 staging 库）
│   │   └── nds_diag.sh              # 诊断脚本
│   └── orig/
│       ├── types.h.orig             # TENT types.h 原版（对照用，修改版需加 NDS 枚举）
│       └── tent_src_CMakeLists.txt.orig  # tent 顶层 CMakeLists 原版
├── mooncake_ref/                    # ★ 修改后的 TENT 集成文件 + 参考源码（基于 Mooncake commit 89da2c3a）
│   ├── src/runtime/
│   │   ├── transport_loader.cpp     # [已修改] USE_NDS 分支：transports/nds/enable → 创建 NdsTransport
│   │   └── transport_selector.cpp   # [已修改] file:// Segment 优先级：GDS -> NDS -> IOURING
│   ├── src/transport/CMakeLists.txt # [已修改] add_subdirectory(nds) + tent_xport_nds 链接
│   ├── src/transport/gds/           # 参考标杆：GDS 后端实现（cuFile batch 异步模型）
│   ├── src/transport/ascend/        # 参考：ascend_direct transport（hixl 直传）
│   ├── include/tent/runtime/        # 参考头文件：transport.h / transport_selector.h /
│   │                                #   segment.h / segment_manager.h / transfer_engine_impl.h
│   ├── config/transfer-engine.json  # TENT 配置示例
│   └── tent_ref.tar.gz              # TENT 参考源码原始快照
├── a2_reference/
│   └── ascend_nds_ref.c             # A2-110 fio P2P 引擎源码快照（20KB，三模式
│                                    #   p2p/bounce/p2pw + async worker pool，
│                                    #   NdsTransport 线程池实现的参考来源）
├── scripts/                         # 构建/探测脚本（针对 A2-110 环境）
│   ├── try_build.sh / try_build2.sh # cmake configure（USE_ASCEND=ON USE_NDS=ON USE_TENT=ON）
│   ├── compile_check.sh / syntax_check.sh  # 编译/语法检查
│   ├── probe_p2p.sh                 # 探测 staging 库 P2P 符号 + runtime 源码 P2P API
│   ├── probe_deps.sh / probe_py.sh / deploy_deps.sh  # 依赖探测与部署
│   └── verify_commit.sh             # 提交校验
└── docs/
    ├── NDS-Mooncake-接入接口分析.md  # 接口梳理与接入可行性分析（设计依据）
    ├── NDS_实验复现报告.md           # A2-110 实地取证报告（2026-08-29）
    └── NDS-Solution-Architecture-中文翻译.md  # NDS 解决方案架构翻译
```

## 集成接通位置（四点）

1. **类型与名字**：`TransportType` 枚举加 `NDS`（types.h，修改版在 A2-110，原版对照见 `nds_impl/orig/types.h.orig`）
2. **构建与装载**：CMake `USE_NDS`（`nds_impl/src/transport/nds/CMakeLists.txt`）+ `transport_loader.cpp` 的 `transports/nds/enable`
3. **选择策略**：`transport_selector.cpp` 文件 Segment 优先级 `{GDS, NDS, IOURING}`
4. **Segment/Buffer 语义**：复用 `file://` Segment；NPU buffer 经 `aclrtMemP2PMapHost` 映射为主机 VA

## 缺失部分（原在 A2-110，当前不可达）

- `runtime-v9.0.0` 移植源码（`/root/tomer/nds/runtime-v9.0.0/`，含 `aclrtMemP2PMapHost`/`aclrtMemP2PUnmapHost` 实现）
- 6-commit 内核补丁（`/root/nds-patches/`：PCI p2pdma、FUSE ITER_ALLOW_P2PDMA、HiSilicon whitelist 等）
- `NDS-Tools/`（bringup/harness/regression）
- 实验结果（183 个 sweep 目录 + 最终 2x2 对比 CSV）
- `/root/tomer/nds_a2_up.sh`、`nds_demo_suite.sh` 等拉起脚本
- storage_os（71.14.11.77）：DAOS 配置、DPU 固件配置 XML
